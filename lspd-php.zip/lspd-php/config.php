<?php
/**
 * config.php
 * ÚNICO archivo que necesitás editar antes de subir el sitio a ByetHost.
 *
 * En tu panel de ByetHost (vPanel/cPanel): sección "MySQL Databases",
 * creá una base de datos y un usuario, asignale todos los permisos, y
 * pegá esos 4 datos acá abajo. ByetHost antepone tu prefijo de cuenta a
 * todo (ej: "b7_12345678_lspd", "b7_12345678_admin"), copialo tal cual
 * te lo muestra el panel.
 */

// --- Datos de conexión a MySQL (ByetHost) ---
define('DB_HOST', 'localhost');                  // Casi siempre 'localhost' en ByetHost
define('DB_NAME', 'b7_XXXXXXXX_lspd');            // Nombre de tu base de datos
define('DB_USER', 'b7_XXXXXXXX_lspd');            // Usuario MySQL
define('DB_PASS', 'TU_CONTRASEÑA_AQUI');          // Contraseña MySQL

// --- Clave secreta de la aplicación (reservada para uso futuro) ---
// La sesión y el token CSRF ya usan generación aleatoria segura de PHP
// (random_bytes) y no dependen de esta constante — no hace falta tocarla,
// queda acá por si en el futuro se agrega firma de cookies u otra función
// que la necesite.
define('APP_SECRET', 'cambia-esto-por-un-texto-largo-y-aleatorio-unico');

// --- Usuario inicial ---
// Se crea automáticamente la primera vez que se ejecuta el schema.sql.
// Placa: 9999 / Contraseña: admin123 — CAMBIALA apenas entres por primera vez.

// --- Cloudflare Turnstile (CAPTCHA) — opcional ---
// Dejalo vacío ("") si todavía no querés usar CAPTCHA; el sitio funciona
// igual sin esto. Sacá tus claves gratis en https://dash.cloudflare.com → Turnstile.
define('TURNSTILE_SITE_KEY', '');
define('TURNSTILE_SECRET_KEY', '');

// --- Zona horaria ---
date_default_timezone_set('America/Santiago'); // Cambiá según tu país/ciudad

// --- Modo de errores ---
// En ByetHost dejá esto en 0 (false) — mostrar errores de PHP en producción
// puede filtrar rutas del servidor a cualquier visitante.
define('APP_DEBUG', false);

if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

// --- Rutas base (no tocar) ---
define('BASE_DIR', __DIR__);
define('UPLOAD_DIR', BASE_DIR . '/uploads');
