<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $stmt = $pdo->prepare('DELETE FROM sanciones_internas WHERE id = ?');
    $stmt->execute([(int) ($_POST['id'] ?? 0)]);
    flash('info', 'Reporte de Asuntos Internos eliminado.');
}
redirigir('mdt/asuntos_internos.php');
