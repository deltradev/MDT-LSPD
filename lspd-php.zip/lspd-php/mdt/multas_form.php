<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();

$categorias = $pdo->query('SELECT * FROM categorias_multa ORDER BY nombre')->fetchAll();
$personas = $pdo->query('SELECT id, nombre, dni FROM personas ORDER BY nombre')->fetchAll();
$estados = getEstados('multa');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare(
        "INSERT INTO multas (id_persona, nombre_infractor, dni_infractor, motivo, monto, id_oficial, fecha, estado)
         VALUES (?, ?, ?, ?, ?, ?, CURDATE(), ?)"
    );
    $stmt->execute([
        !empty($_POST['id_persona']) ? (int) $_POST['id_persona'] : null,
        trim($_POST['nombre_infractor'] ?? ''),
        trim($_POST['dni_infractor'] ?? ''),
        trim($_POST['motivo'] ?? ''),
        (float) ($_POST['monto'] ?? 0),
        $usuario['id'],
        $_POST['estado'] ?? 'Pendiente',
    ]);
    flash('success', 'Multa registrada.');
    redirigir('mdt/multas.php');
}

$tituloPagina = 'Nueva Multa';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-cash-coin"></i> Nueva Multa</h3>
<div class="card mdt-card p-4">
  <form method="POST">
    <?= csrfCampoOculto() ?>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Persona registrada (opcional)</label>
        <select name="id_persona" class="form-select" id="selPersona" onchange="autofill(this)">
          <option value="">Ninguna / Manual</option>
          <?php foreach ($personas as $p): ?>
          <option value="<?= (int) $p['id'] ?>" data-nombre="<?= escape($p['nombre']) ?>" data-dni="<?= escape($p['dni'] ?? '') ?>"><?= escape($p['nombre']) ?> (<?= escape($p['dni'] ?: 'sin DNI') ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Nombre infractor</label>
        <input type="text" name="nombre_infractor" id="nombreInfractor" class="form-control">
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">DNI infractor</label>
        <input type="text" name="dni_infractor" id="dniInfractor" class="form-control">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Motivo</label>
        <select name="motivo" class="form-select" id="selMotivo" required>
          <option value="">Seleccionar...</option>
          <?php foreach ($categorias as $c): ?>
          <option value="<?= escape($c['nombre']) ?>" data-monto="<?= (float) $c['monto_sugerido'] ?>"><?= escape($c['nombre']) ?> ($<?= number_format((float) $c['monto_sugerido'], 2) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Monto ($)</label>
        <input type="number" step="0.01" name="monto" id="montoInput" class="form-control" required>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Estado</label>
        <select name="estado" class="form-select">
          <?php foreach ($estados as $e): ?>
          <option value="<?= escape($e) ?>"><?= escape($e) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Registrar Multa</button>
    <a href="<?= rutaBase() ?>mdt/multas.php" class="btn btn-outline-light">Cancelar</a>
  </form>
</div>
<script>
function autofill(sel) {
  var opt = sel.options[sel.selectedIndex];
  document.getElementById('nombreInfractor').value = opt.dataset.nombre || '';
  document.getElementById('dniInfractor').value = opt.dataset.dni || '';
}
document.getElementById('selMotivo').addEventListener('change', function () {
  var opt = this.options[this.selectedIndex];
  if (opt.dataset.monto) document.getElementById('montoInput').value = opt.dataset.monto;
});
</script>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
