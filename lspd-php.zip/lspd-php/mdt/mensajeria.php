<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();

$stmt = $pdo->prepare(
    "SELECT id, nombre, apellido, placa, rol FROM usuarios WHERE rol != 'Civil' AND id != ? ORDER BY nombre"
);
$stmt->execute([$usuario['id']]);
$oficiales = $stmt->fetchAll();

$conId = isset($_GET['con']) ? (int) $_GET['con'] : null;

if ($conId) {
    $stmt = $pdo->prepare(
        "SELECT m.*, u.nombre AS remitente_nombre, u.apellido AS remitente_apellido
         FROM mensajes_internos m LEFT JOIN usuarios u ON m.id_remitente = u.id
         WHERE (m.id_remitente = ? AND m.id_destinatario = ?)
            OR (m.id_remitente = ? AND m.id_destinatario = ?)
         ORDER BY m.id ASC LIMIT 200"
    );
    $stmt->execute([$usuario['id'], $conId, $conId, $usuario['id']]);
} else {
    $stmt = $pdo->query(
        "SELECT m.*, u.nombre AS remitente_nombre, u.apellido AS remitente_apellido
         FROM mensajes_internos m LEFT JOIN usuarios u ON m.id_remitente = u.id
         WHERE m.id_destinatario IS NULL
         ORDER BY m.id ASC LIMIT 200"
    );
}
$mensajes = $stmt->fetchAll();

$tituloPagina = 'Chat Interno';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-chat-dots"></i> Chat Interno LSPD</h3>
<div class="row g-3">
  <div class="col-md-3">
    <div class="card mdt-card p-3">
      <h6>Canales</h6>
      <ul class="list-group list-group-flush mb-3">
        <li class="list-group-item mdt-list-item <?= !$conId ? 'bg-primary' : '' ?>">
          <a href="<?= rutaBase() ?>mdt/mensajeria.php" class="text-decoration-none <?= !$conId ? 'text-white' : 'text-info' ?>">
            <i class="bi bi-broadcast"></i> Canal General
          </a>
        </li>
      </ul>
      <h6>Mensajes Directos</h6>
      <ul class="list-group list-group-flush">
        <?php if (empty($oficiales)): ?>
          <li class="list-group-item mdt-list-item text-secondary">No hay más oficiales.</li>
        <?php else: ?>
          <?php foreach ($oficiales as $o): ?>
          <li class="list-group-item mdt-list-item <?= $conId === (int) $o['id'] ? 'bg-primary' : '' ?>">
            <a href="<?= rutaBase() ?>mdt/mensajeria.php?con=<?= (int) $o['id'] ?>" class="text-decoration-none <?= $conId === (int) $o['id'] ? 'text-white' : 'text-info' ?>">
              <i class="bi bi-person"></i> <?= escape($o['nombre'] . ' ' . $o['apellido']) ?> <small class="text-secondary">(<?= escape($o['rol']) ?>)</small>
            </a>
          </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>
  </div>

  <div class="col-md-9">
    <div class="card mdt-card p-3 d-flex flex-column" style="height: 70vh;">
      <h6 class="mb-2">
        <?php
        if ($conId) {
            foreach ($oficiales as $o) {
                if ((int) $o['id'] === $conId) {
                    echo 'Conversación con ' . escape($o['nombre'] . ' ' . $o['apellido']);
                }
            }
        } else {
            echo 'Canal General (visible para todo el LSPD)';
        }
        ?>
      </h6>
      <div id="chatMensajes" class="flex-grow-1 overflow-auto mb-3 p-2" style="background:#0f1620; border-radius:8px;">
        <?php if (empty($mensajes)): ?>
          <p class="text-secondary">Aún no hay mensajes en este canal.</p>
        <?php else: ?>
          <?php foreach ($mensajes as $m): ?>
          <div class="mb-2 <?= (int) $m['id_remitente'] === (int) $usuario['id'] ? 'text-end' : '' ?>">
            <span class="badge <?= (int) $m['id_remitente'] === (int) $usuario['id'] ? 'bg-primary' : 'bg-secondary' ?>">
              <?= escape($m['remitente_nombre'] . ' ' . $m['remitente_apellido']) ?>
            </span>
            <div class="small text-secondary"><?= escape($m['fecha']) ?></div>
            <div><?= escape($m['mensaje']) ?></div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
      <form method="POST" action="<?= rutaBase() ?>mdt/mensajeria_enviar.php" class="d-flex gap-2">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="con_id" value="<?= $conId ?: '' ?>">
        <input type="text" name="mensaje" class="form-control" placeholder="Escribe un mensaje..." autocomplete="off" required>
        <button class="btn btn-primary"><i class="bi bi-send"></i></button>
      </form>
    </div>
  </div>
</div>

<script>
var conId = <?= $conId ? (int) $conId : 'null' ?>;
var contenedor = document.getElementById('chatMensajes');
var currentUserId = <?= (int) $usuario['id'] ?>;
var urlMensajes = '<?= rutaBase() ?>mdt/mensajeria_datos.php';

function escapeHtml(str) {
  var div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function refrescarMensajes() {
  var url = conId ? (urlMensajes + '?con=' + conId) : urlMensajes;
  fetch(url).then(function (resp) { return resp.json(); }).then(function (data) {
    var cercaDelFinal = contenedor.scrollTop + contenedor.clientHeight >= contenedor.scrollHeight - 40;
    contenedor.innerHTML = '';
    if (data.mensajes.length === 0) {
      contenedor.innerHTML = '<p class="text-secondary">Aún no hay mensajes en este canal.</p>';
    } else {
      data.mensajes.forEach(function (m) {
        var propio = m.id_remitente === currentUserId;
        var div = document.createElement('div');
        div.className = 'mb-2' + (propio ? ' text-end' : '');
        div.innerHTML = '<span class="badge ' + (propio ? 'bg-primary' : 'bg-secondary') + '">' + escapeHtml(m.remitente) + '</span>' +
          '<div class="small text-secondary">' + escapeHtml(m.fecha) + '</div>' +
          '<div>' + escapeHtml(m.mensaje) + '</div>';
        contenedor.appendChild(div);
      });
    }
    if (cercaDelFinal) contenedor.scrollTop = contenedor.scrollHeight;
  }).catch(function (e) { console.error('Error refrescando chat', e); });
}

contenedor.scrollTop = contenedor.scrollHeight;
setInterval(refrescarMensajes, 4000);
</script>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
