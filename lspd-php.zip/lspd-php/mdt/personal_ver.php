<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();
$idOficial = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ? AND rol != 'Civil'");
$stmt->execute([$idOficial]);
$oficial = $stmt->fetch();
if (!$oficial) {
    http_response_code(404);
    die('Oficial no encontrado.');
}

// Acciones POST: ascenso (solo Jefe/AdminWeb) o certificacion (cualquier LSPD)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

    if ($accion === 'ascenso') {
        if (!in_array($usuario['rol'], ROLES_ADMIN, true)) {
            http_response_code(403);
            require __DIR__ . '/../public/403.php';
            exit;
        }
        $rangoNuevo = $_POST['rango_nuevo'] ?? '';
        $motivo = trim($_POST['motivo'] ?? '');
        if ($rangoNuevo !== '') {
            $stmt = $pdo->prepare(
                "INSERT INTO historial_ascensos (id_usuario, rango_anterior, rango_nuevo, motivo, id_oficial_autoriza, fecha)
                 VALUES (?, ?, ?, ?, ?, CURDATE())"
            );
            $stmt->execute([$idOficial, $oficial['rol'], $rangoNuevo, $motivo, $usuario['id']]);
            $upd = $pdo->prepare('UPDATE usuarios SET rol = ? WHERE id = ?');
            $upd->execute([$rangoNuevo, $idOficial]);
            logAccion($usuario['id'], "Ascendió a {$oficial['placa']} de {$oficial['rol']} a {$rangoNuevo}");
            flash('success', "{$oficial['nombre']} {$oficial['apellido']} ahora es {$rangoNuevo}.");
        }
    } elseif ($accion === 'certificacion') {
        $nombreCurso = trim($_POST['nombre_curso'] ?? '');
        if ($nombreCurso !== '') {
            $fechaObtencion = $_POST['fecha_obtencion'] ?? '';
            if ($fechaObtencion === '') {
                $fechaObtencion = date('Y-m-d');
            }
            $stmt = $pdo->prepare(
                "INSERT INTO certificaciones (id_usuario, nombre_curso, institucion, fecha_obtencion, notas)
                 VALUES (?, ?, ?, ?, ?)"
            );
            $stmt->execute([$idOficial, $nombreCurso, trim($_POST['institucion'] ?? ''), $fechaObtencion, trim($_POST['notas'] ?? '')]);
            flash('success', 'Certificación agregada.');
        }
    }
    redirigir('mdt/personal_ver.php', 'id=' . $idOficial);
}

$stmt = $pdo->prepare(
    "SELECT h.*, u.nombre AS autoriza_nombre, u.apellido AS autoriza_apellido
     FROM historial_ascensos h LEFT JOIN usuarios u ON h.id_oficial_autoriza = u.id
     WHERE h.id_usuario = ? ORDER BY h.id DESC"
);
$stmt->execute([$idOficial]);
$ascensos = $stmt->fetchAll();

$stmt = $pdo->prepare('SELECT * FROM certificaciones WHERE id_usuario = ? ORDER BY id DESC');
$stmt->execute([$idOficial]);
$certificaciones = $stmt->fetchAll();

$tituloPagina = $oficial['nombre'] . ' ' . $oficial['apellido'];
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-person-vcard"></i> <?= escape($oficial['nombre'] . ' ' . $oficial['apellido']) ?>
  <span class="badge bg-primary"><?= escape($oficial['rol']) ?></span>
</h3>
<p class="text-secondary">Placa: <?= escape($oficial['placa']) ?> — Ingreso: <?= escape($oficial['fecha_ingreso']) ?></p>

<div class="row g-4">
  <div class="col-md-6">
    <div class="card mdt-card p-4">
      <h5><i class="bi bi-award"></i> Historial de Ascensos</h5>
      <?php if (in_array($usuario['rol'], ROLES_ADMIN, true)): ?>
      <form method="POST" class="mb-3 border-bottom border-secondary pb-3">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="accion" value="ascenso">
        <div class="row g-2">
          <div class="col-7">
            <select name="rango_nuevo" class="form-select">
              <?php foreach (ROLES_LSPD as $r): ?>
              <option value="<?= $r ?>" <?= $r === $oficial['rol'] ? 'selected' : '' ?>><?= $r ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-5">
            <button class="btn btn-primary w-100"><i class="bi bi-arrow-up-circle"></i> Ascender</button>
          </div>
        </div>
        <input type="text" name="motivo" class="form-control mt-2" placeholder="Motivo del ascenso (opcional)">
      </form>
      <?php endif; ?>
      <ul class="list-group list-group-flush">
        <?php if (empty($ascensos)): ?>
          <li class="list-group-item mdt-list-item text-secondary">Sin ascensos registrados.</li>
        <?php else: ?>
          <?php foreach ($ascensos as $a): ?>
          <li class="list-group-item mdt-list-item">
            <strong><?= escape($a['rango_anterior'] ?: '—') ?> → <?= escape($a['rango_nuevo']) ?></strong><br>
            <small class="text-secondary"><?= escape($a['fecha']) ?> — autorizado por <?= escape(trim(($a['autoriza_nombre'] ?? '') . ' ' . ($a['autoriza_apellido'] ?? ''))) ?></small>
            <?php if ($a['motivo']): ?><p class="mb-0 small"><?= escape($a['motivo']) ?></p><?php endif; ?>
          </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card mdt-card p-4">
      <h5><i class="bi bi-mortarboard"></i> Certificaciones / Cursos</h5>
      <form method="POST" class="mb-3 border-bottom border-secondary pb-3">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="accion" value="certificacion">
        <div class="mb-2"><input type="text" name="nombre_curso" class="form-control" placeholder="Nombre del curso" required></div>
        <div class="row g-2">
          <div class="col-7"><input type="text" name="institucion" class="form-control" placeholder="Institución"></div>
          <div class="col-5"><input type="date" name="fecha_obtencion" class="form-control"></div>
        </div>
        <textarea name="notas" class="form-control mt-2" rows="2" placeholder="Notas (opcional)"></textarea>
        <button class="btn btn-primary btn-sm mt-2"><i class="bi bi-plus-lg"></i> Agregar Certificación</button>
      </form>
      <ul class="list-group list-group-flush">
        <?php if (empty($certificaciones)): ?>
          <li class="list-group-item mdt-list-item text-secondary">Sin certificaciones registradas.</li>
        <?php else: ?>
          <?php foreach ($certificaciones as $c): ?>
          <li class="list-group-item mdt-list-item d-flex justify-content-between align-items-start">
            <div>
              <strong><?= escape($c['nombre_curso']) ?></strong><br>
              <small class="text-secondary"><?= escape($c['institucion'] ?: 'Sin institución') ?> — <?= escape($c['fecha_obtencion']) ?></small>
              <?php if ($c['notas']): ?><p class="mb-0 small"><?= escape($c['notas']) ?></p><?php endif; ?>
            </div>
            <form method="POST" action="<?= rutaBase() ?>mdt/personal_certificacion_eliminar.php">
              <?= csrfCampoOculto() ?>
              <input type="hidden" name="cert_id" value="<?= (int) $c['id'] ?>">
              <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
            </form>
          </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
