<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();

$idDenuncia = isset($_GET['id']) ? (int) $_GET['id'] : null;
$denuncia = null;
if ($idDenuncia) {
    $stmt = $pdo->prepare('SELECT * FROM denuncias WHERE id = ?');
    $stmt->execute([$idDenuncia]);
    $denuncia = $stmt->fetch();
    if (!$denuncia) {
        http_response_code(404);
        die('Denuncia no encontrada.');
    }
}

$categorias = $pdo->query('SELECT * FROM categorias_denuncia ORDER BY nombre')->fetchAll();
$estados = getEstados('denuncia');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = trim($_POST['tipo'] ?? '');
    $lugar = trim($_POST['lugar'] ?? '');
    $denunciante = trim($_POST['denunciante'] ?? '');
    $denunciadoDni = trim($_POST['denunciado_dni'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $estado = $_POST['estado'] ?? 'Pendiente';

    if ($denuncia) {
        $stmt = $pdo->prepare(
            "UPDATE denuncias SET tipo=?, lugar=?, denunciante=?, denunciado_dni=?, descripcion=?, estado=? WHERE id=?"
        );
        $stmt->execute([$tipo, $lugar, $denunciante, $denunciadoDni, $descripcion, $estado, $idDenuncia]);
        $denunciaIdFinal = $idDenuncia;
    } else {
        $nroCaso = generarNumeroCaso('CASO', 'denuncias');
        $stmt = $pdo->prepare(
            "INSERT INTO denuncias (nro_caso, tipo, fecha, lugar, denunciante, denunciado_dni,
                                     descripcion, estado, id_oficial, fecha_creacion, es_publica)
             VALUES (?, ?, CURDATE(), ?, ?, ?, ?, ?, ?, NOW(), 0)"
        );
        $stmt->execute([$nroCaso, $tipo, $lugar, $denunciante, $denunciadoDni, $descripcion, $estado, $usuario['id']]);
        $denunciaIdFinal = (int) $pdo->lastInsertId();
        logAccion($usuario['id'], "Creó denuncia {$nroCaso}");
    }

    if (!empty($_FILES['archivos']['name'][0] ?? '')) {
        $total = count($_FILES['archivos']['name']);
        for ($i = 0; $i < $total; $i++) {
            if ($_FILES['archivos']['error'][$i] !== UPLOAD_ERR_OK) {
                continue;
            }
            $archivoIndividual = [
                'name' => $_FILES['archivos']['name'][$i],
                'type' => $_FILES['archivos']['type'][$i],
                'tmp_name' => $_FILES['archivos']['tmp_name'][$i],
                'error' => $_FILES['archivos']['error'][$i],
                'size' => $_FILES['archivos']['size'][$i],
            ];
            $_FILES['__archivo_temp__'] = $archivoIndividual;
            $ruta = subirArchivo('__archivo_temp__', 'denuncias/' . $denunciaIdFinal);
            if ($ruta !== null) {
                $stmt = $pdo->prepare('INSERT INTO archivos_denuncia (id_denuncia, nombre_archivo, ruta) VALUES (?, ?, ?)');
                $stmt->execute([$denunciaIdFinal, basename($ruta), $ruta]);
            }
        }
    }

    flash('success', $denuncia ? 'Denuncia actualizada.' : 'Denuncia creada correctamente.');
    redirigir($denuncia ? 'mdt/denuncias_ver.php' : 'mdt/denuncias.php', $denuncia ? 'id=' . $idDenuncia : '');
}

$tituloPagina = $denuncia ? 'Editar Denuncia' : 'Nueva Denuncia';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-file-earmark-text"></i> <?= $denuncia ? 'Editar Denuncia' : 'Nueva Denuncia' ?></h3>
<div class="card mdt-card p-4">
  <form method="POST" enctype="multipart/form-data">
    <?= csrfCampoOculto() ?>
    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">Tipo</label>
        <select name="tipo" class="form-select">
          <option value="">Seleccionar...</option>
          <?php foreach ($categorias as $c): ?>
          <option value="<?= escape($c['nombre']) ?>" <?= ($denuncia && $denuncia['tipo'] === $c['nombre']) ? 'selected' : '' ?>><?= escape($c['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Lugar</label>
        <input type="text" name="lugar" class="form-control" value="<?= escape($denuncia['lugar'] ?? '') ?>">
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Estado</label>
        <select name="estado" class="form-select">
          <?php foreach ($estados as $e): ?>
          <option value="<?= escape($e) ?>" <?= ($denuncia && $denuncia['estado'] === $e) ? 'selected' : '' ?>><?= escape($e) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Denunciante</label>
        <input type="text" name="denunciante" class="form-control" value="<?= escape($denuncia['denunciante'] ?? '') ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">DNI Denunciado</label>
        <input type="text" name="denunciado_dni" class="form-control" value="<?= escape($denuncia['denunciado_dni'] ?? '') ?>">
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Descripción</label>
      <textarea name="descripcion" class="form-control" rows="4"><?= escape($denuncia['descripcion'] ?? '') ?></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Adjuntar archivos</label>
      <input type="file" name="archivos[]" class="form-control" multiple>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Guardar</button>
    <a href="<?= rutaBase() ?>mdt/denuncias.php" class="btn btn-outline-light">Cancelar</a>
  </form>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
