<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    "SELECT a.*, p.nombre AS persona_nombre, p.dni AS persona_dni
     FROM armas a LEFT JOIN personas p ON a.id_persona = p.id
     WHERE a.id = ?"
);
$stmt->execute([$id]);
$arma = $stmt->fetch();
if (!$arma) {
    http_response_code(404);
    die('Arma no encontrada.');
}

$rutaTemporal = sys_get_temp_dir() . '/licencia_arma_' . $id . '.pdf';
generarPdfConstancia(
    $rutaTemporal,
    'CERTIFICADO DE LICENCIA DE ARMA',
    [
        'Categoría' => $arma['categoria_arma'] ?: '-',
        'Marca / Modelo' => trim(($arma['marca'] ?: '-') . ' ' . ($arma['modelo'] ?: '')),
        'N° de Serie' => $arma['numero_serie'] ?: '-',
        'Calibre' => $arma['calibre'] ?: '-',
        'Titular' => $arma['persona_nombre'] ?: '-',
        'DNI Titular' => $arma['persona_dni'] ?: '-',
        'N° de Permiso' => $arma['numero_permiso'] ?: '-',
        'Fecha de Emisión' => $arma['fecha_emision_permiso'] ?: '-',
        'Fecha de Vencimiento' => $arma['fecha_vencimiento_permiso'] ?: '-',
        'Estado' => $arma['estado'],
    ],
    $arma['notas'] ?? ''
);

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="licencia_arma_' . $id . '.pdf"');
header('Content-Length: ' . filesize($rutaTemporal));
readfile($rutaTemporal);
unlink($rutaTemporal);
exit;
