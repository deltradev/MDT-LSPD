<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$idBanda = isset($_GET['id']) ? (int) $_GET['id'] : null;
$banda = null;
if ($idBanda) {
    $stmt = $pdo->prepare('SELECT * FROM bandas WHERE id = ?');
    $stmt->execute([$idBanda]);
    $banda = $stmt->fetch();
    if (!$banda) {
        http_response_code(404);
        die('Banda no encontrada.');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $tag = trim($_POST['tag'] ?? '');
    $lider = trim($_POST['lider'] ?? '');
    $territorio = trim($_POST['territorio'] ?? '');
    $actividades = trim($_POST['actividades'] ?? '');
    $nivelPeligro = $_POST['nivel_peligro'] ?? 'Bajo';
    $esPublico = isset($_POST['es_publico']) ? 1 : 0;

    $rutaFoto = $banda['foto'] ?? null;
    $nuevaFoto = subirArchivo('foto', 'fotos_criminales');
    if ($nuevaFoto !== null) {
        $rutaFoto = $nuevaFoto;
    }

    if ($banda) {
        $stmt = $pdo->prepare(
            "UPDATE bandas SET nombre=?, tag=?, lider=?, territorio=?, actividades=?, nivel_peligro=?, foto=?, es_publico=? WHERE id=?"
        );
        $stmt->execute([$nombre, $tag, $lider, $territorio, $actividades, $nivelPeligro, $rutaFoto, $esPublico, $idBanda]);
        flash('success', 'Banda actualizada.');
    } else {
        $stmt = $pdo->prepare(
            "INSERT INTO bandas (nombre, tag, lider, territorio, actividades, nivel_peligro, foto, es_publico, fecha_registro)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURDATE())"
        );
        $stmt->execute([$nombre, $tag, $lider, $territorio, $actividades, $nivelPeligro, $rutaFoto, $esPublico]);
        flash('success', 'Banda registrada.');
    }
    redirigir('mdt/bandas.php');
}

$tituloPagina = $banda ? 'Editar Banda' : 'Nueva Banda';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-people-fill"></i> <?= $banda ? 'Editar Banda' : 'Nueva Banda' ?></h3>
<div class="card mdt-card p-4">
  <form method="POST" enctype="multipart/form-data">
    <?= csrfCampoOculto() ?>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control" value="<?= escape($banda['nombre'] ?? '') ?>" required>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Tag</label>
        <input type="text" name="tag" class="form-control" value="<?= escape($banda['tag'] ?? '') ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Líder</label>
        <input type="text" name="lider" class="form-control" value="<?= escape($banda['lider'] ?? '') ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Territorio</label>
        <input type="text" name="territorio" class="form-control" value="<?= escape($banda['territorio'] ?? '') ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Nivel de Peligro</label>
        <select name="nivel_peligro" class="form-select">
          <?php foreach (['Bajo', 'Medio', 'Alto', 'Extremo'] as $nivel): ?>
          <option value="<?= $nivel ?>" <?= ($banda && $banda['nivel_peligro'] === $nivel) ? 'selected' : '' ?>><?= $nivel ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Foto</label>
        <?php if ($banda && !empty($banda['foto'])): ?>
        <div class="mb-2">
          <img src="<?= rutaBase() ?>descargar.php?f=<?= urlencode($banda['foto']) ?>" alt="Foto actual" style="max-height:120px; border-radius:8px;">
          <div class="form-text text-secondary">Foto actual — subí un archivo nuevo abajo solo si querés reemplazarla.</div>
        </div>
        <?php endif; ?>
        <input type="file" name="foto" class="form-control">
        <div class="form-text text-secondary">Formatos permitidos: jpg, jpeg, png, gif, webp.</div>
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Actividades</label>
      <textarea name="actividades" class="form-control" rows="3"><?= escape($banda['actividades'] ?? '') ?></textarea>
    </div>
    <div class="form-check mb-3">
      <input class="form-check-input" type="checkbox" name="es_publico" id="esPublico" <?= ($banda && $banda['es_publico']) ? 'checked' : '' ?>>
      <label class="form-check-label" for="esPublico">Marcar como "Se Busca" (visible en portal público)</label>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Guardar</button>
    <a href="<?= rutaBase() ?>mdt/bandas.php" class="btn btn-outline-light">Cancelar</a>
  </form>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
