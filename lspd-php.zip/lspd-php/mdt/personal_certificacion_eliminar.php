<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $certId = (int) ($_POST['cert_id'] ?? 0);

    $stmt = $pdo->prepare('SELECT id_usuario FROM certificaciones WHERE id = ?');
    $stmt->execute([$certId]);
    $cert = $stmt->fetch();

    if ($cert) {
        $idUsuario = (int) $cert['id_usuario'];
        $pdo->prepare('DELETE FROM certificaciones WHERE id = ?')->execute([$certId]);
        flash('info', 'Certificación eliminada.');
        redirigir('mdt/personal_ver.php', 'id=' . $idUsuario);
    }
}

redirigir('mdt/personal.php');
