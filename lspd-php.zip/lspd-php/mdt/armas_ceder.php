<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();
$idArma = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare(
    "SELECT a.*, p.nombre AS persona_nombre FROM armas a LEFT JOIN personas p ON a.id_persona = p.id WHERE a.id = ?"
);
$stmt->execute([$idArma]);
$arma = $stmt->fetch();
if (!$arma) {
    http_response_code(404);
    die('Arma no encontrada.');
}

if (in_array($arma['estado'], ['Retirada', 'Destruida'], true)) {
    flash('danger', 'No se puede ceder un arma que ya fue dada de baja o destruida.');
    redirigir('mdt/armas_ver.php', 'id=' . $idArma);
}

$personas = $pdo->query('SELECT id, nombre, dni FROM personas ORDER BY nombre')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idPersonaNueva = (int) ($_POST['id_persona_nueva'] ?? 0);
    $motivo = trim($_POST['motivo'] ?? '');

    if ($idPersonaNueva === 0) {
        flash('danger', 'Tenés que seleccionar la persona que recibe el arma.');
        redirigir('mdt/armas_ceder.php', 'id=' . $idArma);
    }

    $idPersonaAnterior = $arma['id_persona'];

    $stmt = $pdo->prepare("UPDATE armas SET id_persona = ?, estado = 'Cedida' WHERE id = ?");
    $stmt->execute([$idPersonaNueva, $idArma]);

    $stmt = $pdo->prepare(
        "INSERT INTO armas_historial (id_arma, tipo_evento, descripcion, id_persona_anterior, id_persona_nueva, id_oficial, fecha)
         VALUES (?, 'Cesión', ?, ?, ?, ?, NOW())"
    );
    $stmt->execute([$idArma, $motivo ?: 'Cesión de titularidad.', $idPersonaAnterior, $idPersonaNueva, $usuario['id']]);

    logAccion($usuario['id'], "Cedió el arma #{$idArma} a otra persona");
    flash('success', 'Arma cedida correctamente. Queda registrada en el historial.');
    redirigir('mdt/armas_ver.php', 'id=' . $idArma);
}

$tituloPagina = 'Ceder Arma / Licencia';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-arrow-left-right"></i> Ceder Arma / Licencia</h3>
<div class="alert alert-info">
  <i class="bi bi-info-circle"></i> Titular actual: <strong><?= escape($arma['persona_nombre'] ?: 'Sin titular asignado') ?></strong>.
  Al ceder, el arma pasa a nombre de la nueva persona y el estado cambia a <strong>Cedida</strong>. Queda un registro
  permanente de este cambio en el historial de la licencia.
</div>
<div class="card mdt-card p-4">
  <form method="POST">
    <?= csrfCampoOculto() ?>
    <input type="hidden" name="id" value="<?= $idArma ?>">
    <div class="mb-3">
      <label class="form-label">Nueva persona titular</label>
      <select name="id_persona_nueva" class="form-select" required>
        <option value="">Seleccionar...</option>
        <?php foreach ($personas as $p): ?>
        <option value="<?= (int) $p['id'] ?>"><?= escape($p['nombre']) ?> (<?= escape($p['dni'] ?: 'sin DNI') ?>)</option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="mb-3">
      <label class="form-label">Motivo / notas de la cesión</label>
      <textarea name="motivo" class="form-control" rows="3" placeholder="Ej: Venta particular, herencia, cesión familiar..."></textarea>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Confirmar Cesión</button>
    <a href="<?= rutaBase() ?>mdt/armas_ver.php?id=<?= $idArma ?>" class="btn btn-outline-light">Cancelar</a>
  </form>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
