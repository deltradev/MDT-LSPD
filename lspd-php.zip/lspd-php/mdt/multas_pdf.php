<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM multas WHERE id = ?');
$stmt->execute([$id]);
$multa = $stmt->fetch();
if (!$multa) {
    http_response_code(404);
    die('Multa no encontrada.');
}

$rutaTemporal = sys_get_temp_dir() . '/multa_' . $id . '.pdf';
generarPdfConstancia(
    $rutaTemporal,
    'BOLETA OFICIAL DE MULTA',
    [
        'Infractor' => $multa['nombre_infractor'] ?: '-',
        'DNI' => $multa['dni_infractor'] ?: '-',
        'Motivo' => $multa['motivo'],
        'Monto' => '$' . number_format((float) $multa['monto'], 2),
        'Fecha' => $multa['fecha'],
        'Estado' => $multa['estado'],
    ]
);

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="multa_' . $id . '.pdf"');
header('Content-Length: ' . filesize($rutaTemporal));
readfile($rutaTemporal);
unlink($rutaTemporal);
exit;
