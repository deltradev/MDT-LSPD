<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$pdo = obtenerConexion();
$sanciones = $pdo->query(
    "SELECT s.*,
            ui.nombre AS investigado_nombre, ui.apellido AS investigado_apellido, ui.placa AS investigado_placa,
            ur.nombre AS reporta_nombre, ur.apellido AS reporta_apellido
     FROM sanciones_internas s
     LEFT JOIN usuarios ui ON s.id_oficial_investigado = ui.id
     LEFT JOIN usuarios ur ON s.id_oficial_reporta = ur.id
     ORDER BY s.id DESC"
)->fetchAll();

$tituloPagina = 'Asuntos Internos';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="text-light"><i class="bi bi-shield-exclamation"></i> Asuntos Internos / Sanciones</h3>
  <a href="<?= rutaBase() ?>mdt/asuntos_internos_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nuevo Reporte</a>
</div>
<div class="alert alert-warning">
  <i class="bi bi-lock-fill"></i> Este módulo es confidencial y solo lo pueden ver Jefe y AdminWeb.
</div>
<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>Investigado</th><th>Motivo</th><th>Estado</th><th>Medida</th><th>Reportado por</th><th>Fecha</th><th></th></tr></thead>
    <tbody>
    <?php if (empty($sanciones)): ?>
      <tr><td colspan="7" class="text-secondary">No hay reportes de Asuntos Internos.</td></tr>
    <?php else: ?>
      <?php foreach ($sanciones as $s): ?>
      <tr>
        <td><?= escape($s['investigado_nombre'] . ' ' . $s['investigado_apellido']) ?> <span class="text-secondary">(<?= escape($s['investigado_placa']) ?>)</span></td>
        <td style="max-width:220px"><?= escape($s['motivo']) ?></td>
        <td><span class="badge bg-secondary"><?= escape($s['estado']) ?></span></td>
        <td><?= escape($s['medida_aplicada'] ?: '-') ?></td>
        <td><?= escape(trim(($s['reporta_nombre'] ?? '') . ' ' . ($s['reporta_apellido'] ?? ''))) ?></td>
        <td><?= escape($s['fecha']) ?></td>
        <td>
          <a href="<?= rutaBase() ?>mdt/asuntos_internos_form.php?id=<?= (int) $s['id'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
          <form method="POST" action="<?= rutaBase() ?>mdt/asuntos_internos_eliminar.php" class="d-inline" onsubmit="return confirm('¿Eliminar este reporte?')">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
