<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$armas = $pdo->query(
    "SELECT a.*, p.nombre AS persona_nombre, p.dni AS persona_dni
     FROM armas a LEFT JOIN personas p ON a.id_persona = p.id
     ORDER BY a.id DESC"
)->fetchAll();

$hoy = date('Y-m-d');

$tituloPagina = 'Registro de Armas y Licencias';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="text-light"><i class="bi bi-record-circle"></i> Registro de Armas y Licencias</h3>
  <a href="<?= rutaBase() ?>mdt/armas_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nueva Arma / Licencia</a>
</div>
<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>Tipo</th><th>Categoría</th><th>N° Serie</th><th>Marca/Modelo</th><th>Titular</th><th>N° Permiso</th><th>Vencimiento</th><th>Estado</th><th></th></tr></thead>
    <tbody>
    <?php if (empty($armas)): ?>
      <tr><td colspan="9" class="text-secondary">No hay armas registradas.</td></tr>
    <?php else: ?>
      <?php foreach ($armas as $a): ?>
      <?php $vencida = $a['fecha_vencimiento_permiso'] && $a['fecha_vencimiento_permiso'] < $hoy && $a['estado'] === 'Activa'; ?>
      <tr onclick="window.location='<?= rutaBase() ?>mdt/armas_ver.php?id=<?= (int) $a['id'] ?>'" style="cursor:pointer">
        <td><span class="badge <?= $a['tipo'] === 'Incautada' ? 'bg-danger' : 'bg-info text-dark' ?>"><?= escape($a['tipo']) ?></span></td>
        <td><?= escape($a['categoria_arma'] ?: '-') ?></td>
        <td><?= escape($a['numero_serie'] ?: '-') ?></td>
        <td><?= escape($a['marca'] ?: '-') ?> <?= escape($a['modelo'] ?: '') ?></td>
        <td><?= escape($a['persona_nombre'] ?: '-') ?> <?php if ($a['persona_dni']): ?>(<?= escape($a['persona_dni']) ?>)<?php endif; ?></td>
        <td><?= escape($a['numero_permiso'] ?: '-') ?></td>
        <td>
          <?= escape($a['fecha_vencimiento_permiso'] ?: '-') ?>
          <?php if ($vencida): ?><span class="badge bg-warning text-dark ms-1">Vencida</span><?php endif; ?>
        </td>
        <td><span class="badge <?= in_array($a['estado'], ['Retirada', 'Incautada', 'Destruida'], true) ? 'bg-danger' : 'bg-secondary' ?>"><?= escape($a['estado']) ?></span></td>
        <td onclick="event.stopPropagation()">
          <a href="<?= rutaBase() ?>mdt/armas_ver.php?id=<?= (int) $a['id'] ?>" class="btn btn-sm btn-outline-info"><i class="bi bi-eye"></i></a>
          <a href="<?= rutaBase() ?>mdt/armas_form.php?id=<?= (int) $a['id'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
          <form method="POST" action="<?= rutaBase() ?>mdt/armas_eliminar.php" class="d-inline" onsubmit="return confirm('¿Eliminar este registro?')">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
