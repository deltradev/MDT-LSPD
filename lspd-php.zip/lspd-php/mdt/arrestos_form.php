<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();
$idArresto = isset($_GET['id']) ? (int) $_GET['id'] : null;
$arresto = null;
if ($idArresto) {
    $stmt = $pdo->prepare('SELECT * FROM arrestos WHERE id = ?');
    $stmt->execute([$idArresto]);
    $arresto = $stmt->fetch();
    if (!$arresto) {
        http_response_code(404);
        die('Arresto no encontrado.');
    }
}

$personas = $pdo->query('SELECT id, nombre, dni FROM personas ORDER BY nombre')->fetchAll();
$denuncias = $pdo->query('SELECT id, nro_caso FROM denuncias ORDER BY id DESC LIMIT 200')->fetchAll();
$estados = getEstados('arresto');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idPersona = !empty($_POST['id_persona']) ? (int) $_POST['id_persona'] : null;
    $nombreDetenido = trim($_POST['nombre_detenido'] ?? '');
    $dniDetenido = trim($_POST['dni_detenido'] ?? '');
    $cargos = trim($_POST['cargos'] ?? '');
    $fianza = (float) ($_POST['fianza'] ?? 0);
    $estadoJudicial = $_POST['estado_judicial'] ?? 'Detenido';
    $idDenuncia = !empty($_POST['id_denuncia']) ? (int) $_POST['id_denuncia'] : null;
    $notas = trim($_POST['notas'] ?? '');

    $duracionMinutosTexto = trim($_POST['duracion_minutos'] ?? '');
    $duracionMinutos = $duracionMinutosTexto !== '' ? (int) $duracionMinutosTexto : null;
    $reiniciarTemporizador = isset($_POST['reiniciar_temporizador']);

    if ($arresto) {
        if ($duracionMinutos === null) {
            // Se quitó la duración: no hay temporizador corriendo.
            $inicioCondena = null;
        } elseif ($reiniciarTemporizador || $arresto['duracion_minutos'] === null || $arresto['inicio_condena'] === null) {
            // Es la primera vez que se le pone duración, o se pidió reiniciar: arranca el conteo ahora.
            $inicioCondena = date('Y-m-d H:i:s');
        } else {
            // Ya tenía un temporizador corriendo: se mantiene el inicio original.
            $inicioCondena = $arresto['inicio_condena'];
        }

        $stmt = $pdo->prepare(
            "UPDATE arrestos SET id_persona=?, nombre_detenido=?, dni_detenido=?, cargos=?, fianza=?,
                                  estado_judicial=?, id_denuncia=?, notas=?, duracion_minutos=?, inicio_condena=? WHERE id=?"
        );
        $stmt->execute([
            $idPersona, $nombreDetenido, $dniDetenido, $cargos, $fianza, $estadoJudicial,
            $idDenuncia, $notas, $duracionMinutos, $inicioCondena, $idArresto,
        ]);
        flash('success', 'Arresto actualizado.');
    } else {
        $inicioCondena = $duracionMinutos !== null ? date('Y-m-d H:i:s') : null;
        $total = (int) $pdo->query('SELECT COUNT(*) FROM arrestos')->fetchColumn();
        $nroArresto = sprintf('ARR-%s-%05d', date('Y'), $total + 1);
        $stmt = $pdo->prepare(
            "INSERT INTO arrestos (nro_arresto, id_persona, nombre_detenido, dni_detenido, cargos,
                                    fianza, estado_judicial, id_denuncia, id_oficial, notas,
                                    duracion_minutos, inicio_condena, fecha)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE())"
        );
        $stmt->execute([
            $nroArresto, $idPersona, $nombreDetenido, $dniDetenido, $cargos, $fianza,
            $estadoJudicial, $idDenuncia, $usuario['id'], $notas, $duracionMinutos, $inicioCondena,
        ]);
        flash('success', "Arresto {$nroArresto} registrado.");
    }
    redirigir('mdt/arrestos.php');
}

$tituloPagina = $arresto ? 'Editar Arresto' : 'Nuevo Arresto';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-person-lock"></i> <?= $arresto ? 'Editar Arresto' : 'Nuevo Arresto' ?></h3>
<div class="card mdt-card p-4">
  <form method="POST">
    <?= csrfCampoOculto() ?>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Persona registrada (opcional)</label>
        <select name="id_persona" class="form-select" onchange="autofillArresto(this)">
          <option value="">Ninguna / Manual</option>
          <?php foreach ($personas as $p): ?>
          <option value="<?= (int) $p['id'] ?>" data-nombre="<?= escape($p['nombre']) ?>" data-dni="<?= escape($p['dni'] ?? '') ?>"
            <?= ($arresto && (int) ($arresto['id_persona'] ?? 0) === (int) $p['id']) ? 'selected' : '' ?>><?= escape($p['nombre']) ?> (<?= escape($p['dni'] ?: 'sin DNI') ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Nombre del detenido</label>
        <input type="text" name="nombre_detenido" id="nombreDetenido" class="form-control" value="<?= escape($arresto['nombre_detenido'] ?? '') ?>">
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">DNI</label>
        <input type="text" name="dni_detenido" id="dniDetenido" class="form-control" value="<?= escape($arresto['dni_detenido'] ?? '') ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Cargos</label>
        <input type="text" name="cargos" class="form-control" value="<?= escape($arresto['cargos'] ?? '') ?>" placeholder="Ej: Robo agravado, resistencia a la autoridad">
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Fianza ($)</label>
        <input type="number" step="0.01" name="fianza" class="form-control" value="<?= escape($arresto['fianza'] ?? 0) ?>">
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Estado Judicial</label>
        <select name="estado_judicial" class="form-select">
          <?php foreach ($estados as $e): ?>
          <option value="<?= escape($e) ?>" <?= ($arresto && $arresto['estado_judicial'] === $e) ? 'selected' : '' ?>><?= escape($e) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-12 mb-3">
        <label class="form-label">Denuncia vinculada</label>
        <select name="id_denuncia" class="form-select">
          <option value="">Ninguna</option>
          <?php foreach ($denuncias as $d): ?>
          <option value="<?= (int) $d['id'] ?>" <?= ($arresto && (int) ($arresto['id_denuncia'] ?? 0) === (int) $d['id']) ? 'selected' : '' ?>><?= escape($d['nro_caso']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <h6 class="text-secondary mt-3">Temporizador de condena</h6>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Duración de la condena (minutos)</label>
        <input type="number" min="1" name="duracion_minutos" class="form-control" value="<?= escape($arresto['duracion_minutos'] ?? '') ?>" placeholder="Ej: 30">
        <div class="form-text text-secondary">
          Dejalo vacío si este arresto no usa temporizador. Al cumplirse el tiempo, el estado judicial
          pasa solo a <strong>"Condena Cumplida"</strong> (se revisa cada vez que alguien abre el listado de arrestos).
        </div>
      </div>
      <?php if ($arresto && $arresto['duracion_minutos'] !== null && $arresto['inicio_condena']): ?>
      <div class="col-md-6 mb-3">
        <label class="form-label">Temporizador actual</label>
        <div class="form-control-plaintext">
          <span class="badge bg-info text-dark" id="badgeTiempoRestante" data-fin="<?= escape(date('c', strtotime($arresto['inicio_condena']) + ((int) $arresto['duracion_minutos'] * 60))) ?>">calculando...</span>
        </div>
        <div class="form-check mt-2">
          <input class="form-check-input" type="checkbox" name="reiniciar_temporizador" id="reiniciarTemporizador">
          <label class="form-check-label" for="reiniciarTemporizador">Reiniciar el temporizador desde ahora al guardar</label>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <div class="mb-3">
      <label class="form-label">Notas</label>
      <textarea name="notas" class="form-control" rows="3"><?= escape($arresto['notas'] ?? '') ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Guardar</button>
    <a href="<?= rutaBase() ?>mdt/arrestos.php" class="btn btn-outline-light">Cancelar</a>
  </form>
</div>
<script>
function autofillArresto(sel) {
  var opt = sel.options[sel.selectedIndex];
  var nombreEl = document.getElementById('nombreDetenido');
  var dniEl = document.getElementById('dniDetenido');
  if (!nombreEl.value) nombreEl.value = opt.dataset.nombre || '';
  if (!dniEl.value) dniEl.value = opt.dataset.dni || '';
}

// Contador en vivo del temporizador de condena (si este arresto tiene uno activo)
var badgeTiempo = document.getElementById('badgeTiempoRestante');
if (badgeTiempo) {
  var finCondena = new Date(badgeTiempo.dataset.fin).getTime();
  function actualizarContador() {
    var restante = finCondena - Date.now();
    if (restante <= 0) {
      badgeTiempo.textContent = 'Tiempo cumplido — se actualizará al recargar el listado';
      badgeTiempo.className = 'badge bg-success';
      return;
    }
    var totalSeg = Math.floor(restante / 1000);
    var horas = Math.floor(totalSeg / 3600);
    var min = Math.floor((totalSeg % 3600) / 60);
    var seg = totalSeg % 60;
    var texto = (horas > 0 ? horas + 'h ' : '') + min + 'm ' + seg + 's restantes';
    badgeTiempo.textContent = texto;
    setTimeout(actualizarContador, 1000);
  }
  actualizarContador();
}
</script>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
