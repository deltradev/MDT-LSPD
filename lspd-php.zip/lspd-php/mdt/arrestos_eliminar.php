<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $stmt = $pdo->prepare('DELETE FROM arrestos WHERE id = ?');
    $stmt->execute([(int) ($_POST['id'] ?? 0)]);
    flash('info', 'Arresto eliminado.');
}
redirigir('mdt/arrestos.php');
