<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

// Revisa condenas con temporizador vencido cada vez que se abre el dashboard.
actualizarArrestosVencidos();

$pdo = obtenerConexion();
$totalDenuncias = (int) $pdo->query("SELECT COUNT(*) FROM denuncias")->fetchColumn();
$denunciasPendientes = (int) $pdo->query("SELECT COUNT(*) FROM denuncias WHERE estado = 'Pendiente'")->fetchColumn();
$totalInvestigaciones = (int) $pdo->query("SELECT COUNT(*) FROM investigaciones WHERE estado != 'Cerrada'")->fetchColumn();
$totalMultas = (int) $pdo->query("SELECT COUNT(*) FROM multas")->fetchColumn();
$ultimasDenuncias = $pdo->query("SELECT * FROM denuncias ORDER BY id DESC LIMIT 5")->fetchAll();
$bolosActivos = $pdo->query(
    "SELECT * FROM personas WHERE nivel_amenaza IN ('Alto','Extremo') ORDER BY id DESC LIMIT 5"
)->fetchAll();

$tituloPagina = 'Dashboard MDT';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-1"><i class="bi bi-speedometer2"></i> Dashboard</h3>
<p class="text-secondary"><?= escape($cfgMdt['mdt_texto_dashboard'] ?? '') ?></p>

<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="card mdt-card text-center p-3">
      <i class="bi bi-file-earmark-text display-6 text-primary"></i>
      <h3 class="mt-2"><?= $totalDenuncias ?></h3>
      <p class="mb-0 text-secondary">Denuncias Totales</p>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card mdt-card text-center p-3">
      <i class="bi bi-hourglass-split display-6 text-warning"></i>
      <h3 class="mt-2"><?= $denunciasPendientes ?></h3>
      <p class="mb-0 text-secondary">Denuncias Pendientes</p>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card mdt-card text-center p-3">
      <i class="bi bi-search display-6 text-info"></i>
      <h3 class="mt-2"><?= $totalInvestigaciones ?></h3>
      <p class="mb-0 text-secondary">Investigaciones Activas</p>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card mdt-card text-center p-3">
      <i class="bi bi-cash-coin display-6 text-success"></i>
      <h3 class="mt-2"><?= $totalMultas ?></h3>
      <p class="mb-0 text-secondary">Multas Registradas</p>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-md-7">
    <div class="card mdt-card p-3">
      <h5><i class="bi bi-file-earmark-text"></i> Últimas Denuncias</h5>
      <table class="table table-dark table-hover mt-2">
        <thead><tr><th>Caso</th><th>Tipo</th><th>Fecha</th><th>Estado</th></tr></thead>
        <tbody>
        <?php if (empty($ultimasDenuncias)): ?>
          <tr><td colspan="4" class="text-secondary">Sin denuncias registradas.</td></tr>
        <?php else: ?>
          <?php foreach ($ultimasDenuncias as $d): ?>
          <tr onclick="window.location='<?= rutaBase() ?>mdt/denuncias_ver.php?id=<?= (int) $d['id'] ?>'" style="cursor:pointer">
            <td><?= escape($d['nro_caso']) ?></td><td><?= escape($d['tipo'] ?: '-') ?></td><td><?= escape($d['fecha']) ?></td>
            <td><span class="badge bg-secondary"><?= escape($d['estado']) ?></span></td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="col-md-5">
    <div class="card mdt-card p-3">
      <h5><i class="bi bi-megaphone"></i> BOLOs de Alto Riesgo</h5>
      <ul class="list-group list-group-flush mt-2">
        <?php if (empty($bolosActivos)): ?>
          <li class="list-group-item mdt-list-item text-secondary">Sin BOLOs activos.</li>
        <?php else: ?>
          <?php foreach ($bolosActivos as $p): ?>
          <li class="list-group-item mdt-list-item d-flex justify-content-between">
            <?= escape($p['nombre']) ?> <?php if ($p['alias']): ?><span class="text-secondary">"<?= escape($p['alias']) ?>"</span><?php endif; ?>
            <span class="badge bg-danger"><?= escape($p['nivel_amenaza']) ?></span>
          </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
