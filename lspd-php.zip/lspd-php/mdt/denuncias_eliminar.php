<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $id = (int) ($_POST['id'] ?? 0);
    $stmt = $pdo->prepare('DELETE FROM denuncias WHERE id = ?');
    $stmt->execute([$id]);
    flash('info', 'Denuncia eliminada.');
}

redirigir('mdt/denuncias.php');
