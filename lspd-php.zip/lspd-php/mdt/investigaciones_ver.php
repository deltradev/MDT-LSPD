<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();
$idInv = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM investigaciones WHERE id = ?');
$stmt->execute([$idInv]);
$investigacion = $stmt->fetch();
if (!$investigacion) {
    http_response_code(404);
    die('Investigación no encontrada.');
}

// Agregar nota (POST en esta misma página)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $notaTexto = trim($_POST['nota'] ?? '');
    if ($notaTexto !== '') {
        $rutaArchivo = subirArchivo('archivo_adjunto', 'investigaciones/' . $idInv);
        $stmt = $pdo->prepare(
            'INSERT INTO notas_investigacion (id_investigacion, nota, id_oficial, fecha, archivo_adjunto)
             VALUES (?, ?, ?, NOW(), ?)'
        );
        $stmt->execute([$idInv, $notaTexto, $usuario['id'], $rutaArchivo]);
        flash('success', 'Nota agregada a la investigación.');
    }
    redirigir('mdt/investigaciones_ver.php', 'id=' . $idInv);
}

$categorias = $pdo->query('SELECT * FROM categorias_investigacion ORDER BY nombre')->fetchAll();
$personas = $pdo->query('SELECT id, nombre FROM personas ORDER BY nombre')->fetchAll();
$bandas = $pdo->query('SELECT id, nombre FROM bandas ORDER BY nombre')->fetchAll();
$estados = getEstados('investigacion');

$stmt = $pdo->prepare(
    "SELECT n.*, u.nombre AS oficial_nombre, u.apellido AS oficial_apellido
     FROM notas_investigacion n LEFT JOIN usuarios u ON n.id_oficial = u.id
     WHERE n.id_investigacion = ? ORDER BY n.id DESC"
);
$stmt->execute([$idInv]);
$notas = $stmt->fetchAll();

$tituloPagina = 'Investigación ' . $investigacion['nro_operacion'];
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-search"></i> Investigación <?= escape($investigacion['nro_operacion']) ?></h3>

<div class="card mdt-card p-4 mb-4">
  <form method="POST" action="<?= rutaBase() ?>mdt/investigaciones_editar.php">
    <?= csrfCampoOculto() ?>
    <input type="hidden" name="id" value="<?= $idInv ?>">
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Nombre de la operación</label>
        <input type="text" name="nombre" class="form-control" value="<?= escape($investigacion['nombre']) ?>" required>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Categoría</label>
        <select name="categoria" class="form-select">
          <option value="">Seleccionar...</option>
          <?php foreach ($categorias as $c): ?>
          <option value="<?= escape($c['nombre']) ?>" <?= $investigacion['categoria'] === $c['nombre'] ? 'selected' : '' ?>><?= escape($c['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Estado</label>
        <select name="estado" class="form-select">
          <?php foreach ($estados as $e): ?>
          <option value="<?= escape($e) ?>" <?= $investigacion['estado'] === $e ? 'selected' : '' ?>><?= escape($e) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Tipo de objetivo</label>
        <select name="objetivo_tipo" class="form-select">
          <option value="">Ninguno</option>
          <option value="Persona" <?= $investigacion['objetivo_tipo'] === 'Persona' ? 'selected' : '' ?>>Persona</option>
          <option value="Banda" <?= $investigacion['objetivo_tipo'] === 'Banda' ? 'selected' : '' ?>>Banda</option>
        </select>
      </div>
      <div class="col-md-8 mb-3">
        <label class="form-label">Objetivo</label>
        <select name="objetivo_id" class="form-select">
          <option value="">Ninguno</option>
          <optgroup label="Personas">
            <?php foreach ($personas as $p): ?>
            <option value="<?= (int) $p['id'] ?>" <?= (int) ($investigacion['objetivo_id'] ?? 0) === (int) $p['id'] ? 'selected' : '' ?>><?= escape($p['nombre']) ?></option>
            <?php endforeach; ?>
          </optgroup>
          <optgroup label="Bandas">
            <?php foreach ($bandas as $b): ?>
            <option value="<?= (int) $b['id'] ?>" <?= (int) ($investigacion['objetivo_id'] ?? 0) === (int) $b['id'] ? 'selected' : '' ?>><?= escape($b['nombre']) ?></option>
            <?php endforeach; ?>
          </optgroup>
        </select>
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Descripción</label>
      <textarea name="descripcion" class="form-control" rows="3"><?= escape($investigacion['descripcion'] ?? '') ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Guardar</button>
    <a href="<?= rutaBase() ?>mdt/investigaciones.php" class="btn btn-outline-light">Volver</a>
  </form>
</div>

<div class="card mdt-card p-4">
  <h5><i class="bi bi-journal-text"></i> Notas de la investigación</h5>
  <form method="POST" enctype="multipart/form-data" class="mb-3">
    <?= csrfCampoOculto() ?>
    <div class="mb-2">
      <textarea name="nota" class="form-control" rows="2" placeholder="Agregar nueva nota..."></textarea>
    </div>
    <div class="mb-2">
      <input type="file" name="archivo_adjunto" class="form-control">
    </div>
    <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Agregar Nota</button>
  </form>
  <ul class="list-group list-group-flush">
    <?php if (empty($notas)): ?>
      <li class="list-group-item mdt-list-item text-secondary">Sin notas aún.</li>
    <?php else: ?>
      <?php foreach ($notas as $n): ?>
      <li class="list-group-item mdt-list-item">
        <div class="d-flex justify-content-between">
          <strong><?= escape($n['oficial_nombre'] . ' ' . $n['oficial_apellido']) ?></strong>
          <small class="text-secondary"><?= escape($n['fecha']) ?></small>
        </div>
        <p class="mb-1"><?= nl2br(escape($n['nota'])) ?></p>
        <?php if ($n['archivo_adjunto']): ?>
          <a href="<?= rutaBase() ?>descargar.php?f=<?= urlencode($n['archivo_adjunto']) ?>" target="_blank" class="small text-info"><i class="bi bi-paperclip"></i> Archivo adjunto</a>
        <?php endif; ?>
      </li>
      <?php endforeach; ?>
    <?php endif; ?>
  </ul>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
