<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();
rateLimit('chat_enviar', 20, 60);

$usuario = usuarioActual();
$mensaje = trim($_POST['mensaje'] ?? '');
$conId = !empty($_POST['con_id']) ? (int) $_POST['con_id'] : null;

if ($mensaje !== '') {
    $pdo = obtenerConexion();
    $stmt = $pdo->prepare(
        'INSERT INTO mensajes_internos (id_remitente, id_destinatario, mensaje, fecha, leido)
         VALUES (?, ?, ?, NOW(), 0)'
    );
    $stmt->execute([$usuario['id'], $conId, $mensaje]);
}

redirigir('mdt/mensajeria.php', $conId ? 'con=' . $conId : '');
