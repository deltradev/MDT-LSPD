<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$personas = $pdo->query(
    "SELECT * FROM personas WHERE nivel_amenaza IN ('Alto','Extremo') ORDER BY id DESC"
)->fetchAll();
$bandas = $pdo->query(
    "SELECT * FROM bandas WHERE nivel_peligro IN ('Alto','Extremo') ORDER BY id DESC"
)->fetchAll();

$tituloPagina = 'BOLO';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-megaphone"></i> Avisos BOLO — Se Busca (Alto Riesgo)</h3>
<h5 class="text-light">Individuos</h5>
<div class="row g-3 mb-4">
  <?php if (empty($personas)): ?>
    <p class="text-secondary">Sin BOLOs de personas activos.</p>
  <?php else: ?>
    <?php foreach ($personas as $p): ?>
    <div class="col-md-3">
      <div class="card mdt-card p-3 text-center border-danger">
        <i class="bi bi-person-fill display-5 text-danger"></i>
        <h6 class="mt-2"><?= escape($p['nombre']) ?></h6>
        <?php if ($p['alias']): ?><p class="small text-secondary">"<?= escape($p['alias']) ?>"</p><?php endif; ?>
        <span class="badge bg-danger"><?= escape($p['nivel_amenaza']) ?></span>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
<h5 class="text-light">Bandas</h5>
<div class="row g-3">
  <?php if (empty($bandas)): ?>
    <p class="text-secondary">Sin BOLOs de bandas activos.</p>
  <?php else: ?>
    <?php foreach ($bandas as $b): ?>
    <div class="col-md-3">
      <div class="card mdt-card p-3 text-center border-warning">
        <i class="bi bi-people-fill display-5 text-warning"></i>
        <h6 class="mt-2"><?= escape($b['nombre']) ?></h6>
        <?php if ($b['tag']): ?><p class="small text-secondary"><?= escape($b['tag']) ?></p><?php endif; ?>
        <span class="badge bg-warning text-dark"><?= escape($b['nivel_peligro']) ?></span>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
