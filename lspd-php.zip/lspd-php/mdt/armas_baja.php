<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();
$idArma = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM armas WHERE id = ?');
$stmt->execute([$idArma]);
$arma = $stmt->fetch();
if (!$arma) {
    http_response_code(404);
    die('Arma no encontrada.');
}

if (in_array($arma['estado'], ['Retirada', 'Destruida'], true)) {
    flash('danger', 'Esta arma ya fue dada de baja o destruida.');
    redirigir('mdt/armas_ver.php', 'id=' . $idArma);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $motivo = trim($_POST['motivo'] ?? '');
    $estadoFinal = $_POST['estado_final'] ?? 'Retirada';

    if ($motivo === '') {
        flash('danger', 'Tenés que indicar el motivo de la baja.');
        redirigir('mdt/armas_baja.php', 'id=' . $idArma);
    }

    $stmt = $pdo->prepare(
        "UPDATE armas SET estado = ?, motivo_baja = ?, fecha_baja = CURDATE(), id_oficial_baja = ? WHERE id = ?"
    );
    $stmt->execute([$estadoFinal, $motivo, $usuario['id'], $idArma]);

    $stmt = $pdo->prepare(
        "INSERT INTO armas_historial (id_arma, tipo_evento, descripcion, id_persona_anterior, id_oficial, fecha)
         VALUES (?, 'Retiro', ?, ?, ?, NOW())"
    );
    $stmt->execute([$idArma, $motivo, $arma['id_persona'], $usuario['id']]);

    logAccion($usuario['id'], "Dio de baja el arma #{$idArma}");
    flash('success', 'Arma dada de baja correctamente.');
    redirigir('mdt/armas_ver.php', 'id=' . $idArma);
}

$tituloPagina = 'Dar de Baja Arma / Licencia';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-x-circle"></i> Dar de Baja Arma / Licencia</h3>
<div class="alert alert-warning">
  <i class="bi bi-exclamation-triangle"></i> Esta acción marca la licencia como retirada/dada de baja de forma permanente
  (por ejemplo: destrucción voluntaria, entrega al departamento, revocación del permiso). Queda registrada en el historial.
</div>
<div class="card mdt-card p-4">
  <form method="POST">
    <?= csrfCampoOculto() ?>
    <input type="hidden" name="id" value="<?= $idArma ?>">
    <div class="mb-3">
      <label class="form-label">Estado final</label>
      <select name="estado_final" class="form-select">
        <option value="Retirada">Retirada / Dada de baja</option>
        <option value="Destruida">Destruida</option>
      </select>
    </div>
    <div class="mb-3">
      <label class="form-label">Motivo de la baja</label>
      <textarea name="motivo" class="form-control" rows="3" placeholder="Ej: Revocación del permiso por vencimiento, entrega voluntaria, orden judicial..." required></textarea>
    </div>
    <button type="submit" class="btn btn-danger"><i class="bi bi-check-lg"></i> Confirmar Baja</button>
    <a href="<?= rutaBase() ?>mdt/armas_ver.php?id=<?= $idArma ?>" class="btn btn-outline-light">Cancelar</a>
  </form>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
