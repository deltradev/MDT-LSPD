<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$q = trim($_GET['q'] ?? '');

if ($q !== '') {
    $stmt = $pdo->prepare('SELECT * FROM personas WHERE nombre LIKE ? OR dni LIKE ? OR alias LIKE ? ORDER BY id DESC');
    $like = "%{$q}%";
    $stmt->execute([$like, $like, $like]);
} else {
    $stmt = $pdo->query('SELECT * FROM personas ORDER BY id DESC');
}
$personas = $stmt->fetchAll();

$tituloPagina = 'Base Criminal - Personas';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="text-light"><i class="bi bi-person-lines-fill"></i> Base de Datos Criminal - Personas</h3>
  <a href="<?= rutaBase() ?>mdt/personas_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nueva Persona</a>
</div>
<form class="mb-3" method="GET">
  <input type="text" name="q" class="form-control" placeholder="Buscar por nombre, DNI o alias..." value="<?= escape($q) ?>">
</form>
<div class="row g-3">
  <?php if (empty($personas)): ?>
    <p class="text-secondary">No hay personas registradas.</p>
  <?php else: ?>
    <?php foreach ($personas as $p): ?>
    <div class="col-md-3">
      <div class="card mdt-card p-3 text-center">
        <?php if (!empty($p['foto'])): ?>
          <img src="<?= rutaBase() ?>descargar.php?f=<?= urlencode($p['foto']) ?>" alt="Foto de <?= escape($p['nombre']) ?>" class="mx-auto mb-1" style="width:90px; height:90px; object-fit:cover; border-radius:8px;">
        <?php else: ?>
          <i class="bi bi-person-circle display-5 text-secondary"></i>
        <?php endif; ?>
        <h6 class="mt-2"><?= escape($p['nombre']) ?></h6>
        <p class="text-secondary small mb-1">DNI: <?= escape($p['dni'] ?: '-') ?></p>
        <?php if ($p['alias']): ?><p class="text-secondary small mb-1">Alias: "<?= escape($p['alias']) ?>"</p><?php endif; ?>
        <span class="badge <?= in_array($p['nivel_amenaza'], ['Alto', 'Extremo'], true) ? 'bg-danger' : 'bg-secondary' ?> mb-2"><?= escape($p['nivel_amenaza']) ?></span>
        <?php if ($p['es_publico']): ?><span class="badge bg-info text-dark mb-2">Público</span><?php endif; ?>
        <div>
          <a href="<?= rutaBase() ?>mdt/personas_form.php?id=<?= (int) $p['id'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
          <form method="POST" action="<?= rutaBase() ?>mdt/personas_eliminar.php" class="d-inline" onsubmit="return confirm('¿Eliminar?')">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
