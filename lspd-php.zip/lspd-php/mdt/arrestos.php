<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$arrestos = $pdo->query(
    "SELECT a.*, u.nombre AS oficial_nombre, u.apellido AS oficial_apellido
     FROM arrestos a LEFT JOIN usuarios u ON a.id_oficial = u.id
     ORDER BY a.id DESC"
)->fetchAll();

$tituloPagina = 'Arrestos';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="text-light"><i class="bi bi-person-lock"></i> Arrestos / Detenciones</h3>
  <a href="<?= rutaBase() ?>mdt/arrestos_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nuevo Arresto</a>
</div>
<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>N° Arresto</th><th>Detenido</th><th>DNI</th><th>Cargos</th><th>Fianza</th><th>Estado Judicial</th><th>Oficial</th><th>Fecha</th><th></th></tr></thead>
    <tbody>
    <?php if (empty($arrestos)): ?>
      <tr><td colspan="9" class="text-secondary">No hay arrestos registrados.</td></tr>
    <?php else: ?>
      <?php foreach ($arrestos as $a): ?>
      <tr>
        <td><?= escape($a['nro_arresto']) ?></td>
        <td><?= escape($a['nombre_detenido'] ?: '-') ?></td>
        <td><?= escape($a['dni_detenido'] ?: '-') ?></td>
        <td style="max-width:200px"><?= escape($a['cargos'] ?: '-') ?></td>
        <td>$<?= number_format((float) $a['fianza'], 2) ?></td>
        <td><span class="badge bg-secondary"><?= escape($a['estado_judicial']) ?></span></td>
        <td><?= escape(trim(($a['oficial_nombre'] ?? '') . ' ' . ($a['oficial_apellido'] ?? ''))) ?></td>
        <td><?= escape($a['fecha']) ?></td>
        <td>
          <a href="<?= rutaBase() ?>mdt/arrestos_form.php?id=<?= (int) $a['id'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
          <form method="POST" action="<?= rutaBase() ?>mdt/arrestos_eliminar.php" class="d-inline" onsubmit="return confirm('¿Eliminar este arresto?')">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
