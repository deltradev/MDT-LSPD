<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$investigaciones = $pdo->query('SELECT * FROM investigaciones ORDER BY id DESC')->fetchAll();

$tituloPagina = 'Investigaciones';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="text-light"><i class="bi bi-search"></i> Investigaciones</h3>
  <a href="<?= rutaBase() ?>mdt/investigaciones_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nueva Investigación</a>
</div>
<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>N° Operación</th><th>Nombre</th><th>Categoría</th><th>Estado</th><th>Inicio</th><th></th></tr></thead>
    <tbody>
    <?php if (empty($investigaciones)): ?>
      <tr><td colspan="6" class="text-secondary">No hay investigaciones registradas.</td></tr>
    <?php else: ?>
      <?php foreach ($investigaciones as $i): ?>
      <tr onclick="window.location='<?= rutaBase() ?>mdt/investigaciones_ver.php?id=<?= (int) $i['id'] ?>'" style="cursor:pointer">
        <td><?= escape($i['nro_operacion']) ?></td><td><?= escape($i['nombre']) ?></td><td><?= escape($i['categoria'] ?: '-') ?></td>
        <td><span class="badge bg-secondary"><?= escape($i['estado']) ?></span></td><td><?= escape($i['fecha_inicio']) ?></td>
        <td>
          <form method="POST" action="<?= rutaBase() ?>mdt/investigaciones_eliminar.php" onclick="event.stopPropagation()" onsubmit="return confirm('¿Eliminar?')">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $i['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
