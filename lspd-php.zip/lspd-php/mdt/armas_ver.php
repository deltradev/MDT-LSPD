<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$idArma = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    "SELECT a.*, p.nombre AS persona_nombre, p.dni AS persona_dni,
            d.nro_caso AS denuncia_caso,
            uo.nombre AS oficial_registra_nombre, uo.apellido AS oficial_registra_apellido,
            ub.nombre AS oficial_baja_nombre, ub.apellido AS oficial_baja_apellido
     FROM armas a
     LEFT JOIN personas p ON a.id_persona = p.id
     LEFT JOIN denuncias d ON a.id_denuncia = d.id
     LEFT JOIN usuarios uo ON a.id_oficial_registra = uo.id
     LEFT JOIN usuarios ub ON a.id_oficial_baja = ub.id
     WHERE a.id = ?"
);
$stmt->execute([$idArma]);
$arma = $stmt->fetch();
if (!$arma) {
    http_response_code(404);
    die('Arma no encontrada.');
}

$stmt = $pdo->prepare(
    "SELECT h.*, pa.nombre AS persona_anterior_nombre, pn.nombre AS persona_nueva_nombre,
            u.nombre AS oficial_nombre, u.apellido AS oficial_apellido
     FROM armas_historial h
     LEFT JOIN personas pa ON h.id_persona_anterior = pa.id
     LEFT JOIN personas pn ON h.id_persona_nueva = pn.id
     LEFT JOIN usuarios u ON h.id_oficial = u.id
     WHERE h.id_arma = ? ORDER BY h.id DESC"
);
$stmt->execute([$idArma]);
$historial = $stmt->fetchAll();

$hoy = date('Y-m-d');
$vencida = $arma['fecha_vencimiento_permiso'] && $arma['fecha_vencimiento_permiso'] < $hoy && $arma['estado'] === 'Activa';
$puedeGestionar = !in_array($arma['estado'], ['Retirada', 'Destruida'], true);

$tituloPagina = 'Arma / Licencia #' . $idArma;
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
  <h3 class="text-light">
    <i class="bi bi-record-circle"></i> <?= escape($arma['categoria_arma'] ?: 'Arma') ?>
    <?= escape($arma['marca'] ?: '') ?> <?= escape($arma['modelo'] ?: '') ?>
    <span class="badge <?= in_array($arma['estado'], ['Retirada', 'Incautada', 'Destruida'], true) ? 'bg-danger' : 'bg-secondary' ?>"><?= escape($arma['estado']) ?></span>
    <?php if ($vencida): ?><span class="badge bg-warning text-dark">Licencia Vencida</span><?php endif; ?>
  </h3>
  <div>
    <a href="<?= rutaBase() ?>mdt/armas_form.php?id=<?= $idArma ?>" class="btn btn-warning"><i class="bi bi-pencil"></i> Editar</a>
    <a href="<?= rutaBase() ?>mdt/armas_pdf.php?id=<?= $idArma ?>" class="btn btn-outline-light"><i class="bi bi-file-earmark-pdf"></i> Certificado PDF</a>
    <?php if ($puedeGestionar): ?>
    <a href="<?= rutaBase() ?>mdt/armas_ceder.php?id=<?= $idArma ?>" class="btn btn-info"><i class="bi bi-arrow-left-right"></i> Ceder</a>
    <a href="<?= rutaBase() ?>mdt/armas_baja.php?id=<?= $idArma ?>" class="btn btn-danger"><i class="bi bi-x-circle"></i> Dar de Baja</a>
    <?php endif; ?>
  </div>
</div>

<div class="row g-4">
  <div class="col-md-7">
    <div class="card mdt-card p-4 mb-4">
      <h5><i class="bi bi-info-circle"></i> Datos del Arma</h5>
      <div class="row">
        <div class="col-md-6"><strong>Tipo:</strong> <?= escape($arma['tipo']) ?></div>
        <div class="col-md-6"><strong>Categoría:</strong> <?= escape($arma['categoria_arma'] ?: '-') ?></div>
        <div class="col-md-6"><strong>N° de Serie:</strong> <?= escape($arma['numero_serie'] ?: '-') ?></div>
        <div class="col-md-6"><strong>Calibre:</strong> <?= escape($arma['calibre'] ?: '-') ?></div>
        <div class="col-md-6"><strong>Marca:</strong> <?= escape($arma['marca'] ?: '-') ?></div>
        <div class="col-md-6"><strong>Modelo:</strong> <?= escape($arma['modelo'] ?: '-') ?></div>
        <div class="col-md-6"><strong>Color:</strong> <?= escape($arma['color'] ?: '-') ?></div>
        <div class="col-md-6"><strong>País de origen:</strong> <?= escape($arma['pais_origen'] ?: '-') ?></div>
      </div>
      <hr class="border-secondary">
      <h5><i class="bi bi-card-checklist"></i> Licencia</h5>
      <div class="row">
        <div class="col-md-6"><strong>N° de Permiso:</strong> <?= escape($arma['numero_permiso'] ?: '-') ?></div>
        <div class="col-md-6"><strong>Titular actual:</strong> <?= escape($arma['persona_nombre'] ?: '-') ?> <?php if ($arma['persona_dni']): ?>(<?= escape($arma['persona_dni']) ?>)<?php endif; ?></div>
        <div class="col-md-6"><strong>Emisión:</strong> <?= escape($arma['fecha_emision_permiso'] ?: '-') ?></div>
        <div class="col-md-6"><strong>Vencimiento:</strong> <?= escape($arma['fecha_vencimiento_permiso'] ?: '-') ?> <?php if ($vencida): ?><span class="badge bg-warning text-dark">Vencida</span><?php endif; ?></div>
        <?php if ($arma['denuncia_caso']): ?>
        <div class="col-md-6"><strong>Denuncia vinculada:</strong> <?= escape($arma['denuncia_caso']) ?></div>
        <?php endif; ?>
        <div class="col-md-6"><strong>Registrada por:</strong> <?= escape(trim(($arma['oficial_registra_nombre'] ?? '') . ' ' . ($arma['oficial_registra_apellido'] ?? ''))) ?: '-' ?> el <?= escape($arma['fecha_registro']) ?></div>
      </div>
      <?php if ($arma['notas']): ?>
      <hr class="border-secondary">
      <p><strong>Notas:</strong><br><?= nl2br(escape($arma['notas'])) ?></p>
      <?php endif; ?>

      <?php if ($arma['estado'] === 'Retirada'): ?>
      <hr class="border-secondary">
      <h5 class="text-danger"><i class="bi bi-x-circle"></i> Baja / Retiro</h5>
      <div class="row">
        <div class="col-md-6"><strong>Fecha de baja:</strong> <?= escape($arma['fecha_baja'] ?: '-') ?></div>
        <div class="col-md-6"><strong>Dado de baja por:</strong> <?= escape(trim(($arma['oficial_baja_nombre'] ?? '') . ' ' . ($arma['oficial_baja_apellido'] ?? ''))) ?: '-' ?></div>
        <div class="col-md-12"><strong>Motivo:</strong> <?= escape($arma['motivo_baja'] ?: '-') ?></div>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-md-5">
    <div class="card mdt-card p-4">
      <h5><i class="bi bi-clock-history"></i> Historial de la Licencia</h5>
      <ul class="list-group list-group-flush">
        <?php if (empty($historial)): ?>
          <li class="list-group-item mdt-list-item text-secondary">Sin eventos registrados.</li>
        <?php else: ?>
          <?php foreach ($historial as $h): ?>
          <li class="list-group-item mdt-list-item">
            <div class="d-flex justify-content-between">
              <span class="badge bg-primary"><?= escape($h['tipo_evento']) ?></span>
              <small class="text-secondary"><?= escape($h['fecha']) ?></small>
            </div>
            <?php if ($h['descripcion']): ?><p class="mb-1 mt-1"><?= nl2br(escape($h['descripcion'])) ?></p><?php endif; ?>
            <?php if ($h['persona_anterior_nombre'] || $h['persona_nueva_nombre']): ?>
              <small class="text-secondary">
                <?= escape($h['persona_anterior_nombre'] ?: 'Sin titular') ?> → <?= escape($h['persona_nueva_nombre'] ?: 'Sin titular') ?>
              </small><br>
            <?php endif; ?>
            <small class="text-secondary">Registrado por: <?= escape(trim(($h['oficial_nombre'] ?? '') . ' ' . ($h['oficial_apellido'] ?? ''))) ?: 'Sistema' ?></small>
          </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
