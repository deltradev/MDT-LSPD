<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$multas = $pdo->query(
    "SELECT m.*, u.nombre AS oficial_nombre, u.apellido AS oficial_apellido
     FROM multas m LEFT JOIN usuarios u ON m.id_oficial = u.id
     ORDER BY m.id DESC"
)->fetchAll();

$tituloPagina = 'Multas';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="text-light"><i class="bi bi-cash-coin"></i> Multas</h3>
  <a href="<?= rutaBase() ?>mdt/multas_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nueva Multa</a>
</div>
<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>Infractor</th><th>DNI</th><th>Motivo</th><th>Monto</th><th>Oficial</th><th>Fecha</th><th>Estado</th><th></th></tr></thead>
    <tbody>
    <?php if (empty($multas)): ?>
      <tr><td colspan="8" class="text-secondary">No hay multas registradas.</td></tr>
    <?php else: ?>
      <?php foreach ($multas as $m): ?>
      <tr>
        <td><?= escape($m['nombre_infractor'] ?: '-') ?></td>
        <td><?= escape($m['dni_infractor'] ?: '-') ?></td>
        <td><?= escape($m['motivo']) ?></td>
        <td>$<?= number_format((float) $m['monto'], 2) ?></td>
        <td><?= escape(trim(($m['oficial_nombre'] ?? '') . ' ' . ($m['oficial_apellido'] ?? ''))) ?></td>
        <td><?= escape($m['fecha']) ?></td>
        <td><span class="badge bg-secondary"><?= escape($m['estado']) ?></span></td>
        <td>
          <a href="<?= rutaBase() ?>mdt/multas_pdf.php?id=<?= (int) $m['id'] ?>" class="btn btn-sm btn-outline-light"><i class="bi bi-file-earmark-pdf"></i></a>
          <form method="POST" action="<?= rutaBase() ?>mdt/multas_eliminar.php" class="d-inline" onsubmit="return confirm('¿Eliminar?')">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
