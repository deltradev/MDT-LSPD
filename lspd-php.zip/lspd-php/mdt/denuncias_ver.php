<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$idDenuncia = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM denuncias WHERE id = ?');
$stmt->execute([$idDenuncia]);
$denuncia = $stmt->fetch();
if (!$denuncia) {
    http_response_code(404);
    die('Denuncia no encontrada.');
}

$stmt = $pdo->prepare('SELECT * FROM archivos_denuncia WHERE id_denuncia = ?');
$stmt->execute([$idDenuncia]);
$archivos = $stmt->fetchAll();

$tituloPagina = 'Denuncia ' . $denuncia['nro_caso'];
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between mb-3">
  <h3 class="text-light"><i class="bi bi-file-earmark-text"></i> <?= escape($denuncia['nro_caso']) ?></h3>
  <div>
    <a href="<?= rutaBase() ?>mdt/denuncias_form.php?id=<?= $idDenuncia ?>" class="btn btn-warning"><i class="bi bi-pencil"></i> Editar</a>
    <a href="<?= rutaBase() ?>mdt/denuncias_pdf.php?id=<?= $idDenuncia ?>" class="btn btn-outline-light"><i class="bi bi-file-earmark-pdf"></i> PDF</a>
  </div>
</div>
<div class="card mdt-card p-4">
  <div class="row">
    <div class="col-md-3"><strong>Tipo:</strong> <?= escape($denuncia['tipo'] ?: '-') ?></div>
    <div class="col-md-3"><strong>Fecha:</strong> <?= escape($denuncia['fecha']) ?></div>
    <div class="col-md-3"><strong>Lugar:</strong> <?= escape($denuncia['lugar'] ?: '-') ?></div>
    <div class="col-md-3"><strong>Estado:</strong> <span class="badge bg-secondary"><?= escape($denuncia['estado']) ?></span></div>
  </div>
  <hr class="border-secondary">
  <div class="row">
    <div class="col-md-6"><strong>Denunciante:</strong> <?= escape($denuncia['denunciante'] ?: '-') ?></div>
    <div class="col-md-6"><strong>DNI Denunciado:</strong> <?= escape($denuncia['denunciado_dni'] ?: '-') ?></div>
  </div>
  <hr class="border-secondary">
  <p><strong>Descripción:</strong><br><?= nl2br(escape($denuncia['descripcion'] ?: 'Sin descripción.')) ?></p>
  <hr class="border-secondary">
  <h6><i class="bi bi-paperclip"></i> Archivos adjuntos</h6>
  <ul class="list-group list-group-flush">
    <?php if (empty($archivos)): ?>
      <li class="list-group-item mdt-list-item text-secondary">Sin archivos adjuntos.</li>
    <?php else: ?>
      <?php foreach ($archivos as $a): ?>
      <li class="list-group-item mdt-list-item">
        <a href="<?= rutaBase() ?>descargar.php?f=<?= urlencode($a['ruta']) ?>" target="_blank" class="text-info"><?= escape($a['nombre_archivo']) ?></a>
      </li>
      <?php endforeach; ?>
    <?php endif; ?>
  </ul>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
