<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$oficiales = $pdo->query("SELECT * FROM usuarios WHERE rol != 'Civil' ORDER BY nombre")->fetchAll();

$tituloPagina = 'Personal';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-person-vcard"></i> Personal LSPD</h3>
<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>Placa</th><th>Nombre</th><th>Rango Actual</th><th>Ingreso</th><th></th></tr></thead>
    <tbody>
    <?php if (empty($oficiales)): ?>
      <tr><td colspan="5" class="text-secondary">No hay personal registrado.</td></tr>
    <?php else: ?>
      <?php foreach ($oficiales as $o): ?>
      <tr onclick="window.location='<?= rutaBase() ?>mdt/personal_ver.php?id=<?= (int) $o['id'] ?>'" style="cursor:pointer">
        <td><?= escape($o['placa']) ?></td>
        <td><?= escape($o['nombre'] . ' ' . $o['apellido']) ?></td>
        <td><span class="badge bg-primary"><?= escape($o['rol']) ?></span></td>
        <td><?= escape($o['fecha_ingreso']) ?></td>
        <td><i class="bi bi-chevron-right"></i></td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
