<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();

$denunciasPorTipo = $pdo->query(
    "SELECT COALESCE(NULLIF(tipo, ''), 'Sin tipo') AS etiqueta, COUNT(*) AS total
     FROM denuncias GROUP BY etiqueta ORDER BY total DESC"
)->fetchAll();

$denunciasPorMes = $pdo->query(
    "SELECT SUBSTR(fecha_creacion, 1, 7) AS mes, COUNT(*) AS total
     FROM denuncias GROUP BY mes ORDER BY mes ASC LIMIT 12"
)->fetchAll();

$investigacionesPorEstado = $pdo->query(
    "SELECT estado AS etiqueta, COUNT(*) AS total FROM investigaciones GROUP BY estado"
)->fetchAll();

$multasPorMes = $pdo->query(
    "SELECT SUBSTR(fecha, 1, 7) AS mes, COUNT(*) AS total, SUM(monto) AS recaudado
     FROM multas GROUP BY mes ORDER BY mes ASC LIMIT 12"
)->fetchAll();

$arrestosPorMes = $pdo->query(
    "SELECT SUBSTR(fecha, 1, 7) AS mes, COUNT(*) AS total
     FROM arrestos GROUP BY mes ORDER BY mes ASC LIMIT 12"
)->fetchAll();

$topOficiales = $pdo->query(
    "SELECT u.nombre, u.apellido, u.placa, COUNT(d.id) AS total
     FROM denuncias d JOIN usuarios u ON d.id_oficial = u.id
     GROUP BY d.id_oficial ORDER BY total DESC LIMIT 8"
)->fetchAll();

$personasPorAmenaza = $pdo->query(
    "SELECT nivel_amenaza AS etiqueta, COUNT(*) AS total FROM personas GROUP BY nivel_amenaza"
)->fetchAll();

$totales = [
    'denuncias' => (int) $pdo->query('SELECT COUNT(*) FROM denuncias')->fetchColumn(),
    'investigaciones' => (int) $pdo->query('SELECT COUNT(*) FROM investigaciones')->fetchColumn(),
    'multas' => (int) $pdo->query('SELECT COUNT(*) FROM multas')->fetchColumn(),
    'recaudado_multas' => (float) $pdo->query('SELECT COALESCE(SUM(monto),0) FROM multas')->fetchColumn(),
    'arrestos' => (int) $pdo->query('SELECT COUNT(*) FROM arrestos')->fetchColumn(),
    'armas' => (int) $pdo->query('SELECT COUNT(*) FROM armas')->fetchColumn(),
    'personas' => (int) $pdo->query('SELECT COUNT(*) FROM personas')->fetchColumn(),
    'oficiales' => (int) $pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol != 'Civil'")->fetchColumn(),
];

$tituloPagina = 'Estadísticas';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-1"><i class="bi bi-bar-chart-line"></i> Estadísticas Automáticas</h3>
<p class="text-secondary">Calculadas en tiempo real a partir de los datos actuales del sistema.</p>

<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="card mdt-card p-3 text-center">
      <h4 class="mb-0"><?= $totales['denuncias'] ?></h4><small class="text-secondary">Denuncias</small>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card mdt-card p-3 text-center">
      <h4 class="mb-0"><?= $totales['investigaciones'] ?></h4><small class="text-secondary">Investigaciones</small>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card mdt-card p-3 text-center">
      <h4 class="mb-0"><?= $totales['arrestos'] ?></h4><small class="text-secondary">Arrestos</small>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card mdt-card p-3 text-center">
      <h4 class="mb-0">$<?= number_format($totales['recaudado_multas'], 2) ?></h4><small class="text-secondary">Recaudado en Multas (<?= $totales['multas'] ?>)</small>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card mdt-card p-3 text-center">
      <h4 class="mb-0"><?= $totales['armas'] ?></h4><small class="text-secondary">Armas Registradas</small>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card mdt-card p-3 text-center">
      <h4 class="mb-0"><?= $totales['personas'] ?></h4><small class="text-secondary">Personas en BD Criminal</small>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="card mdt-card p-3 text-center">
      <h4 class="mb-0"><?= $totales['oficiales'] ?></h4><small class="text-secondary">Personal LSPD</small>
    </div>
  </div>
</div>

<div class="row g-4">
  <div class="col-md-6">
    <div class="card mdt-card p-3">
      <h6>Denuncias por Tipo</h6>
      <canvas id="chartDenunciasTipo" height="220"></canvas>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card mdt-card p-3">
      <h6>Denuncias por Mes</h6>
      <canvas id="chartDenunciasMes" height="220"></canvas>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card mdt-card p-3">
      <h6>Investigaciones por Estado</h6>
      <canvas id="chartInvestigaciones" height="220"></canvas>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card mdt-card p-3">
      <h6>Multas por Mes (cantidad y recaudación)</h6>
      <canvas id="chartMultas" height="220"></canvas>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card mdt-card p-3">
      <h6>Arrestos por Mes</h6>
      <canvas id="chartArrestos" height="220"></canvas>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card mdt-card p-3">
      <h6>Personas por Nivel de Amenaza</h6>
      <canvas id="chartAmenaza" height="220"></canvas>
    </div>
  </div>
  <div class="col-md-12">
    <div class="card mdt-card p-3">
      <h6>Top Oficiales por Denuncias Registradas</h6>
      <canvas id="chartTopOficiales" height="140"></canvas>
    </div>
  </div>
</div>

<script>
var paleta = ['#0d6efd', '#dc3545', '#ffc107', '#20c997', '#6f42c1', '#fd7e14', '#0dcaf0', '#adb5bd'];
Chart.defaults.color = '#cbd5e1';
Chart.defaults.borderColor = '#2a3646';

var denunciasTipo = <?= json_encode($denunciasPorTipo) ?>;
new Chart(document.getElementById('chartDenunciasTipo'), {
  type: 'doughnut',
  data: {
    labels: denunciasTipo.map(function (d) { return d.etiqueta; }),
    datasets: [{ data: denunciasTipo.map(function (d) { return d.total; }), backgroundColor: paleta }]
  }
});

var denunciasMes = <?= json_encode($denunciasPorMes) ?>;
new Chart(document.getElementById('chartDenunciasMes'), {
  type: 'line',
  data: {
    labels: denunciasMes.map(function (d) { return d.mes; }),
    datasets: [{ label: 'Denuncias', data: denunciasMes.map(function (d) { return d.total; }), borderColor: '#0d6efd', tension: 0.3 }]
  }
});

var investigaciones = <?= json_encode($investigacionesPorEstado) ?>;
new Chart(document.getElementById('chartInvestigaciones'), {
  type: 'pie',
  data: {
    labels: investigaciones.map(function (d) { return d.etiqueta; }),
    datasets: [{ data: investigaciones.map(function (d) { return d.total; }), backgroundColor: paleta }]
  }
});

var multasMes = <?= json_encode($multasPorMes) ?>;
new Chart(document.getElementById('chartMultas'), {
  data: {
    labels: multasMes.map(function (d) { return d.mes; }),
    datasets: [
      { type: 'bar', label: 'Cantidad', data: multasMes.map(function (d) { return d.total; }), backgroundColor: '#0d6efd' },
      { type: 'line', label: 'Recaudado ($)', data: multasMes.map(function (d) { return d.recaudado || 0; }), borderColor: '#ffc107', yAxisID: 'y1' }
    ]
  },
  options: {
    scales: {
      y: { beginAtZero: true },
      y1: { beginAtZero: true, position: 'right', grid: { drawOnChartArea: false } }
    }
  }
});

var arrestosMes = <?= json_encode($arrestosPorMes) ?>;
new Chart(document.getElementById('chartArrestos'), {
  type: 'bar',
  data: {
    labels: arrestosMes.map(function (d) { return d.mes; }),
    datasets: [{ label: 'Arrestos', data: arrestosMes.map(function (d) { return d.total; }), backgroundColor: '#dc3545' }]
  }
});

var amenaza = <?= json_encode($personasPorAmenaza) ?>;
new Chart(document.getElementById('chartAmenaza'), {
  type: 'doughnut',
  data: {
    labels: amenaza.map(function (d) { return d.etiqueta; }),
    datasets: [{ data: amenaza.map(function (d) { return d.total; }), backgroundColor: paleta }]
  }
});

var topOficiales = <?= json_encode($topOficiales) ?>;
new Chart(document.getElementById('chartTopOficiales'), {
  type: 'bar',
  data: {
    labels: topOficiales.map(function (d) { return d.nombre + ' ' + d.apellido; }),
    datasets: [{ label: 'Denuncias registradas', data: topOficiales.map(function (d) { return d.total; }), backgroundColor: '#20c997' }]
  },
  options: { indexAxis: 'y' }
});
</script>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
