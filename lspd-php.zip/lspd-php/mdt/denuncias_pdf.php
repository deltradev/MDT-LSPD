<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM denuncias WHERE id = ?');
$stmt->execute([$id]);
$denuncia = $stmt->fetch();
if (!$denuncia) {
    http_response_code(404);
    die('Denuncia no encontrada.');
}

$rutaTemporal = sys_get_temp_dir() . '/constancia_denuncia_' . $id . '.pdf';
generarPdfConstancia(
    $rutaTemporal,
    'CONSTANCIA OFICIAL DE DENUNCIA',
    [
        'N° de Caso' => $denuncia['nro_caso'],
        'Tipo' => $denuncia['tipo'] ?: '-',
        'Fecha' => $denuncia['fecha'],
        'Lugar' => $denuncia['lugar'] ?: '-',
        'Denunciante' => $denuncia['denunciante'] ?: '-',
        'DNI Denunciado' => $denuncia['denunciado_dni'] ?: '-',
        'Estado' => $denuncia['estado'],
    ],
    $denuncia['descripcion'] ?? ''
);

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="constancia_' . $denuncia['nro_caso'] . '.pdf"');
header('Content-Length: ' . filesize($rutaTemporal));
readfile($rutaTemporal);
unlink($rutaTemporal);
exit;
