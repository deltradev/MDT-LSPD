<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();

$categorias = $pdo->query('SELECT * FROM categorias_investigacion ORDER BY nombre')->fetchAll();
$personas = $pdo->query('SELECT id, nombre FROM personas ORDER BY nombre')->fetchAll();
$bandas = $pdo->query('SELECT id, nombre FROM bandas ORDER BY nombre')->fetchAll();
$estados = getEstados('investigacion');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $total = (int) $pdo->query('SELECT COUNT(*) FROM investigaciones')->fetchColumn();
    $nroOperacion = sprintf('OP-%s-%04d', date('Y'), $total + 1);

    $stmt = $pdo->prepare(
        "INSERT INTO investigaciones (nro_operacion, nombre, objetivo_tipo, objetivo_id, descripcion,
                                       categoria, estado, id_oficial_cargo, fecha_inicio)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURDATE())"
    );
    $stmt->execute([
        $nroOperacion,
        trim($_POST['nombre'] ?? ''),
        $_POST['objetivo_tipo'] ?? '',
        !empty($_POST['objetivo_id']) ? (int) $_POST['objetivo_id'] : null,
        trim($_POST['descripcion'] ?? ''),
        $_POST['categoria'] ?? '',
        $_POST['estado'] ?? 'Abierta',
        $usuario['id'],
    ]);

    flash('success', "Investigación {$nroOperacion} creada.");
    redirigir('mdt/investigaciones.php');
}

$tituloPagina = 'Nueva Investigación';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-search"></i> Nueva Investigación</h3>
<div class="card mdt-card p-4">
  <form method="POST">
    <?= csrfCampoOculto() ?>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Nombre de la operación</label>
        <input type="text" name="nombre" class="form-control" required>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Categoría</label>
        <select name="categoria" class="form-select">
          <option value="">Seleccionar...</option>
          <?php foreach ($categorias as $c): ?>
          <option value="<?= escape($c['nombre']) ?>"><?= escape($c['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Estado</label>
        <select name="estado" class="form-select">
          <?php foreach ($estados as $e): ?>
          <option value="<?= escape($e) ?>"><?= escape($e) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Tipo de objetivo</label>
        <select name="objetivo_tipo" class="form-select">
          <option value="">Ninguno</option>
          <option value="Persona">Persona</option>
          <option value="Banda">Banda</option>
        </select>
      </div>
      <div class="col-md-8 mb-3">
        <label class="form-label">Objetivo</label>
        <select name="objetivo_id" class="form-select">
          <option value="">Ninguno</option>
          <optgroup label="Personas">
            <?php foreach ($personas as $p): ?>
            <option value="<?= (int) $p['id'] ?>"><?= escape($p['nombre']) ?></option>
            <?php endforeach; ?>
          </optgroup>
          <optgroup label="Bandas">
            <?php foreach ($bandas as $b): ?>
            <option value="<?= (int) $b['id'] ?>"><?= escape($b['nombre']) ?></option>
            <?php endforeach; ?>
          </optgroup>
        </select>
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Descripción</label>
      <textarea name="descripcion" class="form-control" rows="3"></textarea>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Guardar</button>
    <a href="<?= rutaBase() ?>mdt/investigaciones.php" class="btn btn-outline-light">Volver</a>
  </form>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
