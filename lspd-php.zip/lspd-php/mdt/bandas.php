<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$bandas = $pdo->query('SELECT * FROM bandas ORDER BY id DESC')->fetchAll();

$tituloPagina = 'Base Criminal - Bandas';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="text-light"><i class="bi bi-people-fill"></i> Base de Datos Criminal - Bandas</h3>
  <a href="<?= rutaBase() ?>mdt/bandas_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nueva Banda</a>
</div>
<div class="row g-3">
  <?php if (empty($bandas)): ?>
    <p class="text-secondary">No hay bandas registradas.</p>
  <?php else: ?>
    <?php foreach ($bandas as $b): ?>
    <div class="col-md-3">
      <div class="card mdt-card p-3 text-center">
        <i class="bi bi-flag-fill display-5 text-secondary"></i>
        <h6 class="mt-2"><?= escape($b['nombre']) ?></h6>
        <?php if ($b['tag']): ?><p class="text-secondary small mb-1">Tag: <?= escape($b['tag']) ?></p><?php endif; ?>
        <p class="text-secondary small mb-1">Líder: <?= escape($b['lider'] ?: '-') ?></p>
        <span class="badge <?= in_array($b['nivel_peligro'], ['Alto', 'Extremo'], true) ? 'bg-danger' : 'bg-secondary' ?> mb-2"><?= escape($b['nivel_peligro']) ?></span>
        <?php if ($b['es_publico']): ?><span class="badge bg-info text-dark mb-2">Público</span><?php endif; ?>
        <div>
          <a href="<?= rutaBase() ?>mdt/bandas_form.php?id=<?= (int) $b['id'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
          <form method="POST" action="<?= rutaBase() ?>mdt/bandas_eliminar.php" class="d-inline" onsubmit="return confirm('¿Eliminar?')">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
