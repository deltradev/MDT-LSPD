<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$pdo = obtenerConexion();
$usuario = usuarioActual();
$idSancion = isset($_GET['id']) ? (int) $_GET['id'] : null;
$sancion = null;
if ($idSancion) {
    $stmt = $pdo->prepare('SELECT * FROM sanciones_internas WHERE id = ?');
    $stmt->execute([$idSancion]);
    $sancion = $stmt->fetch();
    if (!$sancion) {
        http_response_code(404);
        die('Reporte no encontrado.');
    }
}

$oficiales = $pdo->query(
    "SELECT id, nombre, apellido, placa, rol FROM usuarios WHERE rol != 'Civil' ORDER BY nombre"
)->fetchAll();
$estados = getEstados('asunto_interno');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idInvestigado = (int) ($_POST['id_oficial_investigado'] ?? 0);
    $motivo = trim($_POST['motivo'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $estado = $_POST['estado'] ?? 'Pendiente';
    $medidaAplicada = trim($_POST['medida_aplicada'] ?? '');
    $esCerrado = strpos($estado, 'Cerrad') === 0;

    if ($sancion) {
        $fechaResolucion = $esCerrado ? date('Y-m-d') : $sancion['fecha_resolucion'];
        $stmt = $pdo->prepare(
            "UPDATE sanciones_internas SET id_oficial_investigado=?, motivo=?, descripcion=?,
                                            estado=?, medida_aplicada=?, fecha_resolucion=? WHERE id=?"
        );
        $stmt->execute([$idInvestigado, $motivo, $descripcion, $estado, $medidaAplicada, $fechaResolucion, $idSancion]);
        flash('success', 'Reporte actualizado.');
    } else {
        $fechaResolucion = $esCerrado ? date('Y-m-d') : null;
        $stmt = $pdo->prepare(
            "INSERT INTO sanciones_internas (id_oficial_investigado, id_oficial_reporta, motivo,
                                              descripcion, estado, medida_aplicada, fecha, fecha_resolucion)
             VALUES (?, ?, ?, ?, ?, ?, CURDATE(), ?)"
        );
        $stmt->execute([$idInvestigado, $usuario['id'], $motivo, $descripcion, $estado, $medidaAplicada, $fechaResolucion]);
        logAccion($usuario['id'], 'Registró un reporte de Asuntos Internos');
        flash('success', 'Reporte de Asuntos Internos registrado.');
    }
    redirigir('mdt/asuntos_internos.php');
}

$tituloPagina = $sancion ? 'Editar Reporte' : 'Nuevo Reporte de Asuntos Internos';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-shield-exclamation"></i> <?= $sancion ? 'Editar Reporte' : 'Nuevo Reporte' ?></h3>
<div class="card mdt-card p-4">
  <form method="POST">
    <?= csrfCampoOculto() ?>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Oficial investigado</label>
        <select name="id_oficial_investigado" class="form-select" required>
          <option value="">Seleccionar...</option>
          <?php foreach ($oficiales as $o): ?>
          <option value="<?= (int) $o['id'] ?>" <?= ($sancion && (int) $sancion['id_oficial_investigado'] === (int) $o['id']) ? 'selected' : '' ?>>
            <?= escape($o['nombre'] . ' ' . $o['apellido']) ?> — <?= escape($o['rol']) ?> (<?= escape($o['placa']) ?>)
          </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Estado</label>
        <select name="estado" class="form-select">
          <?php foreach ($estados as $e): ?>
          <option value="<?= escape($e) ?>" <?= ($sancion && $sancion['estado'] === $e) ? 'selected' : '' ?>><?= escape($e) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Motivo</label>
      <input type="text" name="motivo" class="form-control" value="<?= escape($sancion['motivo'] ?? '') ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Descripción de los hechos</label>
      <textarea name="descripcion" class="form-control" rows="4"><?= escape($sancion['descripcion'] ?? '') ?></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Medida aplicada (si corresponde)</label>
      <input type="text" name="medida_aplicada" class="form-control" value="<?= escape($sancion['medida_aplicada'] ?? '') ?>" placeholder="Ej: Amonestación, suspensión 5 días, degradación...">
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Guardar</button>
    <a href="<?= rutaBase() ?>mdt/asuntos_internos.php" class="btn btn-outline-light">Cancelar</a>
  </form>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
