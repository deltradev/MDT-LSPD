<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();
$idArma = isset($_GET['id']) ? (int) $_GET['id'] : null;
$arma = null;
if ($idArma) {
    $stmt = $pdo->prepare('SELECT * FROM armas WHERE id = ?');
    $stmt->execute([$idArma]);
    $arma = $stmt->fetch();
    if (!$arma) {
        http_response_code(404);
        die('Arma no encontrada.');
    }
}

$personas = $pdo->query('SELECT id, nombre, dni FROM personas ORDER BY nombre')->fetchAll();
$denuncias = $pdo->query('SELECT id, nro_caso FROM denuncias ORDER BY id DESC LIMIT 200')->fetchAll();
$estados = getEstados('arma');
$categorias = ['Pistola', 'Revólver', 'Rifle', 'Escopeta', 'Subfusil', 'Otro'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['tipo'] ?? 'Permiso Civil';
    $categoriaArma = $_POST['categoria_arma'] ?? '';
    $numeroSerie = trim($_POST['numero_serie'] ?? '');
    $marca = trim($_POST['marca'] ?? '');
    $modelo = trim($_POST['modelo'] ?? '');
    $calibre = trim($_POST['calibre'] ?? '');
    $color = trim($_POST['color'] ?? '');
    $paisOrigen = trim($_POST['pais_origen'] ?? '');
    $idPersona = !empty($_POST['id_persona']) ? (int) $_POST['id_persona'] : null;
    $numeroPermiso = trim($_POST['numero_permiso'] ?? '');
    $fechaEmision = $_POST['fecha_emision_permiso'] ?? '';
    $fechaEmision = $fechaEmision !== '' ? $fechaEmision : null;
    $fechaVencimiento = $_POST['fecha_vencimiento_permiso'] ?? '';
    $fechaVencimiento = $fechaVencimiento !== '' ? $fechaVencimiento : null;
    $estado = $_POST['estado'] ?? 'Activa';
    $idDenuncia = !empty($_POST['id_denuncia']) ? (int) $_POST['id_denuncia'] : null;
    $notas = trim($_POST['notas'] ?? '');

    if ($arma) {
        $stmt = $pdo->prepare(
            "UPDATE armas SET tipo=?, categoria_arma=?, numero_serie=?, marca=?, modelo=?, calibre=?, color=?,
                              pais_origen=?, id_persona=?, numero_permiso=?, fecha_emision_permiso=?,
                              fecha_vencimiento_permiso=?, estado=?, id_denuncia=?, notas=? WHERE id=?"
        );
        $stmt->execute([
            $tipo, $categoriaArma, $numeroSerie, $marca, $modelo, $calibre, $color, $paisOrigen,
            $idPersona, $numeroPermiso, $fechaEmision, $fechaVencimiento, $estado, $idDenuncia, $notas, $idArma,
        ]);
        flash('success', 'Arma / licencia actualizada.');
        redirigir('mdt/armas_ver.php', 'id=' . $idArma);
    } else {
        $stmt = $pdo->prepare(
            "INSERT INTO armas (tipo, categoria_arma, numero_serie, marca, modelo, calibre, color, pais_origen,
                                 id_persona, numero_permiso, fecha_emision_permiso, fecha_vencimiento_permiso,
                                 estado, id_denuncia, id_oficial_registra, notas, fecha_registro)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE())"
        );
        $stmt->execute([
            $tipo, $categoriaArma, $numeroSerie, $marca, $modelo, $calibre, $color, $paisOrigen,
            $idPersona, $numeroPermiso, $fechaEmision, $fechaVencimiento, $estado, $idDenuncia, $usuario['id'], $notas,
        ]);
        $nuevoId = (int) $pdo->lastInsertId();

        $stmt = $pdo->prepare(
            "INSERT INTO armas_historial (id_arma, tipo_evento, descripcion, id_persona_nueva, id_oficial, fecha)
             VALUES (?, 'Registro', 'Alta inicial del arma/licencia en el sistema.', ?, ?, NOW())"
        );
        $stmt->execute([$nuevoId, $idPersona, $usuario['id']]);

        flash('success', 'Arma / licencia registrada correctamente.');
        redirigir('mdt/armas_ver.php', 'id=' . $nuevoId);
    }
}

$tituloPagina = $arma ? 'Editar Arma / Licencia' : 'Nueva Arma / Licencia';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-record-circle"></i> <?= $arma ? 'Editar Arma / Licencia' : 'Nueva Arma / Licencia' ?></h3>

<?php if ($arma): ?>
<div class="alert alert-info">
  <i class="bi bi-info-circle"></i> Para ceder esta arma a otra persona o darla de baja, usá los botones de
  <a href="<?= rutaBase() ?>mdt/armas_ver.php?id=<?= $idArma ?>">la ficha de detalle</a> — así queda registrado en el historial.
  Este formulario es solo para corregir datos básicos.
</div>
<?php endif; ?>

<div class="card mdt-card p-4">
  <form method="POST">
    <?= csrfCampoOculto() ?>
    <h6 class="text-secondary">Datos del arma</h6>
    <div class="row">
      <div class="col-md-3 mb-3">
        <label class="form-label">Tipo</label>
        <select name="tipo" class="form-select">
          <option value="Permiso Civil" <?= (!$arma || $arma['tipo'] === 'Permiso Civil') ? 'selected' : '' ?>>Permiso Civil</option>
          <option value="Incautada" <?= ($arma && $arma['tipo'] === 'Incautada') ? 'selected' : '' ?>>Incautada</option>
        </select>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Categoría</label>
        <select name="categoria_arma" class="form-select">
          <option value="">Seleccionar...</option>
          <?php foreach ($categorias as $cat): ?>
          <option value="<?= $cat ?>" <?= ($arma && $arma['categoria_arma'] === $cat) ? 'selected' : '' ?>><?= $cat ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">N° de Serie</label>
        <input type="text" name="numero_serie" class="form-control" value="<?= escape($arma['numero_serie'] ?? '') ?>">
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Calibre</label>
        <input type="text" name="calibre" class="form-control" value="<?= escape($arma['calibre'] ?? '') ?>">
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Marca</label>
        <input type="text" name="marca" class="form-control" value="<?= escape($arma['marca'] ?? '') ?>">
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Modelo</label>
        <input type="text" name="modelo" class="form-control" value="<?= escape($arma['modelo'] ?? '') ?>">
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">Color</label>
        <input type="text" name="color" class="form-control" value="<?= escape($arma['color'] ?? '') ?>">
      </div>
      <div class="col-md-3 mb-3">
        <label class="form-label">País de origen</label>
        <input type="text" name="pais_origen" class="form-control" value="<?= escape($arma['pais_origen'] ?? '') ?>">
      </div>
    </div>

    <h6 class="text-secondary mt-3">Datos de la licencia</h6>
    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">N° de Permiso</label>
        <input type="text" name="numero_permiso" class="form-control" value="<?= escape($arma['numero_permiso'] ?? '') ?>">
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Fecha de emisión</label>
        <input type="date" name="fecha_emision_permiso" class="form-control" value="<?= escape($arma['fecha_emision_permiso'] ?? '') ?>">
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Fecha de vencimiento</label>
        <input type="date" name="fecha_vencimiento_permiso" class="form-control" value="<?= escape($arma['fecha_vencimiento_permiso'] ?? '') ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Persona (titular actual)</label>
        <select name="id_persona" class="form-select">
          <option value="">Ninguna</option>
          <?php foreach ($personas as $p): ?>
          <option value="<?= (int) $p['id'] ?>" <?= ($arma && (int) ($arma['id_persona'] ?? 0) === (int) $p['id']) ? 'selected' : '' ?>><?= escape($p['nombre']) ?> (<?= escape($p['dni'] ?: 'sin DNI') ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Estado</label>
        <select name="estado" class="form-select">
          <?php foreach ($estados as $e): ?>
          <option value="<?= escape($e) ?>" <?= ($arma && $arma['estado'] === $e) ? 'selected' : '' ?>><?= escape($e) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-12 mb-3">
        <label class="form-label">Denuncia vinculada (si fue incautada)</label>
        <select name="id_denuncia" class="form-select">
          <option value="">Ninguna</option>
          <?php foreach ($denuncias as $d): ?>
          <option value="<?= (int) $d['id'] ?>" <?= ($arma && (int) ($arma['id_denuncia'] ?? 0) === (int) $d['id']) ? 'selected' : '' ?>><?= escape($d['nro_caso']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Notas</label>
      <textarea name="notas" class="form-control" rows="3"><?= escape($arma['notas'] ?? '') ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Guardar</button>
    <a href="<?= rutaBase() ?>mdt/armas.php" class="btn btn-outline-light">Cancelar</a>
  </form>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
