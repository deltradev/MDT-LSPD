<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$usuario = usuarioActual();
$conId = isset($_GET['con']) ? (int) $_GET['con'] : null;

if ($conId) {
    $stmt = $pdo->prepare(
        "SELECT m.*, u.nombre AS remitente_nombre, u.apellido AS remitente_apellido
         FROM mensajes_internos m LEFT JOIN usuarios u ON m.id_remitente = u.id
         WHERE (m.id_remitente = ? AND m.id_destinatario = ?)
            OR (m.id_remitente = ? AND m.id_destinatario = ?)
         ORDER BY m.id ASC LIMIT 200"
    );
    $stmt->execute([$usuario['id'], $conId, $conId, $usuario['id']]);
} else {
    $stmt = $pdo->query(
        "SELECT m.*, u.nombre AS remitente_nombre, u.apellido AS remitente_apellido
         FROM mensajes_internos m LEFT JOIN usuarios u ON m.id_remitente = u.id
         WHERE m.id_destinatario IS NULL
         ORDER BY m.id ASC LIMIT 200"
    );
}
$mensajes = $stmt->fetchAll();

$data = array_map(function ($m) {
    return [
        'id' => (int) $m['id'],
        'remitente' => trim($m['remitente_nombre'] . ' ' . $m['remitente_apellido']),
        'id_remitente' => (int) $m['id_remitente'],
        'mensaje' => $m['mensaje'],
        'fecha' => $m['fecha'],
    ];
}, $mensajes);

header('Content-Type: application/json');
echo json_encode(['mensajes' => $data]);
