<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$idPersona = isset($_GET['id']) ? (int) $_GET['id'] : null;
$persona = null;
if ($idPersona) {
    $stmt = $pdo->prepare('SELECT * FROM personas WHERE id = ?');
    $stmt->execute([$idPersona]);
    $persona = $stmt->fetch();
    if (!$persona) {
        http_response_code(404);
        die('Persona no encontrada.');
    }
}
$bandas = $pdo->query('SELECT * FROM bandas ORDER BY nombre')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $dni = trim($_POST['dni'] ?? '');
    $alias = trim($_POST['alias'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $antecedentes = trim($_POST['antecedentes'] ?? '');
    $nivelAmenaza = $_POST['nivel_amenaza'] ?? 'Bajo';
    $esPublico = isset($_POST['es_publico']) ? 1 : 0;
    $idBanda = !empty($_POST['id_banda']) ? (int) $_POST['id_banda'] : null;

    $rutaFoto = $persona['foto'] ?? null;
    $nuevaFoto = subirArchivo('foto', 'investigaciones');
    if ($nuevaFoto !== null) {
        $rutaFoto = $nuevaFoto;
    }

    if ($persona) {
        $stmt = $pdo->prepare(
            "UPDATE personas SET nombre=?, dni=?, foto=?, alias=?, direccion=?, antecedentes=?,
                                  nivel_amenaza=?, es_publico=?, id_banda=? WHERE id=?"
        );
        $stmt->execute([$nombre, $dni, $rutaFoto, $alias, $direccion, $antecedentes, $nivelAmenaza, $esPublico, $idBanda, $idPersona]);
        flash('success', 'Persona actualizada.');
    } else {
        $stmt = $pdo->prepare(
            "INSERT INTO personas (nombre, dni, foto, alias, direccion, antecedentes, nivel_amenaza, es_publico, id_banda, fecha_registro)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE())"
        );
        $stmt->execute([$nombre, $dni, $rutaFoto, $alias, $direccion, $antecedentes, $nivelAmenaza, $esPublico, $idBanda]);
        flash('success', 'Persona registrada en la base criminal.');
    }
    redirigir('mdt/personas.php');
}

$tituloPagina = $persona ? 'Editar Persona' : 'Nueva Persona';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-person-lines-fill"></i> <?= $persona ? 'Editar Persona' : 'Nueva Persona' ?></h3>
<div class="card mdt-card p-4">
  <form method="POST" enctype="multipart/form-data">
    <?= csrfCampoOculto() ?>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Nombre completo</label>
        <input type="text" name="nombre" class="form-control" value="<?= escape($persona['nombre'] ?? '') ?>" required>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">DNI</label>
        <input type="text" name="dni" class="form-control" value="<?= escape($persona['dni'] ?? '') ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Alias</label>
        <input type="text" name="alias" class="form-control" value="<?= escape($persona['alias'] ?? '') ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Dirección</label>
        <input type="text" name="direccion" class="form-control" value="<?= escape($persona['direccion'] ?? '') ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Nivel de Amenaza</label>
        <select name="nivel_amenaza" class="form-select">
          <?php foreach (['Bajo', 'Medio', 'Alto', 'Extremo'] as $nivel): ?>
          <option value="<?= $nivel ?>" <?= ($persona && $persona['nivel_amenaza'] === $nivel) ? 'selected' : '' ?>><?= $nivel ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Banda vinculada</label>
        <select name="id_banda" class="form-select">
          <option value="">Ninguna</option>
          <?php foreach ($bandas as $b): ?>
          <option value="<?= (int) $b['id'] ?>" <?= ($persona && (int) ($persona['id_banda'] ?? 0) === (int) $b['id']) ? 'selected' : '' ?>><?= escape($b['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Antecedentes</label>
      <textarea name="antecedentes" class="form-control" rows="3"><?= escape($persona['antecedentes'] ?? '') ?></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Foto</label>
      <input type="file" name="foto" class="form-control">
    </div>
    <div class="form-check mb-3">
      <input class="form-check-input" type="checkbox" name="es_publico" id="esPublico" <?= ($persona && $persona['es_publico']) ? 'checked' : '' ?>>
      <label class="form-check-label" for="esPublico">Marcar como "Se Busca" (visible en portal público)</label>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Guardar</button>
    <a href="<?= rutaBase() ?>mdt/personas.php" class="btn btn-outline-light">Cancelar</a>
  </form>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
