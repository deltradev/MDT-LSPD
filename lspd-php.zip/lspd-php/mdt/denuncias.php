<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

$pdo = obtenerConexion();
$estadoFiltro = $_GET['estado'] ?? '';

if ($estadoFiltro !== '') {
    $stmt = $pdo->prepare('SELECT * FROM denuncias WHERE estado = ? ORDER BY id DESC');
    $stmt->execute([$estadoFiltro]);
} else {
    $stmt = $pdo->query('SELECT * FROM denuncias ORDER BY id DESC');
}
$denuncias = $stmt->fetchAll();
$estados = getEstados('denuncia');

$tituloPagina = 'Denuncias';
require __DIR__ . '/../includes/layout_mdt_top.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="text-light"><i class="bi bi-file-earmark-text"></i> Denuncias</h3>
  <a href="<?= rutaBase() ?>mdt/denuncias_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nueva Denuncia</a>
</div>

<form class="row g-2 mb-3" method="GET">
  <div class="col-auto">
    <select name="estado" class="form-select" onchange="this.form.submit()">
      <option value="">Todos los estados</option>
      <?php foreach ($estados as $e): ?>
      <option value="<?= escape($e) ?>" <?= $e === $estadoFiltro ? 'selected' : '' ?>><?= escape($e) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
</form>

<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>N° Caso</th><th>Tipo</th><th>Fecha</th><th>Lugar</th><th>Estado</th><th>Acciones</th></tr></thead>
    <tbody>
    <?php if (empty($denuncias)): ?>
      <tr><td colspan="6" class="text-secondary">No hay denuncias registradas.</td></tr>
    <?php else: ?>
      <?php foreach ($denuncias as $d): ?>
      <tr>
        <td><?= escape($d['nro_caso']) ?></td>
        <td><?= escape($d['tipo'] ?: '-') ?></td>
        <td><?= escape($d['fecha']) ?></td>
        <td><?= escape($d['lugar'] ?: '-') ?></td>
        <td><span class="badge bg-secondary"><?= escape($d['estado']) ?></span></td>
        <td>
          <a href="<?= rutaBase() ?>mdt/denuncias_ver.php?id=<?= (int) $d['id'] ?>" class="btn btn-sm btn-outline-info"><i class="bi bi-eye"></i></a>
          <a href="<?= rutaBase() ?>mdt/denuncias_form.php?id=<?= (int) $d['id'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
          <a href="<?= rutaBase() ?>mdt/denuncias_pdf.php?id=<?= (int) $d['id'] ?>" class="btn btn-sm btn-outline-light"><i class="bi bi-file-earmark-pdf"></i></a>
          <form method="POST" action="<?= rutaBase() ?>mdt/denuncias_eliminar.php" class="d-inline" onsubmit="return confirm('¿Eliminar esta denuncia?')">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_mdt_bottom.php'; ?>
