<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirMdt();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $id = (int) ($_POST['id'] ?? 0);

    $stmt = $pdo->prepare(
        "UPDATE investigaciones SET nombre=?, objetivo_tipo=?, objetivo_id=?, descripcion=?, categoria=?, estado=? WHERE id=?"
    );
    $stmt->execute([
        trim($_POST['nombre'] ?? ''),
        $_POST['objetivo_tipo'] ?? '',
        !empty($_POST['objetivo_id']) ? (int) $_POST['objetivo_id'] : null,
        trim($_POST['descripcion'] ?? ''),
        $_POST['categoria'] ?? '',
        $_POST['estado'] ?? 'Abierta',
        $id,
    ]);

    flash('success', 'Investigación actualizada.');
    redirigir('mdt/investigaciones_ver.php', 'id=' . $id);
}

redirigir('mdt/investigaciones.php');
