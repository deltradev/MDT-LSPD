<?php
/**
 * descargar.php
 * Sirve archivos de la carpeta uploads/ (denuncias, investigaciones, CVs
 * de postulaciones) verificando primero que el usuario tenga permiso.
 * Equivalente a la ruta /uploads/<path> de la versión Flask.
 *
 * Uso: descargar.php?f=denuncias/3/foto.jpg
 */

require_once __DIR__ . '/includes/bootstrap.php';

$f = $_GET['f'] ?? '';

if ($f === '') {
    http_response_code(404);
    die('Archivo no especificado.');
}

// Evitar path traversal (../../etc/passwd, etc.)
$rutaCompleta = realpath(UPLOAD_DIR . '/' . $f);
$raizUploads = realpath(UPLOAD_DIR);

if ($rutaCompleta === false || $raizUploads === false || strpos($rutaCompleta, $raizUploads) !== 0) {
    http_response_code(403);
    die('Acceso denegado.');
}

if (!is_file($rutaCompleta)) {
    http_response_code(404);
    die('Archivo no encontrado.');
}

// Personal LSPD siempre puede ver cualquier archivo. Alguien sin login (o
// un Civil) solo puede ver la FOTO de una persona/banda que esté marcada
// explícitamente como "Público" (para que funcione en /public/se_busca.php).
// Todo lo demás (adjuntos de denuncias, investigaciones, CVs) sigue
// restringido exclusivamente a personal LSPD.
$usuario = usuarioActual();
$esLspd = $usuario && in_array($usuario['rol'], ROLES_LSPD, true);

if (!$esLspd) {
    $pdo = obtenerConexion();
    $esFotoPublica = false;

    $stmt = $pdo->prepare('SELECT id FROM personas WHERE foto = ? AND es_publico = 1');
    $stmt->execute([$f]);
    if ($stmt->fetch()) {
        $esFotoPublica = true;
    }

    if (!$esFotoPublica) {
        $stmt = $pdo->prepare('SELECT id FROM bandas WHERE foto = ? AND es_publico = 1');
        $stmt->execute([$f]);
        if ($stmt->fetch()) {
            $esFotoPublica = true;
        }
    }

    if (!$esFotoPublica) {
        http_response_code(403);
        require __DIR__ . '/public/403.php';
        exit;
    }
}

$mime = mime_content_type($rutaCompleta) ?: 'application/octet-stream';
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($rutaCompleta));
header('Content-Disposition: inline; filename="' . basename($rutaCompleta) . '"');
readfile($rutaCompleta);
exit;
