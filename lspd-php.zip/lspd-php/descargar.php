<?php
/**
 * descargar.php
 * Sirve archivos de la carpeta uploads/ (denuncias, investigaciones, CVs
 * de postulaciones) verificando primero que el usuario tenga permiso.
 * Equivalente a la ruta /uploads/<path> de la versión Flask.
 *
 * Uso: descargar.php?f=denuncias/3/foto.jpg
 */

require_once __DIR__ . '/includes/bootstrap.php';

$f = $_GET['f'] ?? '';

if ($f === '') {
    http_response_code(404);
    die('Archivo no especificado.');
}

// Evitar path traversal (../../etc/passwd, etc.)
$rutaCompleta = realpath(UPLOAD_DIR . '/' . $f);
$raizUploads = realpath(UPLOAD_DIR);

if ($rutaCompleta === false || $raizUploads === false || strpos($rutaCompleta, $raizUploads) !== 0) {
    http_response_code(403);
    die('Acceso denegado.');
}

if (!is_file($rutaCompleta)) {
    http_response_code(404);
    die('Archivo no encontrado.');
}

// Solo personal LSPD puede ver adjuntos de denuncias/investigaciones/CVs.
$usuario = usuarioActual();
if (!$usuario || !in_array($usuario['rol'], ROLES_LSPD, true)) {
    http_response_code(403);
    require __DIR__ . '/public/403.php';
    exit;
}

$mime = mime_content_type($rutaCompleta) ?: 'application/octet-stream';
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($rutaCompleta));
header('Content-Disposition: inline; filename="' . basename($rutaCompleta) . '"');
readfile($rutaCompleta);
exit;
