<?php
/**
 * index.php (raíz del sitio)
 * El portal público real vive en public/index.php. Este archivo solo
 * existe para que al entrar a tu dominio (https://tudominio.com/) sin
 * ninguna ruta específica, el visitante llegue ahí en vez de toparse con
 * un error 403 (Apache no tiene qué mostrar en la raíz si no hay ningún
 * archivo índice y el listado de carpetas está deshabilitado).
 */
header('Location: public/index.php');
exit;
