<?php
require_once __DIR__ . '/../includes/bootstrap.php';

$tituloPagina = 'No encontrado';
require __DIR__ . '/../includes/layout_public_top.php';
?>
<div class="text-center py-5">
  <i class="bi bi-question-circle display-1 text-secondary"></i>
  <h2 class="mt-3">404 - Página no encontrada</h2>
  <p class="text-muted">El recurso que buscas no existe o fue movido.</p>
  <a href="<?= rutaBase() ?>public/index.php" class="btn btn-primary">Volver al inicio</a>
</div>
<?php require __DIR__ . '/../includes/layout_public_bottom.php'; ?>
