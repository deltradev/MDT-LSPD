<?php
require_once __DIR__ . '/../includes/bootstrap.php';

$activas = getConfig('postulaciones_activas', '1') === '1';
$formUrl = trim(getConfig('postulaciones_form_url', ''));

$tituloPagina = 'Postulaciones';
require __DIR__ . '/../includes/layout_public_top.php';
?>

<h3 class="mb-4"><i class="bi bi-person-badge"></i> Postúlate al LSPD</h3>

<?php if (!$activas): ?>
  <div class="alert alert-warning">
    <i class="bi bi-lock-fill"></i>
    <strong>Las postulaciones están cerradas por el momento.</strong>
    Vuelve a intentarlo más adelante o mantente atento a nuestras
    <a href="<?= rutaBase() ?>public/index.php">noticias y anuncios</a> para saber cuándo se reabren.
  </div>

<?php elseif ($formUrl === ''): ?>
  <div class="alert alert-info">
    <i class="bi bi-info-circle"></i>
    Las postulaciones están abiertas, pero el formulario aún no fue configurado.
    Contacta a la administración del departamento.
  </div>

<?php else: ?>
  <div class="card shadow-sm mb-3">
    <div class="card-body p-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
      <span><i class="bi bi-check-circle-fill text-success"></i> Las postulaciones se encuentran <strong>abiertas</strong>.</span>
      <a href="<?= escape($formUrl) ?>" target="_blank" rel="noopener" class="btn btn-outline-primary btn-sm">
        <i class="bi bi-box-arrow-up-right"></i> Abrir formulario en una pestaña nueva
      </a>
    </div>
  </div>

  <div class="ratio ratio-4x3 postulacion-embed">
    <iframe src="<?= escape($formUrl) ?>" title="Formulario de postulación LSPD" frameborder="0" marginheight="0" marginwidth="0">
      Cargando formulario…
    </iframe>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/../includes/layout_public_bottom.php'; ?>
