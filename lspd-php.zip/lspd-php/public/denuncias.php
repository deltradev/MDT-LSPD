<?php
require_once __DIR__ . '/../includes/bootstrap.php';

rateLimit('denuncia_publica', 8, 60);

$pdo = obtenerConexion();
$usuario = usuarioActual();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificarTurnstile($_POST['cf-turnstile-response'] ?? '')) {
        flash('danger', 'Verificación de seguridad fallida. Por favor, completa el CAPTCHA e inténtalo de nuevo.');
    } else {
        $tipo = trim($_POST['tipo'] ?? '');
        $lugar = trim($_POST['lugar'] ?? '');
        $denunciante = trim($_POST['denunciante'] ?? '') ?: 'Anónimo';
        $denunciadoDni = trim($_POST['denunciado_dni'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');

        if ($descripcion === '') {
            flash('danger', 'La descripción de la denuncia es obligatoria.');
        } else {
            $nroCaso = generarNumeroCaso('DEN', 'denuncias');
            $idCivil = $usuario ? $usuario['id'] : null;

            $stmt = $pdo->prepare(
                "INSERT INTO denuncias (nro_caso, tipo, fecha, lugar, denunciante, denunciado_dni,
                                        descripcion, estado, id_civil_creador, fecha_creacion, es_publica)
                 VALUES (?, ?, CURDATE(), ?, ?, ?, ?, 'Pendiente', ?, NOW(), 0)"
            );
            $stmt->execute([$nroCaso, $tipo, $lugar, $denunciante, $denunciadoDni, $descripcion, $idCivil]);
            $denunciaId = (int) $pdo->lastInsertId();

            $rutaArchivo = subirArchivo('archivo', 'denuncias/' . $denunciaId);
            if ($rutaArchivo !== null) {
                $stmt = $pdo->prepare('INSERT INTO archivos_denuncia (id_denuncia, nombre_archivo, ruta) VALUES (?, ?, ?)');
                $stmt->execute([$denunciaId, basename($rutaArchivo), $rutaArchivo]);
            }

            flash('success', "Tu denuncia fue registrada con el número de caso {$nroCaso}.");
            redirigir('public/denuncias.php');
        }
    }
}

$misDenuncias = [];
if ($usuario) {
    $stmt = $pdo->prepare('SELECT * FROM denuncias WHERE id_civil_creador = ? ORDER BY id DESC');
    $stmt->execute([$usuario['id']]);
    $misDenuncias = $stmt->fetchAll();
}

$tituloPagina = 'Denuncias Ciudadanas';
require __DIR__ . '/../includes/layout_public_top.php';
?>

<h3 class="mb-4"><i class="bi bi-file-earmark-text"></i> Denuncia Ciudadana</h3>
<div class="row">
  <div class="col-md-7">
    <div class="card shadow-sm mb-4">
      <div class="card-body p-4">
        <form method="POST" enctype="multipart/form-data">
          <?= csrfCampoOculto() ?>
          <div class="mb-3">
            <label class="form-label">Tipo de incidente</label>
            <input type="text" name="tipo" class="form-control" placeholder="Ej: Robo, Vandalismo...">
          </div>
          <div class="mb-3">
            <label class="form-label">Lugar del incidente</label>
            <input type="text" name="lugar" class="form-control">
          </div>
          <div class="mb-3">
            <label class="form-label">Tu nombre (opcional, puedes dejarlo anónimo)</label>
            <input type="text" name="denunciante" class="form-control" placeholder="Anónimo">
          </div>
          <div class="mb-3">
            <label class="form-label">DNI del denunciado (si lo conoces)</label>
            <input type="text" name="denunciado_dni" class="form-control">
          </div>
          <div class="mb-3">
            <label class="form-label">Descripción de los hechos</label>
            <textarea name="descripcion" class="form-control" rows="5" required></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Adjuntar evidencia (foto/documento)</label>
            <input type="file" name="archivo" class="form-control">
          </div>
          <?php if (turnstileHabilitado()): ?>
          <div class="mb-3 cf-turnstile" data-sitekey="<?= escape(TURNSTILE_SITE_KEY) ?>"></div>
          <?php endif; ?>
          <button type="submit" class="btn btn-primary w-100"><i class="bi bi-send"></i> Enviar Denuncia</button>
        </form>
      </div>
    </div>
  </div>
  <div class="col-md-5">
    <?php if ($usuario): ?>
    <h5>Mis denuncias</h5>
    <div class="list-group">
      <?php if (empty($misDenuncias)): ?>
        <p class="text-muted">Aún no has registrado denuncias.</p>
      <?php else: ?>
        <?php foreach ($misDenuncias as $d): ?>
        <div class="list-group-item">
          <div class="d-flex justify-content-between">
            <strong><?= escape($d['nro_caso']) ?></strong>
            <span class="badge bg-secondary"><?= escape($d['estado']) ?></span>
          </div>
          <small class="text-muted"><?= escape($d['fecha']) ?> — <?= escape($d['tipo'] ?: 'Sin tipo') ?></small>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="alert alert-info">
      <i class="bi bi-info-circle"></i> Inicia sesión para ver el historial de tus denuncias.
    </div>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/../includes/layout_public_bottom.php'; ?>
