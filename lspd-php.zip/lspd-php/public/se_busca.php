<?php
require_once __DIR__ . '/../includes/bootstrap.php';

$pdo = obtenerConexion();
$personas = $pdo->query("SELECT * FROM personas WHERE es_publico = 1 ORDER BY id DESC")->fetchAll();
$bandas = $pdo->query("SELECT * FROM bandas WHERE es_publico = 1 ORDER BY id DESC")->fetchAll();

$tituloPagina = 'Se Busca';
require __DIR__ . '/../includes/layout_public_top.php';
?>

<h3 class="mb-4"><i class="bi bi-person-bounding-box"></i> Personas y Bandas Buscadas</h3>

<h5 class="mt-4">Individuos</h5>
<div class="row g-4 mb-5">
  <?php if (empty($personas)): ?>
    <p class="text-muted">No hay personas marcadas como públicas actualmente.</p>
  <?php else: ?>
    <?php foreach ($personas as $p): ?>
    <div class="col-md-3">
      <div class="card h-100 shadow-sm wanted-card">
        <div class="card-body text-center">
          <i class="bi bi-person-fill display-4 text-danger"></i>
          <h5 class="card-title mt-2"><?= escape($p['nombre']) ?></h5>
          <?php if ($p['alias']): ?><p class="text-muted small">Alias: "<?= escape($p['alias']) ?>"</p><?php endif; ?>
          <span class="badge bg-danger">Amenaza: <?= escape($p['nivel_amenaza']) ?></span>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<h5 class="mt-4">Bandas</h5>
<div class="row g-4">
  <?php if (empty($bandas)): ?>
    <p class="text-muted">No hay bandas marcadas como públicas actualmente.</p>
  <?php else: ?>
    <?php foreach ($bandas as $b): ?>
    <div class="col-md-3">
      <div class="card h-100 shadow-sm wanted-card">
        <div class="card-body text-center">
          <i class="bi bi-people-fill display-4 text-warning"></i>
          <h5 class="card-title mt-2"><?= escape($b['nombre']) ?></h5>
          <?php if ($b['tag']): ?><p class="text-muted small">Tag: <?= escape($b['tag']) ?></p><?php endif; ?>
          <span class="badge bg-warning text-dark">Peligro: <?= escape($b['nivel_peligro']) ?></span>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/layout_public_bottom.php'; ?>
