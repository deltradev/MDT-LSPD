<?php
require_once __DIR__ . '/../includes/bootstrap.php';

$pdo = obtenerConexion();
$noticias = $pdo->query(
    "SELECT * FROM noticias WHERE publicado = 1 ORDER BY fecha DESC LIMIT 6"
)->fetchAll();

$tituloPagina = 'Inicio';
require __DIR__ . '/../includes/layout_public_top.php';
?>

<div class="hero-banner rounded-4 p-5 mb-5 text-center">
  <h1 class="display-5 fw-bold"><?= escape($cfgPublic['nombre_departamento'] ?? 'Los Santos Police Department') ?></h1>
  <p class="lead"><?= escape($cfgPublic['banner_texto'] ?? '') ?></p>
  <div class="mt-3">
    <a href="<?= rutaBase() ?>public/postulaciones.php" class="btn btn-primary btn-lg me-2"><i class="bi bi-person-badge"></i> Postula al LSPD</a>
    <a href="<?= rutaBase() ?>public/denuncias.php" class="btn btn-outline-dark btn-lg"><i class="bi bi-file-earmark-text"></i> Realizar Denuncia</a>
  </div>
</div>

<h3 class="mb-3"><i class="bi bi-newspaper"></i> Noticias y Anuncios</h3>
<div class="row g-4">
  <?php if (empty($noticias)): ?>
    <p class="text-muted">No hay noticias publicadas por el momento.</p>
  <?php else: ?>
    <?php foreach ($noticias as $n): ?>
    <div class="col-md-4">
      <div class="card h-100 shadow-sm noticia-card">
        <div class="card-body">
          <h5 class="card-title"><?= escape($n['titulo']) ?></h5>
          <p class="card-text text-muted small"><?= escape($n['fecha']) ?></p>
          <p class="card-text"><?= nl2br(escape($n['contenido'])) ?></p>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/layout_public_bottom.php'; ?>
