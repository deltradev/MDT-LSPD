<?php
require_once __DIR__ . '/../includes/bootstrap.php';

rateLimit('login', 10, 60);

const MAX_INTENTOS_FALLIDOS = 5;
const BLOQUEO_MINUTOS = 15;

$pdo = obtenerConexion();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificarTurnstile($_POST['cf-turnstile-response'] ?? '')) {
        flash('danger', 'Verificación de seguridad fallida. Por favor, completa el CAPTCHA e inténtalo de nuevo.');
    } else {
        $placa = trim($_POST['placa'] ?? '');
        $password = (string) ($_POST['password'] ?? '');

        $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE placa = ?');
        $stmt->execute([$placa]);
        $user = $stmt->fetch();

        $bloqueado = false;
        if ($user && $user['bloqueado_hasta']) {
            $bloqueadoHasta = new DateTime($user['bloqueado_hasta']);
            if (new DateTime() < $bloqueadoHasta) {
                $bloqueado = true;
                $minutosRestantes = max(1, (int) ceil((($bloqueadoHasta->getTimestamp() - time()) / 60)));
                flash('danger', "Cuenta bloqueada temporalmente por varios intentos fallidos. Intenta de nuevo en {$minutosRestantes} minuto(s).");
            }
        }

        if (!$bloqueado && $user && (int) $user['activo'] === 1 && password_verify($password, $user['password_hash'])) {
            $upd = $pdo->prepare('UPDATE usuarios SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id = ?');
            $upd->execute([$user['id']]);

            $_SESSION['usuario'] = [
                'id' => (int) $user['id'],
                'placa' => $user['placa'],
                'nombre' => $user['nombre'],
                'apellido' => $user['apellido'],
                'rol' => $user['rol'],
            ];
            logAccion($user['id'], 'Inicio de sesión');
            flash('success', "Bienvenido, {$user['nombre']}.");

            $siguiente = $_GET['next'] ?? '';
            $siguienteEsSegura = (bool) preg_match('#^/[A-Za-z0-9_\-/\.]*\.php(\?.*)?$#', $siguiente);

            if ($user['rol'] === ROL_CIVIL) {
                if ($siguienteEsSegura && strpos($siguiente, '/mdt/') === false && strpos($siguiente, '/admin/') === false) {
                    header('Location: ' . $siguiente);
                } else {
                    header('Location: ' . rutaBase() . 'public/index.php');
                }
            } else {
                header('Location: ' . ($siguienteEsSegura ? $siguiente : rutaBase() . 'mdt/dashboard.php'));
            }
            exit;
        } elseif (!$bloqueado) {
            if ($user) {
                $intentos = (int) $user['intentos_fallidos'] + 1;
                $bloqueadoHastaValor = null;
                if ($intentos >= MAX_INTENTOS_FALLIDOS) {
                    $bloqueadoHastaValor = (new DateTime())->modify('+' . BLOQUEO_MINUTOS . ' minutes')->format('Y-m-d H:i:s');
                    $intentos = 0;
                }
                $upd = $pdo->prepare('UPDATE usuarios SET intentos_fallidos = ?, bloqueado_hasta = ? WHERE id = ?');
                $upd->execute([$intentos, $bloqueadoHastaValor, $user['id']]);
                logAccion($user['id'], 'Intento de login fallido');

                if ($bloqueadoHastaValor) {
                    flash('danger', 'Demasiados intentos fallidos. Cuenta bloqueada por ' . BLOQUEO_MINUTOS . ' minutos.');
                } else {
                    flash('danger', 'Placa o contraseña incorrectos.');
                }
            } else {
                flash('danger', 'Placa o contraseña incorrectos.');
            }
        }
    }
}

$tituloPagina = 'Iniciar sesión';
require __DIR__ . '/../includes/layout_public_top.php';
?>

<div class="row justify-content-center">
  <div class="col-md-5">
    <div class="card shadow-sm">
      <div class="card-body p-4">
        <h4 class="mb-4 text-center"><i class="bi bi-box-arrow-in-right"></i> Iniciar sesión</h4>
        <form method="POST">
          <?= csrfCampoOculto() ?>
          <div class="mb-3">
            <label class="form-label">Placa / DNI</label>
            <input type="text" name="placa" class="form-control" required autofocus>
          </div>
          <div class="mb-3">
            <label class="form-label">Contraseña</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <?php if (turnstileHabilitado()): ?>
          <div class="mb-3 cf-turnstile" data-sitekey="<?= escape(TURNSTILE_SITE_KEY) ?>"></div>
          <?php endif; ?>
          <button type="submit" class="btn btn-primary w-100">Ingresar</button>
        </form>
        <p class="text-center mt-3 mb-0">¿No tienes cuenta? <a href="<?= rutaBase() ?>public/registro.php">Regístrate aquí</a></p>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/layout_public_bottom.php'; ?>
