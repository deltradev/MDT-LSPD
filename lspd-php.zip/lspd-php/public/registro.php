<?php
require_once __DIR__ . '/../includes/bootstrap.php';

rateLimit('registro', 5, 60);

$pdo = obtenerConexion();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificarTurnstile($_POST['cf-turnstile-response'] ?? '')) {
        flash('danger', 'Verificación de seguridad fallida. Por favor, completa el CAPTCHA e inténtalo de nuevo.');
    } else {
        $placa = trim($_POST['placa'] ?? '');
        $nombre = trim($_POST['nombre'] ?? '');
        $apellido = trim($_POST['apellido'] ?? '');
        $password = (string) ($_POST['password'] ?? '');
        $password2 = (string) ($_POST['password2'] ?? '');

        if ($placa === '' || $nombre === '' || $apellido === '' || $password === '') {
            flash('danger', 'Todos los campos son obligatorios.');
        } elseif ($password !== $password2) {
            flash('danger', 'Las contraseñas no coinciden.');
        } else {
            $stmt = $pdo->prepare('SELECT id FROM usuarios WHERE placa = ?');
            $stmt->execute([$placa]);
            if ($stmt->fetch()) {
                flash('danger', 'Ese DNI/Placa ya está registrado.');
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare(
                    "INSERT INTO usuarios (placa, nombre, apellido, password_hash, rol, fecha_ingreso, activo)
                     VALUES (?, ?, ?, ?, 'Civil', CURDATE(), 1)"
                );
                $stmt->execute([$placa, $nombre, $apellido, $hash]);
                flash('success', 'Registro exitoso. Ya puedes iniciar sesión.');
                redirigir('public/login.php');
            }
        }
    }
}

$tituloPagina = 'Registro';
require __DIR__ . '/../includes/layout_public_top.php';
?>

<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card shadow-sm">
      <div class="card-body p-4">
        <h4 class="mb-4 text-center"><i class="bi bi-person-plus"></i> Crear cuenta de Civil</h4>
        <form method="POST">
          <?= csrfCampoOculto() ?>
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Nombre</label>
              <input type="text" name="nombre" class="form-control" required>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Apellido</label>
              <input type="text" name="apellido" class="form-control" required>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label">DNI</label>
            <input type="text" name="placa" class="form-control" required>
          </div>
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Contraseña</label>
              <input type="password" name="password" class="form-control" required>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Repetir contraseña</label>
              <input type="password" name="password2" class="form-control" required>
            </div>
          </div>
          <?php if (turnstileHabilitado()): ?>
          <div class="mb-3 cf-turnstile" data-sitekey="<?= escape(TURNSTILE_SITE_KEY) ?>"></div>
          <?php endif; ?>
          <button type="submit" class="btn btn-primary w-100">Registrarme</button>
        </form>
        <p class="text-center mt-3 mb-0">¿Ya tienes cuenta? <a href="<?= rutaBase() ?>public/login.php">Inicia sesión</a></p>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/layout_public_bottom.php'; ?>
