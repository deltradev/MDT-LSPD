<?php
// Este archivo es incluido directamente por requerirRol() en includes/auth.php
// cuando un usuario sin permiso intenta acceder a /mdt o /admin. No se
// visita nunca por URL directa, así que no vuelve a llamar a bootstrap.php
// (ya está cargado por quien lo incluye).
$tituloPagina = 'Acceso Denegado';
require __DIR__ . '/../includes/layout_public_top.php';
?>
<div class="text-center py-5">
  <i class="bi bi-shield-lock display-1 text-danger"></i>
  <h2 class="mt-3">403 - Acceso Denegado</h2>
  <p class="text-muted">No tienes permisos para acceder a esta sección. Esta área es exclusiva para personal del LSPD.</p>
  <a href="<?= rutaBase() ?>public/index.php" class="btn btn-primary">Volver al inicio</a>
</div>
<?php require __DIR__ . '/../includes/layout_public_bottom.php'; ?>
