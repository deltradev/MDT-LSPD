<?php
require_once __DIR__ . '/../includes/bootstrap.php';

$usuario = usuarioActual();
if ($usuario) {
    logAccion($usuario['id'], 'Cierre de sesión');
}
unset($_SESSION['usuario']);
flash('info', 'Sesión cerrada correctamente.');
redirigir('public/index.php');
