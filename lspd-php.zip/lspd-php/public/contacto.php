<?php
require_once __DIR__ . '/../includes/bootstrap.php';

rateLimit('contacto', 8, 60);

$pdo = obtenerConexion();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificarTurnstile($_POST['cf-turnstile-response'] ?? '')) {
        flash('danger', 'Verificación de seguridad fallida. Por favor, completa el CAPTCHA e inténtalo de nuevo.');
    } else {
        $nombre = trim($_POST['nombre'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $mensaje = trim($_POST['mensaje'] ?? '');

        if ($nombre === '' || $email === '' || $mensaje === '') {
            flash('danger', 'Completa todos los campos.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO contactos (nombre, email, mensaje, fecha, leido) VALUES (?, ?, ?, NOW(), 0)');
            $stmt->execute([$nombre, $email, $mensaje]);
            flash('success', 'Tu mensaje fue enviado. Nos pondremos en contacto pronto.');
            redirigir('public/contacto.php');
        }
    }
}

$tituloPagina = 'Contacto';
require __DIR__ . '/../includes/layout_public_top.php';
?>

<h3 class="mb-4"><i class="bi bi-envelope"></i> Contacto</h3>
<div class="row justify-content-center">
  <div class="col-md-7">
    <div class="card shadow-sm">
      <div class="card-body p-4">
        <form method="POST">
          <?= csrfCampoOculto() ?>
          <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" name="nombre" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Mensaje</label>
            <textarea name="mensaje" class="form-control" rows="5" required></textarea>
          </div>
          <?php if (turnstileHabilitado()): ?>
          <div class="mb-3 cf-turnstile" data-sitekey="<?= escape(TURNSTILE_SITE_KEY) ?>"></div>
          <?php endif; ?>
          <button type="submit" class="btn btn-primary w-100"><i class="bi bi-send"></i> Enviar Mensaje</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/layout_public_bottom.php'; ?>
