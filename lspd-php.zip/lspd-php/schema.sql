-- ============================================================
-- schema.sql — LSPD CMS (versión PHP + MySQL para ByetHost)
-- ============================================================
-- Importar este archivo UNA SOLA VEZ desde phpMyAdmin (pestaña
-- "Importar" de tu base de datos en el panel de ByetHost).
-- Crea todas las tablas y siembra los datos iniciales (usuario
-- admin, categorías, estados, configuración).
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = "+00:00";

-- ------------------------------------------------------------
-- USUARIOS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    placa VARCHAR(50) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    rol VARCHAR(30) NOT NULL DEFAULT 'Civil',
    fecha_ingreso DATE NOT NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    intentos_fallidos INT NOT NULL DEFAULT 0,
    bloqueado_hasta DATETIME NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- CATEGORÍAS Y ESTADOS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categorias_denuncia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categorias_investigacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categorias_multa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL,
    monto_sugerido DECIMAL(10,2) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS estados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(30) NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    UNIQUE KEY uniq_tipo_nombre (tipo, nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS configuracion (
    clave VARCHAR(100) PRIMARY KEY,
    valor TEXT,
    seccion VARCHAR(30)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- DENUNCIAS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS denuncias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nro_caso VARCHAR(50) UNIQUE NOT NULL,
    tipo VARCHAR(100),
    fecha DATE NOT NULL,
    lugar VARCHAR(255),
    denunciante VARCHAR(150),
    denunciado_dni VARCHAR(50),
    descripcion TEXT,
    estado VARCHAR(50) NOT NULL DEFAULT 'Pendiente',
    id_oficial INT NULL,
    id_civil_creador INT NULL,
    fecha_creacion DATETIME NOT NULL,
    es_publica TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (id_oficial) REFERENCES usuarios(id) ON DELETE SET NULL,
    FOREIGN KEY (id_civil_creador) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS archivos_denuncia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_denuncia INT NOT NULL,
    nombre_archivo VARCHAR(255) NOT NULL,
    ruta VARCHAR(500) NOT NULL,
    FOREIGN KEY (id_denuncia) REFERENCES denuncias(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- BASE DE DATOS CRIMINAL
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bandas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    tag VARCHAR(50),
    lider VARCHAR(150),
    territorio VARCHAR(150),
    actividades TEXT,
    nivel_peligro VARCHAR(30) DEFAULT 'Bajo',
    foto VARCHAR(500),
    es_publico TINYINT(1) NOT NULL DEFAULT 0,
    fecha_registro DATE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS personas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    dni VARCHAR(50),
    foto VARCHAR(500),
    alias VARCHAR(150),
    direccion VARCHAR(255),
    antecedentes TEXT,
    nivel_amenaza VARCHAR(30) DEFAULT 'Bajo',
    es_publico TINYINT(1) NOT NULL DEFAULT 0,
    id_banda INT NULL,
    fecha_registro DATE,
    FOREIGN KEY (id_banda) REFERENCES bandas(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- INVESTIGACIONES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS investigaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nro_operacion VARCHAR(50) UNIQUE NOT NULL,
    nombre VARCHAR(200) NOT NULL,
    objetivo_tipo VARCHAR(30),
    objetivo_id INT NULL,
    descripcion TEXT,
    categoria VARCHAR(100),
    estado VARCHAR(50) NOT NULL DEFAULT 'Abierta',
    id_oficial_cargo INT NULL,
    fecha_inicio DATE NOT NULL,
    FOREIGN KEY (id_oficial_cargo) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notas_investigacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_investigacion INT NOT NULL,
    nota TEXT,
    id_oficial INT NULL,
    fecha DATETIME NOT NULL,
    archivo_adjunto VARCHAR(500),
    FOREIGN KEY (id_investigacion) REFERENCES investigaciones(id) ON DELETE CASCADE,
    FOREIGN KEY (id_oficial) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- MULTAS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS multas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_persona INT NULL,
    nombre_infractor VARCHAR(150),
    dni_infractor VARCHAR(50),
    motivo VARCHAR(200) NOT NULL,
    monto DECIMAL(10,2) NOT NULL DEFAULT 0,
    id_oficial INT NULL,
    fecha DATE NOT NULL,
    estado VARCHAR(50) NOT NULL DEFAULT 'Pendiente',
    FOREIGN KEY (id_persona) REFERENCES personas(id) ON DELETE SET NULL,
    FOREIGN KEY (id_oficial) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- REGISTRO DE ARMAS Y LICENCIAS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS armas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(30) NOT NULL,               -- 'Permiso Civil' | 'Incautada'
    categoria_arma VARCHAR(50),              -- Pistola, Revólver, Rifle, Escopeta, Subfusil, Otro
    numero_serie VARCHAR(100),
    marca VARCHAR(100),
    modelo VARCHAR(100),
    calibre VARCHAR(50),
    color VARCHAR(50),
    pais_origen VARCHAR(100),
    id_persona INT NULL,                     -- portador/titular ACTUAL de la licencia
    numero_permiso VARCHAR(100),
    fecha_emision_permiso DATE NULL,
    fecha_vencimiento_permiso DATE NULL,
    estado VARCHAR(30) NOT NULL DEFAULT 'Activa',  -- Activa, Vencida, Cedida, Retirada, Incautada, Destruida
    id_denuncia INT NULL,
    id_oficial_registra INT NULL,
    notas TEXT,
    -- Datos de baja / retiro (si estado = 'Retirada')
    motivo_baja VARCHAR(255) NULL,
    fecha_baja DATE NULL,
    id_oficial_baja INT NULL,
    fecha_registro DATE NOT NULL,
    FOREIGN KEY (id_persona) REFERENCES personas(id) ON DELETE SET NULL,
    FOREIGN KEY (id_denuncia) REFERENCES denuncias(id) ON DELETE SET NULL,
    FOREIGN KEY (id_oficial_registra) REFERENCES usuarios(id) ON DELETE SET NULL,
    FOREIGN KEY (id_oficial_baja) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Historial de eventos de cada arma/licencia: registro, renovación, cesión,
-- retiro, incautación, reactivación, etc. Deja trazabilidad completa de
-- quién tuvo la licencia y qué pasó con ella a lo largo del tiempo.
CREATE TABLE IF NOT EXISTS armas_historial (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_arma INT NOT NULL,
    tipo_evento VARCHAR(30) NOT NULL,        -- Registro, Renovación, Cesión, Retiro, Incautación, Reactivación, Otro
    descripcion TEXT,
    id_persona_anterior INT NULL,
    id_persona_nueva INT NULL,
    id_oficial INT NULL,
    fecha DATETIME NOT NULL,
    FOREIGN KEY (id_arma) REFERENCES armas(id) ON DELETE CASCADE,
    FOREIGN KEY (id_persona_anterior) REFERENCES personas(id) ON DELETE SET NULL,
    FOREIGN KEY (id_persona_nueva) REFERENCES personas(id) ON DELETE SET NULL,
    FOREIGN KEY (id_oficial) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- ARRESTOS / DETENCIONES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS arrestos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nro_arresto VARCHAR(50) UNIQUE NOT NULL,
    id_persona INT NULL,
    nombre_detenido VARCHAR(150),
    dni_detenido VARCHAR(50),
    cargos TEXT,
    fianza DECIMAL(10,2) DEFAULT 0,
    estado_judicial VARCHAR(50) NOT NULL DEFAULT 'Detenido',
    id_denuncia INT NULL,
    id_oficial INT NULL,
    notas TEXT,
    duracion_minutos INT NULL,           -- duración de la condena, en minutos
    inicio_condena DATETIME NULL,        -- momento exacto en que arrancó a correr el tiempo
    fecha DATE NOT NULL,
    FOREIGN KEY (id_persona) REFERENCES personas(id) ON DELETE SET NULL,
    FOREIGN KEY (id_denuncia) REFERENCES denuncias(id) ON DELETE SET NULL,
    FOREIGN KEY (id_oficial) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- ASUNTOS INTERNOS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sanciones_internas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_oficial_investigado INT NOT NULL,
    id_oficial_reporta INT NULL,
    motivo VARCHAR(200) NOT NULL,
    descripcion TEXT,
    estado VARCHAR(50) NOT NULL DEFAULT 'Pendiente',
    medida_aplicada VARCHAR(200),
    fecha DATE NOT NULL,
    fecha_resolucion DATE NULL,
    FOREIGN KEY (id_oficial_investigado) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_oficial_reporta) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- PERSONAL: ASCENSOS Y CERTIFICACIONES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS historial_ascensos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    rango_anterior VARCHAR(30),
    rango_nuevo VARCHAR(30) NOT NULL,
    motivo VARCHAR(255),
    id_oficial_autoriza INT NULL,
    fecha DATE NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_oficial_autoriza) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS certificaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    nombre_curso VARCHAR(200) NOT NULL,
    institucion VARCHAR(150),
    fecha_obtencion DATE NOT NULL,
    notas TEXT,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- CHAT INTERNO
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mensajes_internos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_remitente INT NOT NULL,
    id_destinatario INT NULL,
    mensaje TEXT NOT NULL,
    fecha DATETIME NOT NULL,
    leido TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (id_remitente) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_destinatario) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- POSTULACIONES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS postulaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    dni VARCHAR(50) NOT NULL,
    edad INT,
    motivo TEXT,
    cv_ruta VARCHAR(500),
    estado VARCHAR(50) NOT NULL DEFAULT 'Pendiente',
    fecha DATETIME NOT NULL,
    id_usuario_civil INT NULL,
    FOREIGN KEY (id_usuario_civil) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- CONTENIDO PÚBLICO
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS noticias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    contenido TEXT,
    imagen VARCHAR(500),
    fecha DATETIME NOT NULL,
    publicado TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS contactos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150),
    email VARCHAR(150),
    mensaje TEXT,
    fecha DATETIME NOT NULL,
    leido TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- LOGS DE AUDITORÍA
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NULL,
    accion VARCHAR(255) NOT NULL,
    fecha DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- RATE LIMITING (reemplaza el diccionario en memoria de la
-- versión Python — en PHP cada request es un proceso nuevo, así
-- que esto necesita persistirse en la base de datos)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rate_limit_hits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    endpoint VARCHAR(50) NOT NULL,
    ip VARCHAR(45) NOT NULL,
    creado_en DATETIME NOT NULL,
    INDEX idx_endpoint_ip (endpoint, ip, creado_en)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- DATOS INICIALES (seed)
-- ============================================================
-- OJO: el usuario AdminWeb inicial (placa 9999 / admin123) NO se crea
-- acá. Se crea al visitar install.php desde el navegador una sola vez,
-- después de importar este schema — así el propio PHP del servidor
-- genera el hash de la contraseña correctamente (evita el riesgo de
-- pegar un hash bcrypt escrito a mano que podría no coincidir).

INSERT IGNORE INTO categorias_denuncia (nombre) VALUES
('Robo'), ('Homicidio'), ('Vandalismo'), ('Tráfico de drogas'), ('Extorsión'), ('Otro');

INSERT IGNORE INTO categorias_investigacion (nombre) VALUES
('Narcóticos'), ('Crimen organizado'), ('Homicidios'), ('Robos'), ('Cibercrimen');

INSERT IGNORE INTO categorias_multa (nombre, monto_sugerido) VALUES
('Exceso de velocidad', 250.00),
('Estacionamiento indebido', 100.00),
('Conducción temeraria', 400.00),
('Sin licencia', 300.00),
('Otro', 50.00);

INSERT IGNORE INTO estados (tipo, nombre) VALUES
('denuncia', 'Pendiente'), ('denuncia', 'En investigación'), ('denuncia', 'Cerrada'), ('denuncia', 'Archivada'),
('investigacion', 'Abierta'), ('investigacion', 'En curso'), ('investigacion', 'Cerrada'), ('investigacion', 'Archivada'),
('postulacion', 'Pendiente'), ('postulacion', 'Aprobada'), ('postulacion', 'Rechazada'),
('multa', 'Pendiente'), ('multa', 'Pagada'), ('multa', 'Anulada'),
('arma', 'Activa'), ('arma', 'Vencida'), ('arma', 'Cedida'), ('arma', 'Retirada'), ('arma', 'Incautada'), ('arma', 'Destruida'),
('arresto', 'Detenido'), ('arresto', 'Libertad Bajo Fianza'), ('arresto', 'Pendiente Audiencia'), ('arresto', 'Condenado'), ('arresto', 'Absuelto'), ('arresto', 'Condena Cumplida'),
('asunto_interno', 'Pendiente'), ('asunto_interno', 'En Investigación'), ('asunto_interno', 'Cerrado - Sancionado'), ('asunto_interno', 'Cerrado - Sin Mérito');

INSERT IGNORE INTO configuracion (clave, valor, seccion) VALUES
('nombre_departamento', 'Los Santos Police Department', 'public'),
('banner_texto', 'Servir y Proteger a la Ciudad de Los Santos', 'public'),
('logo_public', '', 'public'),
('footer_texto', '© Los Santos Police Department - Todos los derechos reservados', 'public'),
('postulaciones_activas', '1', 'public'),
('postulaciones_form_url', '', 'public'),
('mdt_titulo', 'MDT - Terminal de Datos Móvil', 'mdt'),
('mdt_color_primario', '#0d6efd', 'mdt'),
('mdt_logo', '', 'mdt'),
('mdt_texto_dashboard', 'Bienvenido a la Terminal de Datos Móvil del LSPD', 'mdt');

INSERT IGNORE INTO noticias (titulo, contenido, imagen, fecha, publicado) VALUES
('Bienvenidos al nuevo portal del LSPD',
 'El Departamento de Policía de Los Santos presenta su nuevo portal ciudadano, donde podrás realizar denuncias, postular a la institución y mantenerte informado.',
 '', NOW(), 1);
