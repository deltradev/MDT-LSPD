-- ============================================================
-- migracion_armas.sql
-- ============================================================
-- Ejecutar SOLO si ya tenías el sistema instalado ANTES de este
-- cambio (registro de licencias de armas mejorado). Si estás
-- instalando el sistema desde cero, no hace falta este archivo:
-- alcanza con importar schema.sql, que ya incluye todo esto.
--
-- Cómo usar: phpMyAdmin → tu base de datos → pestaña "Importar" →
-- subir este archivo. Es seguro ejecutarlo más de una vez (usa
-- IF NOT EXISTS en todo lo que agrega).
-- ============================================================

ALTER TABLE armas
    ADD COLUMN IF NOT EXISTS categoria_arma VARCHAR(50) AFTER tipo,
    ADD COLUMN IF NOT EXISTS color VARCHAR(50) AFTER calibre,
    ADD COLUMN IF NOT EXISTS pais_origen VARCHAR(100) AFTER color,
    ADD COLUMN IF NOT EXISTS fecha_emision_permiso DATE NULL AFTER numero_permiso,
    ADD COLUMN IF NOT EXISTS fecha_vencimiento_permiso DATE NULL AFTER fecha_emision_permiso,
    ADD COLUMN IF NOT EXISTS motivo_baja VARCHAR(255) NULL AFTER notas,
    ADD COLUMN IF NOT EXISTS fecha_baja DATE NULL AFTER motivo_baja,
    ADD COLUMN IF NOT EXISTS id_oficial_baja INT NULL AFTER fecha_baja;

CREATE TABLE IF NOT EXISTS armas_historial (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_arma INT NOT NULL,
    tipo_evento VARCHAR(30) NOT NULL,
    descripcion TEXT,
    id_persona_anterior INT NULL,
    id_persona_nueva INT NULL,
    id_oficial INT NULL,
    fecha DATETIME NOT NULL,
    FOREIGN KEY (id_arma) REFERENCES armas(id) ON DELETE CASCADE,
    FOREIGN KEY (id_persona_anterior) REFERENCES personas(id) ON DELETE SET NULL,
    FOREIGN KEY (id_persona_nueva) REFERENCES personas(id) ON DELETE SET NULL,
    FOREIGN KEY (id_oficial) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO estados (tipo, nombre) VALUES
('arma', 'Cedida'), ('arma', 'Retirada');

-- Nota: si tu versión de MySQL es más vieja que 8.0.29, "ADD COLUMN IF NOT
-- EXISTS" puede no estar soportado. En ese caso quitá el "IF NOT EXISTS"
-- de cada línea del ALTER TABLE de arriba y ejecutalo una sola vez.
