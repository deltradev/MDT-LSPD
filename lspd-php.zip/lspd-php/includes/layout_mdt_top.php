<?php
/**
 * includes/layout_mdt_top.php
 * Encabezado + navbar del MDT interno (tema oscuro). Requiere que la
 * página ya haya llamado a requerirMdt() antes de incluir este archivo.
 */
$cfgMdt = getConfigSeccion('mdt');
$usuario = usuarioActual();
$tituloPagina = $tituloPagina ?? ($cfgMdt['mdt_titulo'] ?? 'MDT LSPD');
$colorPrimario = $cfgMdt['mdt_color_primario'] ?? '#0d6efd';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= escape($tituloPagina) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= rutaBase() ?>static/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<style>:root{--mdt-primary: <?= escape($colorPrimario) ?>;}</style>
</head>
<body class="mdt-body">
<nav class="navbar navbar-expand-lg mdt-navbar">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold" href="<?= rutaBase() ?>mdt/dashboard.php">
      <i class="bi bi-shield-fill-check me-1"></i><?= escape($cfgMdt['mdt_titulo'] ?? 'MDT LSPD') ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMdt">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMdt">
      <ul class="navbar-nav me-auto gap-1">
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/denuncias.php"><i class="bi bi-file-earmark-text"></i> Denuncias</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><i class="bi bi-database"></i> BD Criminal</a>
          <ul class="dropdown-menu dropdown-menu-dark">
            <li><a class="dropdown-item" href="<?= rutaBase() ?>mdt/personas.php">Personas</a></li>
            <li><a class="dropdown-item" href="<?= rutaBase() ?>mdt/bandas.php">Bandas</a></li>
          </ul>
        </li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/investigaciones.php"><i class="bi bi-search"></i> Investigaciones</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/multas.php"><i class="bi bi-cash-coin"></i> Multas</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/armas.php"><i class="bi bi-record-circle"></i> Armas</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/arrestos.php"><i class="bi bi-person-lock"></i> Arrestos</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/bolo.php"><i class="bi bi-megaphone"></i> BOLO</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><i class="bi bi-person-vcard"></i> Personal</a>
          <ul class="dropdown-menu dropdown-menu-dark">
            <li><a class="dropdown-item" href="<?= rutaBase() ?>mdt/personal.php">Ascensos / Certificaciones</a></li>
            <?php if ($usuario && in_array($usuario['rol'], ROLES_ADMIN, true)): ?>
            <li><a class="dropdown-item" href="<?= rutaBase() ?>mdt/asuntos_internos.php">Asuntos Internos</a></li>
            <?php endif; ?>
          </ul>
        </li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/mensajeria.php"><i class="bi bi-chat-dots"></i> Chat</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/estadisticas.php"><i class="bi bi-bar-chart-line"></i> Estadísticas</a></li>
        <?php if ($usuario && in_array($usuario['rol'], ROLES_ADMIN, true)): ?>
        <li class="nav-item"><a class="nav-link text-warning" href="<?= rutaBase() ?>admin/panel.php"><i class="bi bi-gear-fill"></i> Admin</a></li>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav align-items-lg-center">
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>public/index.php" target="_blank"><i class="bi bi-box-arrow-up-right"></i> Portal Civil</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle"></i> <?= escape($usuario['nombre']) ?> <span class="badge bg-primary"><?= escape($usuario['rol']) ?></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-dark">
            <li><span class="dropdown-item-text small">Placa: <?= escape($usuario['placa']) ?></span></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?= rutaBase() ?>public/logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid px-4 mt-3">
  <?php foreach (obtenerFlashes() as $f): ?>
    <div class="alert alert-<?= escape($f['categoria']) ?> alert-dismissible fade show" role="alert">
      <?= escape($f['mensaje']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endforeach; ?>
</div>

<main class="container-fluid px-4 my-4">
