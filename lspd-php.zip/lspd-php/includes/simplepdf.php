<?php
/**
 * includes/simplepdf.php
 * Generador de PDF mínimo, sin librerías externas (no usamos FPDF/TCPDF
 * porque no podíamos probar la instalación de una librería de terceros
 * en este entorno). Genera PDFs válidos de una sola página con texto,
 * suficiente para las constancias y boletas del sistema.
 *
 * Los offsets de la tabla xref se calculan dinámicamente con strlen()
 * mientras se arma el archivo — no hay ningún número mágico escrito a
 * mano que pueda estar mal.
 */

class SimplePDF {
    private $ops = '';           // operadores de dibujo acumulados (content stream)
    private $ancho = 595;        // A4 en puntos (72dpi)
    private $alto = 842;

    private function esc($texto) {
        $texto = (string) $texto;
        if (function_exists('mb_convert_encoding')) {
            $convertido = @mb_convert_encoding($texto, 'Windows-1252', 'UTF-8');
            if ($convertido !== false) {
                $texto = $convertido;
            }
        }
        // Los core fonts de PDF (Helvetica) solo soportan WinAnsiEncoding
        // (1 byte por carácter) — por eso convertimos antes de escapar.
        $texto = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $texto);
        return $texto;
    }

    public function setColor($r, $g, $b) {
        $this->ops .= sprintf("%.3F %.3F %.3F rg\n", $r, $g, $b);
    }

    public function texto($x, $y, $texto, $tamano = 10, $negrita = false) {
        $fuente = $negrita ? '/F2' : '/F1';
        $this->ops .= sprintf(
            "BT %s %d Tf 1 0 0 1 %.2F %.2F Tm (%s) Tj ET\n",
            $fuente, $tamano, $x, $y, $this->esc($texto)
        );
    }

    public function textoCentrado($y, $texto, $tamano = 12, $negrita = false) {
        // Ancho aproximado (Helvetica promedia ~0.5 del tamaño de fuente
        // por carácter) — suficiente para centrar títulos visualmente.
        $anchoAprox = strlen($texto) * $tamano * 0.5;
        $x = ($this->ancho - $anchoAprox) / 2;
        if ($x < 40) {
            $x = 40;
        }
        $this->texto($x, $y, $texto, $tamano, $negrita);
    }

    public function rectanguloRelleno($x, $y, $w, $h, $r, $g, $b) {
        $this->ops .= sprintf("%.3F %.3F %.3F rg\n%.2F %.2F %.2F %.2F re f\n", $r, $g, $b, $x, $y, $w, $h);
    }

    /** Parte un texto largo en líneas de máximo $maxCaracteres para que entre en la página. */
    public function envolverTexto($texto, $maxCaracteres = 95) {
        $ajustado = wordwrap((string) $texto, $maxCaracteres, "\n", true);
        return explode("\n", $ajustado);
    }

    /** Arma el archivo PDF completo como string de bytes. */
    public function output() {
        $objetos = [];

        $objetos[] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objetos[] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";
        $objetos[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {$this->ancho} {$this->alto}] "
                   . "/Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>";

        $stream = $this->ops;
        $objetos[] = "<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "endstream";

        $objetos[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
        $objetos[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";

        $buffer = "%PDF-1.4\n";
        $offsets = [];
        foreach ($objetos as $i => $cuerpo) {
            $numero = $i + 1;
            $offsets[$numero] = strlen($buffer);
            $buffer .= "{$numero} 0 obj\n{$cuerpo}\nendobj\n";
        }

        $xrefOffset = strlen($buffer);
        $totalObjetos = count($objetos) + 1; // +1 por el objeto 0 (libre)
        $buffer .= "xref\n0 {$totalObjetos}\n0000000000 65535 f \n";
        for ($n = 1; $n < $totalObjetos; $n++) {
            $buffer .= sprintf("%010d 00000 n \n", $offsets[$n]);
        }
        $buffer .= "trailer\n<< /Size {$totalObjetos} /Root 1 0 R >>\nstartxref\n{$xrefOffset}\n%%EOF";

        return $buffer;
    }
}

/**
 * Genera una constancia/boleta oficial estilo LSPD y la guarda en $rutaSalida.
 * $campos es un array asociativo ['Etiqueta' => 'Valor', ...].
 */
function generarPdfConstancia($rutaSalida, $titulo, array $campos, $descripcion = '') {
    $pdf = new SimplePDF();
    $y = 780;

    $pdf->setColor(0.051, 0.106, 0.165);
    $pdf->textoCentrado($y, 'LOS SANTOS POLICE DEPARTMENT', 16, true);
    $y -= 22;

    $pdf->setColor(0.35, 0.35, 0.35);
    $pdf->textoCentrado($y, 'Documento Oficial Generado por el Sistema MDT', 10);
    $y -= 30;

    $pdf->setColor(0, 0, 0);
    $pdf->textoCentrado($y, $titulo, 14, true);
    $y -= 30;

    foreach ($campos as $etiqueta => $valor) {
        $pdf->rectanguloRelleno(50, $y - 4, 150, 18, 0.051, 0.106, 0.165);
        $pdf->setColor(1, 1, 1);
        $pdf->texto(56, $y, $etiqueta, 10, true);
        $pdf->setColor(0, 0, 0);
        $pdf->texto(210, $y, (string) $valor, 10);
        $y -= 22;
    }

    $y -= 12;

    if ($descripcion !== '') {
        $pdf->setColor(0, 0, 0);
        $pdf->texto(50, $y, 'Descripción:', 11, true);
        $y -= 18;
        foreach ($pdf->envolverTexto($descripcion, 95) as $linea) {
            $pdf->texto(50, $y, $linea, 10);
            $y -= 14;
        }
        $y -= 10;
    }

    $y -= 20;
    $pdf->setColor(0.3, 0.3, 0.3);
    $pdf->texto(50, $y, 'Generado el ' . date('Y-m-d H:i'), 9);
    $y -= 14;
    $pdf->texto(50, $y, 'Documento válido únicamente con sello y firma de la institución.', 9);

    file_put_contents($rutaSalida, $pdf->output());
}
