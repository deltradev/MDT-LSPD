<?php
/**
 * includes/db.php
 * Conexión única (singleton) a la base de datos MySQL vía PDO.
 * Usa la constante $pdo global; llamá obtenerConexion() desde cualquier
 * página para obtener la conexión ya lista.
 */

function obtenerConexion() {
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $opciones = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $opciones);
    }

    return $pdo;
}
