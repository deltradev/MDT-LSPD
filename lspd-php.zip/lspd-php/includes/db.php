<?php
/**
 * includes/db.php
 * Conexión única (singleton) a la base de datos MySQL vía PDO.
 * Usa la constante $pdo global; llamá obtenerConexion() desde cualquier
 * página para obtener la conexión ya lista.
 */

function obtenerConexion() {
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $opciones = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $opciones);
        } catch (PDOException $e) {
            // Sin este catch, un dato mal cargado en config.php (o el
            // schema.sql todavía no importado) termina en un error 500 en
            // blanco sin ninguna pista de qué pasó, porque APP_DEBUG está
            // apagado por seguridad. Con esto, al menos se ve un mensaje
            // claro de qué revisar, sin exponer datos sensibles.
            http_response_code(500);
            $detalle = APP_DEBUG ? htmlspecialchars($e->getMessage()) : '';
            echo '<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">'
               . '<title>Error de conexión</title>'
               . '<style>body{font-family:system-ui,sans-serif;background:#0f1620;color:#e2e8f0;'
               . 'display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}'
               . '.box{background:#161f2c;border:1px solid #2a3646;border-radius:10px;padding:2rem;max-width:560px;}'
               . 'h1{color:#dc3545;font-size:1.3rem;}code{background:#0f1620;padding:2px 6px;border-radius:4px;}</style>'
               . '</head><body><div class="box">'
               . '<h1>No se pudo conectar a la base de datos</h1>'
               . '<p>Revisá en <code>config.php</code> que <code>DB_HOST</code>, <code>DB_NAME</code>, '
               . '<code>DB_USER</code> y <code>DB_PASS</code> sean exactamente los que te dio el panel de '
               . 'ByetHost (MySQL Databases), y que ya hayas importado <code>schema.sql</code> desde phpMyAdmin.</p>'
               . ($detalle !== '' ? "<p><small>Detalle técnico: {$detalle}</small></p>" : '')
               . '</div></body></html>';
            exit;
        }
    }

    return $pdo;
}
