<?php
/**
 * includes/bootstrap.php
 * Incluir esto al principio de TODA página PHP de la aplicación (es el
 * equivalente al @app.before_request de la versión Flask): carga
 * configuración, conexión a datos, autenticación, helpers, cabeceras de
 * seguridad, y valida el token CSRF en cualquier POST automáticamente.
 */

require_once __DIR__ . '/../app_config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/simplepdf.php';

enviarCabecerasSeguridad();
verificarCsrf(); // no hace nada si el request no es POST
