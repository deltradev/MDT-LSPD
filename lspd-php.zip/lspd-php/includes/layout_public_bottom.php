</main>

<footer class="public-footer text-center py-4 mt-5">
  <div class="container">
    <p class="mb-0"><?= escape($cfgPublic['footer_texto'] ?? '© Los Santos Police Department') ?></p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
