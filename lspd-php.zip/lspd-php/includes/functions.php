<?php
/**
 * includes/functions.php
 * Funciones auxiliares usadas en toda la aplicación.
 *
 * NOTA SOBRE RUTAS: todas las páginas "reales" de la app viven exactamente
 * un nivel debajo de la raíz del sitio (public/xxx.php, mdt/xxx.php,
 * admin/xxx.php). Por eso rutaBase() siempre devuelve '../' — si algún día
 * cambiás esa estructura de carpetas, actualizá esta función.
 */

require_once __DIR__ . '/db.php';

function rutaBase() {
    return '../';
}

function escape($valor) {
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function redirigir($rutaRelativaDesdeRaiz, $queryString = '') {
    $url = rutaBase() . $rutaRelativaDesdeRaiz;
    if ($queryString !== '') {
        $url .= '?' . $queryString;
    }
    header('Location: ' . $url);
    exit;
}

// ------------------------------------------------------------------
// CONFIGURACIÓN (editor de portales)
// ------------------------------------------------------------------
function getConfig($clave, $default = '') {
    $pdo = obtenerConexion();
    $stmt = $pdo->prepare('SELECT valor FROM configuracion WHERE clave = ?');
    $stmt->execute([$clave]);
    $valor = $stmt->fetchColumn();
    return ($valor === false || $valor === null) ? $default : $valor;
}

function getConfigSeccion($seccion) {
    $pdo = obtenerConexion();
    $stmt = $pdo->prepare('SELECT clave, valor FROM configuracion WHERE seccion = ?');
    $stmt->execute([$seccion]);
    $resultado = [];
    foreach ($stmt->fetchAll() as $fila) {
        $resultado[$fila['clave']] = $fila['valor'];
    }
    return $resultado;
}

// ------------------------------------------------------------------
// ESTADOS / CATEGORÍAS
// ------------------------------------------------------------------
function getEstados($tipo) {
    $pdo = obtenerConexion();
    $stmt = $pdo->prepare('SELECT nombre FROM estados WHERE tipo = ? ORDER BY id');
    $stmt->execute([$tipo]);
    return array_column($stmt->fetchAll(), 'nombre');
}

// ------------------------------------------------------------------
// NÚMEROS DE CASO AUTOGENERADOS
// ------------------------------------------------------------------
function generarNumeroCaso($prefijo, $tabla) {
    $pdo = obtenerConexion();
    $total = (int) $pdo->query("SELECT COUNT(*) FROM {$tabla}")->fetchColumn();
    return sprintf('%s-%s-%05d', $prefijo, date('Y'), $total + 1);
}

// ------------------------------------------------------------------
// LOGS DE AUDITORÍA
// ------------------------------------------------------------------
function logAccion($idUsuario, $accion) {
    $pdo = obtenerConexion();
    $stmt = $pdo->prepare('INSERT INTO logs (id_usuario, accion, fecha) VALUES (?, ?, NOW())');
    $stmt->execute([$idUsuario, $accion]);
}

// ------------------------------------------------------------------
// SUBIDA DE ARCHIVOS
// ------------------------------------------------------------------
const EXTENSIONES_PERMITIDAS = ['pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'txt', 'webp'];
const TAMANO_MAXIMO_BYTES = 16 * 1024 * 1024; // 16 MB

function extensionPermitida($nombreArchivo) {
    $ext = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
    return in_array($ext, EXTENSIONES_PERMITIDAS, true);
}

/**
 * Sube un archivo desde $_FILES[$campo] a una subcarpeta de uploads/.
 * Devuelve la ruta relativa guardada (para la BD) o null si no había
 * archivo / no era válido.
 */
function subirArchivo($campo, $subcarpeta) {
    if (empty($_FILES[$campo]) || $_FILES[$campo]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    $archivo = $_FILES[$campo];
    if ($archivo['size'] > TAMANO_MAXIMO_BYTES) {
        return null;
    }
    if (!extensionPermitida($archivo['name'])) {
        return null;
    }

    $nombreSeguro = preg_replace('/[^A-Za-z0-9._-]/', '_', basename($archivo['name']));
    $nombreSeguro = time() . '_' . $nombreSeguro; // evita colisiones de nombre

    $carpetaDestino = UPLOAD_DIR . '/' . trim($subcarpeta, '/');
    if (!is_dir($carpetaDestino)) {
        mkdir($carpetaDestino, 0755, true);
    }

    $rutaCompleta = $carpetaDestino . '/' . $nombreSeguro;
    if (!move_uploaded_file($archivo['tmp_name'], $rutaCompleta)) {
        return null;
    }

    return trim($subcarpeta, '/') . '/' . $nombreSeguro;
}

// ------------------------------------------------------------------
// CLOUDFLARE TURNSTILE (CAPTCHA)
// ------------------------------------------------------------------
function turnstileHabilitado() {
    return TURNSTILE_SITE_KEY !== '' && TURNSTILE_SECRET_KEY !== '';
}

function verificarTurnstile($token) {
    if (!turnstileHabilitado()) {
        return true; // no configurado -> no se exige
    }
    if (empty($token)) {
        return false;
    }

    $datos = http_build_query([
        'secret' => TURNSTILE_SECRET_KEY,
        'response' => $token,
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '',
    ]);

    $contexto = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $datos,
            'timeout' => 8,
        ],
    ]);

    $respuesta = @file_get_contents('https://challenges.cloudflare.com/turnstile/v0/siteverify', false, $contexto);
    if ($respuesta === false) {
        // Si Cloudflare no responde, no dejamos a la gente sin poder usar
        // el sitio — igual queda protegido por CSRF y rate-limiting.
        return true;
    }

    $resultado = json_decode($respuesta, true);
    return !empty($resultado['success']);
}

// ------------------------------------------------------------------
// CABECERAS DE SEGURIDAD (llamar al inicio de cada página)
// ------------------------------------------------------------------
function enviarCabecerasSeguridad() {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://challenges.cloudflare.com; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; font-src 'self' https://cdn.jsdelivr.net; img-src 'self' data: blob: https:; frame-src 'self' https://docs.google.com https://*.google.com https://challenges.cloudflare.com; connect-src 'self' https://challenges.cloudflare.com;");
}
