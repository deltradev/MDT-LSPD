<?php
/**
 * includes/auth.php
 * Sesión, control de acceso por rol, protección CSRF y rate-limiting.
 *
 * A diferencia de la versión Python (donde el rate-limit vivía en un
 * diccionario en memoria del proceso), acá cada visita a una página PHP
 * es un proceso nuevo e independiente — por eso el rate-limiting y el
 * bloqueo de cuentas se guardan en la tabla `rate_limit_hits` y en las
 * columnas `intentos_fallidos`/`bloqueado_hasta` de `usuarios`.
 */

require_once __DIR__ . '/db.php';

const ROL_CIVIL = 'Civil';
const ROLES_LSPD = ['Cadete', 'Oficial', 'Sargento', 'Teniente', 'Capitán', 'Jefe', 'AdminWeb'];
const ROLES_ADMIN = ['Jefe', 'AdminWeb'];

if (session_status() === PHP_SESSION_NONE) {
    // Cookies de sesión endurecidas: no accesibles por JS, no se filtran
    // en navegación cross-site.
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    ]);
    session_start();
}

// ------------------------------------------------------------------
// USUARIO ACTUAL
// ------------------------------------------------------------------
function usuarioActual() {
    return $_SESSION['usuario'] ?? null;
}

function estaLogueado() {
    return usuarioActual() !== null;
}

// Redirige con un mensaje flash. $ruta debe ser relativa a la raíz del sitio
// (ej: 'public/login.php') — todas las páginas viven en subcarpetas, así
// que uso rutaBase() (definida en functions.php) para armar la URL final.
function requerirLogin() {
    if (!estaLogueado()) {
        flash('warning', 'Debes iniciar sesión para continuar.');
        $siguiente = urlencode($_SERVER['REQUEST_URI'] ?? '');
        header('Location: ' . rutaBase() . 'public/login.php?next=' . $siguiente);
        exit;
    }
}

function requerirRol(array $rolesPermitidos) {
    requerirLogin();
    $usuario = usuarioActual();
    if (!in_array($usuario['rol'], $rolesPermitidos, true)) {
        http_response_code(403);
        require __DIR__ . '/../public/403.php';
        exit;
    }
}

function requerirMdt() {
    requerirRol(ROLES_LSPD);
}

function requerirAdmin() {
    requerirRol(ROLES_ADMIN);
}

// ------------------------------------------------------------------
// CSRF
// ------------------------------------------------------------------
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfCampoOculto() {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrfToken()) . '">';
}

function verificarCsrf() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }
    $tokenSesion = $_SESSION['csrf_token'] ?? '';
    $tokenEnviado = $_POST['csrf_token'] ?? '';
    if ($tokenSesion === '' || $tokenEnviado === '' || !hash_equals($tokenSesion, $tokenEnviado)) {
        http_response_code(400);
        echo '<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>Solicitud inválida</title></head>'
           . '<body style="font-family:sans-serif;text-align:center;padding:4rem;">'
           . '<h1>400 - Solicitud inválida</h1>'
           . '<p>Tu sesión o el formulario expiraron. Recargá la página e intentalo de nuevo.</p>'
           . '<a href="' . rutaBase() . '">Volver al inicio</a>'
           . '</body></html>';
        exit;
    }
}

// ------------------------------------------------------------------
// RATE LIMITING (por IP + endpoint, ventana deslizante en la tabla
// rate_limit_hits — persiste entre requests, a diferencia de un
// diccionario en memoria)
// ------------------------------------------------------------------
function rateLimit($nombreEndpoint, $maxIntentos, $ventanaSegundos) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }
    $pdo = obtenerConexion();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'desconocida';

    // Limpiar intentos viejos fuera de la ventana
    $stmt = $pdo->prepare('DELETE FROM rate_limit_hits WHERE endpoint = ? AND ip = ? AND creado_en < (NOW() - INTERVAL ? SECOND)');
    $stmt->execute([$nombreEndpoint, $ip, $ventanaSegundos]);

    // Contar intentos vigentes
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM rate_limit_hits WHERE endpoint = ? AND ip = ?');
    $stmt->execute([$nombreEndpoint, $ip]);
    $total = (int) $stmt->fetchColumn();

    if ($total >= $maxIntentos) {
        http_response_code(429);
        echo '<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>Demasiadas solicitudes</title></head>'
           . '<body style="font-family:sans-serif;text-align:center;padding:4rem;">'
           . '<h1>429 - Demasiadas solicitudes</h1>'
           . '<p>Detectamos muchos intentos en poco tiempo. Esperá un momento y volvé a intentarlo.</p>'
           . '<a href="' . rutaBase() . '">Volver al inicio</a>'
           . '</body></html>';
        exit;
    }

    $stmt = $pdo->prepare('INSERT INTO rate_limit_hits (endpoint, ip, creado_en) VALUES (?, ?, NOW())');
    $stmt->execute([$nombreEndpoint, $ip]);
}

// ------------------------------------------------------------------
// MENSAJES FLASH (vía sesión, se muestran una vez y se borran)
// ------------------------------------------------------------------
function flash($categoria, $mensaje) {
    if (!isset($_SESSION['flashes'])) {
        $_SESSION['flashes'] = [];
    }
    $_SESSION['flashes'][] = ['categoria' => $categoria, 'mensaje' => $mensaje];
}

function obtenerFlashes() {
    $flashes = $_SESSION['flashes'] ?? [];
    unset($_SESSION['flashes']);
    return $flashes;
}
