<?php
/**
 * includes/layout_admin_top.php
 * Encabezado + navbar del panel de administración. Requiere que la
 * página ya haya llamado a requerirAdmin() antes de incluir esto.
 */
$usuario = usuarioActual();
$tituloPagina = $tituloPagina ?? 'Panel Admin';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= escape($tituloPagina) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= rutaBase() ?>static/css/style.css">
</head>
<body class="mdt-body">
<nav class="navbar navbar-expand-lg mdt-navbar">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold" href="<?= rutaBase() ?>admin/panel.php"><i class="bi bi-gear-fill"></i> Panel de Administración</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navAdmin">
      <ul class="navbar-nav me-auto gap-1">
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>admin/panel.php"><i class="bi bi-speedometer2"></i> Panel</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>admin/usuarios.php"><i class="bi bi-people"></i> Usuarios</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>admin/categorias.php"><i class="bi bi-tags"></i> Categorías</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>admin/estados.php"><i class="bi bi-list-check"></i> Estados</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>admin/config.php?seccion=public"><i class="bi bi-globe"></i> Portal Civil</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>admin/config.php?seccion=mdt"><i class="bi bi-display"></i> Editor MDT</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>admin/postulaciones.php"><i class="bi bi-person-badge"></i> Postulaciones</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>admin/logs.php"><i class="bi bi-clock-history"></i> Logs</a></li>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>mdt/dashboard.php"><i class="bi bi-arrow-left"></i> Volver al MDT</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>public/logout.php"><i class="bi bi-box-arrow-right"></i> Salir</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container-fluid px-4 mt-3">
  <?php foreach (obtenerFlashes() as $f): ?>
    <div class="alert alert-<?= escape($f['categoria']) ?> alert-dismissible fade show" role="alert">
      <?= escape($f['mensaje']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endforeach; ?>
</div>
<main class="container-fluid px-4 my-4">
