<?php
/**
 * includes/layout_public_top.php
 * Encabezado + navbar del portal público (tema claro). Cada página de
 * public/ hace require de esto después de su lógica, y de
 * layout_public_bottom.php al final.
 *
 * Variables que la página puede definir ANTES de incluir este archivo:
 *   $tituloPagina (string, opcional)
 */
$cfgPublic = getConfigSeccion('public');
$usuario = usuarioActual();
$tituloPagina = $tituloPagina ?? ($cfgPublic['nombre_departamento'] ?? 'LSPD');
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= escape($tituloPagina) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= rutaBase() ?>static/css/public.css">
<?php if (turnstileHabilitado()): ?>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
<?php endif; ?>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light public-navbar sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?= rutaBase() ?>public/index.php">
      <i class="bi bi-shield-fill-check me-1"></i><?= escape($cfgPublic['nombre_departamento'] ?? 'LSPD') ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navPublic">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navPublic">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>public/index.php"><i class="bi bi-house-door"></i> Inicio</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>public/postulaciones.php"><i class="bi bi-person-badge"></i> Postulaciones</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>public/denuncias.php"><i class="bi bi-file-earmark-text"></i> Denuncias</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>public/se_busca.php"><i class="bi bi-person-bounding-box"></i> Se Busca</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>public/contacto.php"><i class="bi bi-envelope"></i> Contacto</a></li>
        <?php if ($usuario): ?>
          <?php if ($usuario['rol'] !== ROL_CIVIL): ?>
            <li class="nav-item"><a class="btn btn-dark btn-sm ms-lg-2" href="<?= rutaBase() ?>mdt/dashboard.php"><i class="bi bi-display"></i> Ir al MDT</a></li>
          <?php endif; ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
              <i class="bi bi-person-circle"></i> <?= escape($usuario['nombre']) ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><span class="dropdown-item-text small text-muted">Rol: <?= escape($usuario['rol']) ?></span></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="<?= rutaBase() ?>public/logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
            </ul>
          </li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?= rutaBase() ?>public/login.php"><i class="bi bi-box-arrow-in-right"></i> Iniciar sesión</a></li>
          <li class="nav-item"><a class="btn btn-primary btn-sm" href="<?= rutaBase() ?>public/registro.php">Registrarse</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-3">
  <?php foreach (obtenerFlashes() as $f): ?>
    <div class="alert alert-<?= escape($f['categoria']) ?> alert-dismissible fade show" role="alert">
      <?= escape($f['mensaje']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endforeach; ?>
</div>

<main class="container my-4">
