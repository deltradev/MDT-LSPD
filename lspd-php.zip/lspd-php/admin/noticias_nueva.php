<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = trim($_POST['titulo'] ?? '');
    if ($titulo !== '') {
        $pdo = obtenerConexion();
        $stmt = $pdo->prepare(
            "INSERT INTO noticias (titulo, contenido, imagen, fecha, publicado) VALUES (?, ?, '', NOW(), 1)"
        );
        $stmt->execute([$titulo, trim($_POST['contenido'] ?? '')]);
        flash('success', 'Noticia publicada.');
    }
}

redirigir('admin/config.php', 'seccion=public');
