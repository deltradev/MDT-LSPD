<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$pdo = obtenerConexion();
$usuarios = $pdo->query('SELECT * FROM usuarios ORDER BY id DESC')->fetchAll();

$tituloPagina = 'Gestionar Usuarios';
require __DIR__ . '/../includes/layout_admin_top.php';
?>

<h3 class="text-light mb-3"><i class="bi bi-people"></i> Gestionar Usuarios</h3>

<div class="card mdt-card p-4 mb-4">
  <h5>Crear nuevo usuario</h5>
  <form method="POST" action="<?= rutaBase() ?>admin/usuarios_nuevo.php" class="row g-2">
    <?= csrfCampoOculto() ?>
    <div class="col-md-2"><input type="text" name="placa" class="form-control" placeholder="Placa/DNI" required></div>
    <div class="col-md-2"><input type="text" name="nombre" class="form-control" placeholder="Nombre" required></div>
    <div class="col-md-2"><input type="text" name="apellido" class="form-control" placeholder="Apellido" required></div>
    <div class="col-md-2"><input type="password" name="password" class="form-control" placeholder="Contraseña" required></div>
    <div class="col-md-2">
      <select name="rol" class="form-select">
        <option value="Civil">Civil</option>
        <?php foreach (ROLES_LSPD as $r): ?>
        <option value="<?= $r ?>"><?= $r ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2"><button class="btn btn-primary w-100"><i class="bi bi-plus-lg"></i> Crear</button></div>
  </form>
</div>

<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>Placa</th><th>Nombre</th><th>Rol</th><th>Ingreso</th><th>Activo</th><th>Acciones</th></tr></thead>
    <tbody>
    <?php foreach ($usuarios as $u): ?>
      <tr>
        <td><?= escape($u['placa']) ?></td>
        <td><?= escape($u['nombre'] . ' ' . $u['apellido']) ?></td>
        <td><span class="badge bg-primary"><?= escape($u['rol']) ?></span></td>
        <td><?= escape($u['fecha_ingreso']) ?></td>
        <td><?= $u['activo'] ? 'Sí' : 'No' ?></td>
        <td>
          <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#editModal<?= (int) $u['id'] ?>"><i class="bi bi-pencil"></i></button>
          <form method="POST" action="<?= rutaBase() ?>admin/usuarios_eliminar.php" class="d-inline" onsubmit="return confirm('¿Eliminar usuario?')">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </td>
      </tr>
      <div class="modal fade" id="editModal<?= (int) $u['id'] ?>" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content bg-dark text-light">
            <form method="POST" action="<?= rutaBase() ?>admin/usuarios_editar.php">
              <?= csrfCampoOculto() ?>
              <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
              <div class="modal-header"><h5 class="modal-title">Editar <?= escape($u['placa']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
              <div class="modal-body">
                <div class="mb-2"><label class="form-label">Nombre</label><input class="form-control" name="nombre" value="<?= escape($u['nombre']) ?>"></div>
                <div class="mb-2"><label class="form-label">Apellido</label><input class="form-control" name="apellido" value="<?= escape($u['apellido']) ?>"></div>
                <div class="mb-2"><label class="form-label">Rol</label>
                  <select name="rol" class="form-select">
                    <option value="Civil" <?= $u['rol'] === 'Civil' ? 'selected' : '' ?>>Civil</option>
                    <?php foreach (ROLES_LSPD as $r): ?>
                    <option value="<?= $r ?>" <?= $u['rol'] === $r ? 'selected' : '' ?>><?= $r ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="mb-2"><label class="form-label">Nueva contraseña (opcional)</label><input type="password" class="form-control" name="password"></div>
                <div class="form-check">
                  <input type="checkbox" class="form-check-input" name="activo" <?= $u['activo'] ? 'checked' : '' ?>>
                  <label class="form-check-label">Activo</label>
                </div>
              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_admin_bottom.php'; ?>
