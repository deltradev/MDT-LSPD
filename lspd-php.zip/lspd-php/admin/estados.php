<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$pdo = obtenerConexion();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['tipo'] ?? '';
    $nombre = trim($_POST['nombre'] ?? '');
    if ($tipo !== '' && $nombre !== '') {
        $stmt = $pdo->prepare('INSERT IGNORE INTO estados (tipo, nombre) VALUES (?, ?)');
        $stmt->execute([$tipo, $nombre]);
        flash('success', 'Estado agregado.');
    }
    redirigir('admin/estados.php');
}

$estadosDenuncia = $pdo->query("SELECT * FROM estados WHERE tipo='denuncia' ORDER BY id")->fetchAll();
$estadosInvestigacion = $pdo->query("SELECT * FROM estados WHERE tipo='investigacion' ORDER BY id")->fetchAll();
$estadosPostulacion = $pdo->query("SELECT * FROM estados WHERE tipo='postulacion' ORDER BY id")->fetchAll();
$estadosMulta = $pdo->query("SELECT * FROM estados WHERE tipo='multa' ORDER BY id")->fetchAll();
$estadosArma = $pdo->query("SELECT * FROM estados WHERE tipo='arma' ORDER BY id")->fetchAll();
$estadosArresto = $pdo->query("SELECT * FROM estados WHERE tipo='arresto' ORDER BY id")->fetchAll();
$estadosAsuntoInterno = $pdo->query("SELECT * FROM estados WHERE tipo='asunto_interno' ORDER BY id")->fetchAll();

$grupos = [
    ['denuncia', $estadosDenuncia, 'Denuncias'],
    ['investigacion', $estadosInvestigacion, 'Investigaciones'],
    ['postulacion', $estadosPostulacion, 'Postulaciones'],
    ['multa', $estadosMulta, 'Multas'],
    ['arma', $estadosArma, 'Armas'],
    ['arresto', $estadosArresto, 'Arrestos'],
    ['asunto_interno', $estadosAsuntoInterno, 'Asuntos Internos'],
];

$tituloPagina = 'Gestionar Estados';
require __DIR__ . '/../includes/layout_admin_top.php';
?>

<h3 class="text-light mb-4"><i class="bi bi-list-check"></i> Gestionar Estados</h3>
<div class="row g-4">
  <?php foreach ($grupos as [$tipo, $lista, $titulo]): ?>
  <div class="col-md-3">
    <div class="card mdt-card p-3">
      <h5>Estados de <?= escape($titulo) ?></h5>
      <form method="POST" class="d-flex gap-2 mb-3">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="tipo" value="<?= escape($tipo) ?>">
        <input type="text" name="nombre" class="form-control" placeholder="Nuevo estado" required>
        <button class="btn btn-primary"><i class="bi bi-plus-lg"></i></button>
      </form>
      <ul class="list-group list-group-flush">
        <?php foreach ($lista as $e): ?>
        <li class="list-group-item mdt-list-item d-flex justify-content-between align-items-center">
          <?= escape($e['nombre']) ?>
          <form method="POST" action="<?= rutaBase() ?>admin/estados_eliminar.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $e['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/../includes/layout_admin_bottom.php'; ?>
