<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $usuario = usuarioActual();

    $id = (int) ($_POST['id'] ?? 0);
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $rol = $_POST['rol'] ?? 'Civil';
    $activo = isset($_POST['activo']) ? 1 : 0;
    $nuevaPassword = (string) ($_POST['password'] ?? '');

    if ($nuevaPassword !== '') {
        $hash = password_hash($nuevaPassword, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare(
            'UPDATE usuarios SET nombre=?, apellido=?, rol=?, activo=?, password_hash=? WHERE id=?'
        );
        $stmt->execute([$nombre, $apellido, $rol, $activo, $hash, $id]);
    } else {
        $stmt = $pdo->prepare('UPDATE usuarios SET nombre=?, apellido=?, rol=?, activo=? WHERE id=?');
        $stmt->execute([$nombre, $apellido, $rol, $activo, $id]);
    }

    logAccion($usuario['id'], "Editó usuario ID {$id} (rol: {$rol})");
    flash('success', 'Usuario actualizado.');
}

redirigir('admin/usuarios.php');
