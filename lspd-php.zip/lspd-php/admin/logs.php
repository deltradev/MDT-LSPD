<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$pdo = obtenerConexion();
$logs = $pdo->query(
    "SELECT l.*, u.nombre AS usuario_nombre, u.apellido AS usuario_apellido, u.placa
     FROM logs l LEFT JOIN usuarios u ON l.id_usuario = u.id
     ORDER BY l.id DESC LIMIT 300"
)->fetchAll();

$tituloPagina = 'Logs';
require __DIR__ . '/../includes/layout_admin_top.php';
?>

<h3 class="text-light mb-4"><i class="bi bi-clock-history"></i> Logs del Sistema</h3>
<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>Usuario</th><th>Placa</th><th>Acción</th><th>Fecha</th></tr></thead>
    <tbody>
    <?php if (empty($logs)): ?>
      <tr><td colspan="4" class="text-secondary">Sin registros.</td></tr>
    <?php else: ?>
      <?php foreach ($logs as $l): ?>
      <tr>
        <td><?= escape(trim(($l['usuario_nombre'] ?? '') . ' ' . ($l['usuario_apellido'] ?? ''))) ?></td>
        <td><?= escape($l['placa'] ?: '-') ?></td>
        <td><?= escape($l['accion']) ?></td>
        <td><?= escape($l['fecha']) ?></td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_admin_bottom.php'; ?>
