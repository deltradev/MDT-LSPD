<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $stmt = $pdo->prepare("UPDATE postulaciones SET estado = 'Rechazada' WHERE id = ?");
    $stmt->execute([(int) ($_POST['id'] ?? 0)]);
    flash('info', 'Postulación rechazada.');
}

redirigir('admin/postulaciones.php');
