<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$pdo = obtenerConexion();
$totalUsuarios = (int) $pdo->query('SELECT COUNT(*) FROM usuarios')->fetchColumn();
$totalPostulacionesPendientes = (int) $pdo->query("SELECT COUNT(*) FROM postulaciones WHERE estado = 'Pendiente'")->fetchColumn();
$totalContactos = (int) $pdo->query('SELECT COUNT(*) FROM contactos WHERE leido = 0')->fetchColumn();

$tituloPagina = 'Panel de Administración';
require __DIR__ . '/../includes/layout_admin_top.php';
?>

<h3 class="text-light mb-4"><i class="bi bi-speedometer2"></i> Panel de Administración</h3>
<div class="row g-3 mb-4">
  <div class="col-md-4">
    <div class="card mdt-card p-3 text-center">
      <i class="bi bi-people display-6 text-primary"></i>
      <h3 class="mt-2"><?= $totalUsuarios ?></h3>
      <p class="mb-0 text-secondary">Usuarios Totales</p>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card mdt-card p-3 text-center position-relative">
      <i class="bi bi-person-badge display-6 text-warning"></i>
      <h3 class="mt-2"><?= $totalPostulacionesPendientes ?></h3>
      <p class="mb-0 text-secondary">Postulaciones Pendientes</p>
      <a href="<?= rutaBase() ?>admin/postulaciones.php" class="stretched-link"></a>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card mdt-card p-3 text-center">
      <i class="bi bi-envelope display-6 text-info"></i>
      <h3 class="mt-2"><?= $totalContactos ?></h3>
      <p class="mb-0 text-secondary">Mensajes de Contacto sin leer</p>
    </div>
  </div>
</div>
<div class="row g-3">
  <div class="col-md-3"><a href="<?= rutaBase() ?>admin/usuarios.php" class="btn btn-outline-light w-100 p-3"><i class="bi bi-people d-block display-6 mb-2"></i>Gestionar Usuarios</a></div>
  <div class="col-md-3"><a href="<?= rutaBase() ?>admin/categorias.php" class="btn btn-outline-light w-100 p-3"><i class="bi bi-tags d-block display-6 mb-2"></i>Categorías</a></div>
  <div class="col-md-3"><a href="<?= rutaBase() ?>admin/estados.php" class="btn btn-outline-light w-100 p-3"><i class="bi bi-list-check d-block display-6 mb-2"></i>Estados</a></div>
  <div class="col-md-3"><a href="<?= rutaBase() ?>admin/config.php?seccion=public" class="btn btn-outline-light w-100 p-3"><i class="bi bi-globe d-block display-6 mb-2"></i>Editor Portal Civil</a></div>
  <div class="col-md-3"><a href="<?= rutaBase() ?>admin/config.php?seccion=mdt" class="btn btn-outline-light w-100 p-3"><i class="bi bi-display d-block display-6 mb-2"></i>Editor MDT</a></div>
  <div class="col-md-3"><a href="<?= rutaBase() ?>admin/postulaciones.php" class="btn btn-outline-light w-100 p-3"><i class="bi bi-person-badge d-block display-6 mb-2"></i>Postulaciones</a></div>
  <div class="col-md-3"><a href="<?= rutaBase() ?>admin/logs.php" class="btn btn-outline-light w-100 p-3"><i class="bi bi-clock-history d-block display-6 mb-2"></i>Ver Logs</a></div>
  <div class="col-md-3"><a href="<?= rutaBase() ?>admin/backup.php" class="btn btn-outline-light w-100 p-3"><i class="bi bi-download d-block display-6 mb-2"></i>Backup DB</a></div>
</div>

<?php require __DIR__ . '/../includes/layout_admin_bottom.php'; ?>
