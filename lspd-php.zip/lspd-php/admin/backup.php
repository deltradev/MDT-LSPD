<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

/**
 * ByetHost (como la mayoría de hostings gratuitos) no da acceso a SSH ni a
 * la herramienta mysqldump, así que este backup lo arma el propio PHP:
 * recorre todas las tablas de la base y genera un .sql con CREATE TABLE +
 * INSERT de cada fila. Es más lento que mysqldump para bases enormes, pero
 * para el volumen de datos de este sistema funciona perfectamente.
 */

$pdo = obtenerConexion();
$usuario = usuarioActual();

$tablas = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);

$sql = "-- Backup LSPD CMS — generado el " . date('Y-m-d H:i:s') . "\n";
$sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

foreach ($tablas as $tabla) {
    $crear = $pdo->query("SHOW CREATE TABLE `{$tabla}`")->fetch();
    $sql .= "DROP TABLE IF EXISTS `{$tabla}`;\n";
    $sql .= $crear['Create Table'] . ";\n\n";

    $filas = $pdo->query("SELECT * FROM `{$tabla}`")->fetchAll();
    foreach ($filas as $fila) {
        $columnas = array_keys($fila);
        $valores = array_map(function ($v) use ($pdo) {
            return $v === null ? 'NULL' : $pdo->quote((string) $v);
        }, array_values($fila));

        $sql .= "INSERT INTO `{$tabla}` (`" . implode('`, `', $columnas) . "`) VALUES ("
              . implode(', ', $valores) . ");\n";
    }
    $sql .= "\n";
}

$sql .= "SET FOREIGN_KEY_CHECKS=1;\n";

logAccion($usuario['id'], 'Descargó backup de la base de datos (.sql)');

$nombreArchivo = 'lspd_backup_' . date('Ymd_His') . '.sql';
header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="' . $nombreArchivo . '"');
header('Content-Length: ' . strlen($sql));
echo $sql;
