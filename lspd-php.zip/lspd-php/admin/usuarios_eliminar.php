<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = usuarioActual();
    $id = (int) ($_POST['id'] ?? 0);

    if ($id === (int) $usuario['id']) {
        flash('danger', 'No puedes eliminar tu propio usuario.');
    } else {
        $pdo = obtenerConexion();
        $stmt = $pdo->prepare('DELETE FROM usuarios WHERE id = ?');
        $stmt->execute([$id]);
        flash('info', 'Usuario eliminado.');
    }
}

redirigir('admin/usuarios.php');
