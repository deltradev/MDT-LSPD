<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$pdo = obtenerConexion();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tabla = $_POST['tabla'] ?? '';
    $nombre = trim($_POST['nombre'] ?? '');
    $monto = $_POST['monto_sugerido'] ?? 0;

    if ($tabla === 'denuncia' && $nombre !== '') {
        $stmt = $pdo->prepare('INSERT IGNORE INTO categorias_denuncia (nombre) VALUES (?)');
        $stmt->execute([$nombre]);
    } elseif ($tabla === 'investigacion' && $nombre !== '') {
        $stmt = $pdo->prepare('INSERT IGNORE INTO categorias_investigacion (nombre) VALUES (?)');
        $stmt->execute([$nombre]);
    } elseif ($tabla === 'multa' && $nombre !== '') {
        $stmt = $pdo->prepare('INSERT IGNORE INTO categorias_multa (nombre, monto_sugerido) VALUES (?, ?)');
        $stmt->execute([$nombre, (float) $monto]);
    }

    flash('success', 'Categoría agregada.');
    redirigir('admin/categorias.php');
}

$catDenuncia = $pdo->query('SELECT * FROM categorias_denuncia ORDER BY nombre')->fetchAll();
$catInvestigacion = $pdo->query('SELECT * FROM categorias_investigacion ORDER BY nombre')->fetchAll();
$catMulta = $pdo->query('SELECT * FROM categorias_multa ORDER BY nombre')->fetchAll();

$tituloPagina = 'Gestionar Categorías';
require __DIR__ . '/../includes/layout_admin_top.php';
?>

<h3 class="text-light mb-4"><i class="bi bi-tags"></i> Gestionar Categorías</h3>
<div class="row g-4">
  <div class="col-md-4">
    <div class="card mdt-card p-3">
      <h5>Categorías de Denuncia</h5>
      <form method="POST" class="d-flex gap-2 mb-3">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="tabla" value="denuncia">
        <input type="text" name="nombre" class="form-control" placeholder="Nueva categoría" required>
        <button class="btn btn-primary"><i class="bi bi-plus-lg"></i></button>
      </form>
      <ul class="list-group list-group-flush">
        <?php foreach ($catDenuncia as $c): ?>
        <li class="list-group-item mdt-list-item d-flex justify-content-between align-items-center">
          <?= escape($c['nombre']) ?>
          <form method="POST" action="<?= rutaBase() ?>admin/categorias_eliminar.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="tabla" value="denuncia">
            <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card mdt-card p-3">
      <h5>Categorías de Investigación</h5>
      <form method="POST" class="d-flex gap-2 mb-3">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="tabla" value="investigacion">
        <input type="text" name="nombre" class="form-control" placeholder="Nueva categoría" required>
        <button class="btn btn-primary"><i class="bi bi-plus-lg"></i></button>
      </form>
      <ul class="list-group list-group-flush">
        <?php foreach ($catInvestigacion as $c): ?>
        <li class="list-group-item mdt-list-item d-flex justify-content-between align-items-center">
          <?= escape($c['nombre']) ?>
          <form method="POST" action="<?= rutaBase() ?>admin/categorias_eliminar.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="tabla" value="investigacion">
            <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card mdt-card p-3">
      <h5>Categorías de Multa</h5>
      <form method="POST" class="mb-3">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="tabla" value="multa">
        <div class="d-flex gap-2">
          <input type="text" name="nombre" class="form-control" placeholder="Nueva categoría" required>
          <input type="number" step="0.01" name="monto_sugerido" class="form-control" placeholder="Monto $" style="max-width:110px" required>
          <button class="btn btn-primary"><i class="bi bi-plus-lg"></i></button>
        </div>
      </form>
      <ul class="list-group list-group-flush">
        <?php foreach ($catMulta as $c): ?>
        <li class="list-group-item mdt-list-item d-flex justify-content-between align-items-center">
          <?= escape($c['nombre']) ?> ($<?= number_format((float) $c['monto_sugerido'], 2) ?>)
          <form method="POST" action="<?= rutaBase() ?>admin/categorias_eliminar.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="tabla" value="multa">
            <input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
          </form>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/layout_admin_bottom.php'; ?>
