<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $usuario = usuarioActual();
    $id = (int) ($_POST['id'] ?? 0);

    $stmt = $pdo->prepare('SELECT * FROM postulaciones WHERE id = ?');
    $stmt->execute([$id]);
    $postulacion = $stmt->fetch();

    if ($postulacion) {
        $pdo->prepare("UPDATE postulaciones SET estado = 'Aprobada' WHERE id = ?")->execute([$id]);

        if ($postulacion['id_usuario_civil']) {
            $stmt = $pdo->prepare("UPDATE usuarios SET rol = 'Cadete' WHERE id = ? AND rol = 'Civil'");
            $stmt->execute([$postulacion['id_usuario_civil']]);
        }

        logAccion($usuario['id'], "Aprobó postulación #{$id}");
        flash('success', 'Postulación aprobada. El usuario ahora es Cadete (si tenía cuenta vinculada).');
    }
}

redirigir('admin/postulaciones.php');
