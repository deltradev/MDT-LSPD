<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$pdo = obtenerConexion();
$seccion = $_GET['seccion'] ?? 'public';
if (!in_array($seccion, ['public', 'mdt'], true)) {
    http_response_code(404);
    die('Sección no válida.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Los checkboxes no llegan en $_POST si están desmarcados, así que hay
    // que forzarlos a "0" explícitamente si no vinieron en el formulario.
    $clavesCheckbox = ['postulaciones_activas'];

    $stmt = $pdo->prepare('SELECT clave FROM configuracion WHERE seccion = ?');
    $stmt->execute([$seccion]);
    $clavesExistentes = array_column($stmt->fetchAll(), 'clave');

    foreach ($_POST as $clave => $valor) {
        if ($clave === 'csrf_token') {
            continue;
        }
        $stmt = $pdo->prepare('INSERT INTO configuracion (clave, valor, seccion) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE valor = ?');
        $stmt->execute([$clave, $valor, $seccion, $valor]);
    }

    foreach ($clavesCheckbox as $clave) {
        if (in_array($clave, $clavesExistentes, true) && !isset($_POST[$clave])) {
            $stmt = $pdo->prepare('INSERT INTO configuracion (clave, valor, seccion) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE valor = ?');
            $stmt->execute([$clave, '0', $seccion, '0']);
        }
    }

    flash('success', 'Configuración actualizada.');
    redirigir('admin/config.php', 'seccion=' . $seccion);
}

$config = $pdo->prepare('SELECT * FROM configuracion WHERE seccion = ?');
$config->execute([$seccion]);
$config = $config->fetchAll();

$noticias = [];
if ($seccion === 'public') {
    $noticias = $pdo->query('SELECT * FROM noticias ORDER BY id DESC')->fetchAll();
}

$tituloPagina = 'Editor ' . ($seccion === 'public' ? 'Portal Civil' : 'MDT');
require __DIR__ . '/../includes/layout_admin_top.php';
?>

<h3 class="text-light mb-4">
  <i class="bi <?= $seccion === 'public' ? 'bi-globe' : 'bi-display' ?>"></i>
  Editor <?= $seccion === 'public' ? 'Portal Civil' : 'MDT' ?>
</h3>

<div class="card mdt-card p-4 mb-4">
  <form method="POST">
    <?= csrfCampoOculto() ?>
    <?php foreach ($config as $c): ?>
    <div class="mb-3">
      <label class="form-label"><?= escape(ucwords(str_replace('_', ' ', $c['clave']))) ?></label>
      <?php if ($c['clave'] === 'postulaciones_activas'): ?>
        <div class="form-check form-switch">
          <input class="form-check-input" type="checkbox" role="switch" name="postulaciones_activas" value="1"
                 id="postulacionesActivas" <?= $c['valor'] === '1' ? 'checked' : '' ?>>
          <label class="form-check-label" for="postulacionesActivas">
            <?= $c['valor'] === '1' ? 'Abiertas' : 'Cerradas' ?> — permite o bloquea el acceso al formulario de postulación
          </label>
        </div>
      <?php elseif ($c['clave'] === 'postulaciones_form_url'): ?>
        <input type="url" name="<?= escape($c['clave']) ?>" class="form-control" value="<?= escape($c['valor']) ?>"
               placeholder="https://docs.google.com/forms/d/e/XXXXXXX/viewform?embedded=true">
        <div class="form-text text-secondary">
          Pega aquí el enlace de tu Google Form (con <code>?embedded=true</code> al final para que se vea bien incrustado).
        </div>
      <?php elseif (strpos($c['clave'], 'texto') !== false || strpos($c['clave'], 'descripcion') !== false): ?>
        <textarea name="<?= escape($c['clave']) ?>" class="form-control" rows="2"><?= escape($c['valor']) ?></textarea>
      <?php elseif (strpos($c['clave'], 'color') !== false): ?>
        <input type="color" name="<?= escape($c['clave']) ?>" class="form-control form-control-color" value="<?= escape($c['valor'] ?: '#0d6efd') ?>">
      <?php else: ?>
        <input type="text" name="<?= escape($c['clave']) ?>" class="form-control" value="<?= escape($c['valor']) ?>">
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Guardar Configuración</button>
  </form>
</div>

<?php if ($seccion === 'public'): ?>
<div class="card mdt-card p-4">
  <h5><i class="bi bi-newspaper"></i> Noticias / Anuncios</h5>
  <form method="POST" action="<?= rutaBase() ?>admin/noticias_nueva.php" class="mb-3">
    <?= csrfCampoOculto() ?>
    <div class="mb-2"><input type="text" name="titulo" class="form-control" placeholder="Título" required></div>
    <div class="mb-2"><textarea name="contenido" class="form-control" rows="2" placeholder="Contenido"></textarea></div>
    <button class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Publicar</button>
  </form>
  <ul class="list-group list-group-flush">
    <?php foreach ($noticias as $n): ?>
    <li class="list-group-item mdt-list-item d-flex justify-content-between align-items-start">
      <div><strong><?= escape($n['titulo']) ?></strong><br><small class="text-secondary"><?= escape($n['fecha']) ?></small><p class="mb-0"><?= nl2br(escape($n['contenido'])) ?></p></div>
      <form method="POST" action="<?= rutaBase() ?>admin/noticias_eliminar.php">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="id" value="<?= (int) $n['id'] ?>">
        <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
      </form>
    </li>
    <?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../includes/layout_admin_bottom.php'; ?>
