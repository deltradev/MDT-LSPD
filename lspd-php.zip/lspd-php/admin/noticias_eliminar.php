<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $stmt = $pdo->prepare('DELETE FROM noticias WHERE id = ?');
    $stmt->execute([(int) ($_POST['id'] ?? 0)]);
    flash('info', 'Noticia eliminada.');
}

redirigir('admin/config.php', 'seccion=public');
