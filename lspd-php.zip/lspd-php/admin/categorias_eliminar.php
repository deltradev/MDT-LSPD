<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$tablasValidas = [
    'denuncia' => 'categorias_denuncia',
    'investigacion' => 'categorias_investigacion',
    'multa' => 'categorias_multa',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tabla = $_POST['tabla'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if (isset($tablasValidas[$tabla])) {
        $pdo = obtenerConexion();
        $nombreTabla = $tablasValidas[$tabla]; // whitelisted, no viene directo del usuario en el SQL
        $stmt = $pdo->prepare("DELETE FROM {$nombreTabla} WHERE id = ?");
        $stmt->execute([$id]);
        flash('info', 'Categoría eliminada.');
    }
}

redirigir('admin/categorias.php');
