<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = obtenerConexion();
    $usuario = usuarioActual();

    $placa = trim($_POST['placa'] ?? '');
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $rol = $_POST['rol'] ?? 'Civil';

    $stmt = $pdo->prepare('SELECT id FROM usuarios WHERE placa = ?');
    $stmt->execute([$placa]);

    if ($stmt->fetch()) {
        flash('danger', 'Ya existe un usuario con esa placa/DNI.');
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare(
            "INSERT INTO usuarios (placa, nombre, apellido, password_hash, rol, fecha_ingreso, activo)
             VALUES (?, ?, ?, ?, ?, CURDATE(), 1)"
        );
        $stmt->execute([$placa, $nombre, $apellido, $hash, $rol]);
        logAccion($usuario['id'], "Creó usuario {$placa}");
        flash('success', 'Usuario creado correctamente.');
    }
}

redirigir('admin/usuarios.php');
