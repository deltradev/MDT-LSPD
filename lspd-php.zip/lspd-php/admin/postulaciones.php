<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requerirAdmin();

$pdo = obtenerConexion();
$postulaciones = $pdo->query('SELECT * FROM postulaciones ORDER BY id DESC')->fetchAll();

$tituloPagina = 'Postulaciones';
require __DIR__ . '/../includes/layout_admin_top.php';
?>

<h3 class="text-light mb-4"><i class="bi bi-person-badge"></i> Gestionar Postulaciones</h3>
<div class="alert alert-info">
  <i class="bi bi-info-circle"></i> Las postulaciones ahora se reciben a través del formulario de Google configurado en
  <a href="<?= rutaBase() ?>admin/config.php?seccion=public">Editor Portal Civil</a>. Esta tabla queda disponible para
  registros manuales o históricos, en caso de que necesites cargar una postulación a mano.
</div>
<div class="card mdt-card p-3">
  <table class="table table-dark table-hover align-middle">
    <thead><tr><th>Nombre</th><th>DNI</th><th>Edad</th><th>Motivo</th><th>CV</th><th>Estado</th><th>Fecha</th><th>Acciones</th></tr></thead>
    <tbody>
    <?php if (empty($postulaciones)): ?>
      <tr><td colspan="8" class="text-secondary">No hay postulaciones registradas.</td></tr>
    <?php else: ?>
      <?php foreach ($postulaciones as $p): ?>
      <tr>
        <td><?= escape($p['nombre']) ?></td><td><?= escape($p['dni']) ?></td><td><?= escape($p['edad']) ?></td>
        <td style="max-width:250px"><?= escape($p['motivo']) ?></td>
        <td><?php if ($p['cv_ruta']): ?><a href="<?= rutaBase() ?>descargar.php?f=<?= urlencode($p['cv_ruta']) ?>" target="_blank" class="text-info">Ver CV</a><?php else: ?>-<?php endif; ?></td>
        <td><span class="badge bg-secondary"><?= escape($p['estado']) ?></span></td>
        <td><?= escape($p['fecha']) ?></td>
        <td>
          <?php if ($p['estado'] === 'Pendiente'): ?>
          <form method="POST" action="<?= rutaBase() ?>admin/postulaciones_aprobar.php" class="d-inline">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
            <button class="btn btn-sm btn-outline-success"><i class="bi bi-check-lg"></i></button>
          </form>
          <form method="POST" action="<?= rutaBase() ?>admin/postulaciones_rechazar.php" class="d-inline">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-x-lg"></i></button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../includes/layout_admin_bottom.php'; ?>
