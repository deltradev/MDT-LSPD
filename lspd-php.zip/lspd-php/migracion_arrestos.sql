-- ============================================================
-- migracion_arrestos.sql
-- ============================================================
-- Ejecutar SOLO si ya tenías el sistema instalado ANTES de este
-- cambio (temporizador de condena en arrestos). Si estás
-- instalando desde cero, no hace falta: schema.sql ya incluye
-- todo esto.
--
-- Cómo usar: phpMyAdmin → tu base de datos → pestaña "Importar" →
-- subir este archivo. Es seguro ejecutarlo más de una vez.
-- ============================================================

ALTER TABLE arrestos
    ADD COLUMN IF NOT EXISTS duracion_minutos INT NULL AFTER notas,
    ADD COLUMN IF NOT EXISTS inicio_condena DATETIME NULL AFTER duracion_minutos;

INSERT IGNORE INTO estados (tipo, nombre) VALUES ('arresto', 'Condena Cumplida');

-- Nota: si tu versión de MySQL es más vieja que 8.0.29, "ADD COLUMN IF NOT
-- EXISTS" puede no estar soportado. En ese caso quitá el "IF NOT EXISTS"
-- de cada línea del ALTER TABLE de arriba y ejecutalo una sola vez.
