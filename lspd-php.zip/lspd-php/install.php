<?php
/**
 * install.php
 * Visitá este archivo UNA SOLA VEZ desde el navegador después de:
 *   1) Crear la base de datos MySQL en el panel de ByetHost
 *   2) Importar schema.sql desde phpMyAdmin
 *   3) Editar config.php con tus datos de conexión
 *
 * Esto crea el usuario administrador inicial (placa 9999 / admin123)
 * generando el hash de la contraseña con el propio PHP del servidor
 * (más seguro que pegar un hash escrito a mano).
 *
 * IMPORTANTE: Borrá este archivo del servidor después de usarlo.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/db.php';

header('Content-Type: text/html; charset=utf-8');

function pagina($titulo, $mensaje, $exito = true) {
    $color = $exito ? '#198754' : '#dc3545';
    echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>
        <title>$titulo</title>
        <style>
            body { font-family: system-ui, sans-serif; background:#0f1620; color:#e2e8f0; display:flex; align-items:center; justify-content:center; height:100vh; margin:0; }
            .box { background:#161f2c; border:1px solid #2a3646; border-radius:10px; padding:2rem; max-width:520px; }
            h1 { color: $color; font-size: 1.4rem; }
            code { background:#0f1620; padding:2px 6px; border-radius:4px; }
            a { color:#0d6efd; }
        </style></head><body><div class='box'><h1>$titulo</h1><p>$mensaje</p></div></body></html>";
    exit;
}

try {
    $pdo = obtenerConexion();
} catch (Exception $e) {
    pagina(
        '❌ Error de conexión',
        'No se pudo conectar a la base de datos. Revisá los datos en <code>config.php</code> (DB_HOST, DB_NAME, DB_USER, DB_PASS). Detalle técnico: ' . htmlspecialchars($e->getMessage()),
        false
    );
}

// Verificar si la tabla usuarios existe (o sea, si ya se importó schema.sql)
try {
    $pdo->query('SELECT 1 FROM usuarios LIMIT 1');
} catch (Exception $e) {
    pagina(
        '❌ Faltan las tablas',
        'La conexión a la base de datos funciona, pero no encuentro la tabla <code>usuarios</code>. Importá primero <code>schema.sql</code> desde phpMyAdmin y volvé a cargar esta página.',
        false
    );
}

// Verificar si ya existe el usuario 9999
$stmt = $pdo->prepare('SELECT id FROM usuarios WHERE placa = ?');
$stmt->execute(['9999']);
$existente = $stmt->fetch();

if ($existente) {
    pagina(
        '✅ Ya estaba instalado',
        'El usuario administrador (placa <code>9999</code>) ya existe — no hace falta hacer nada más. '
        . 'Por seguridad, <strong>borrá este archivo (install.php) del servidor ahora</strong> y andá a '
        . '<a href="public/login.php">iniciar sesión</a>.'
    );
}

// Crear el usuario admin con el hash generado por el propio PHP del servidor
$hash = password_hash('admin123', PASSWORD_DEFAULT);
$stmt = $pdo->prepare(
    'INSERT INTO usuarios (placa, nombre, apellido, password_hash, rol, fecha_ingreso, activo)
     VALUES (?, ?, ?, ?, ?, CURDATE(), 1)'
);
$stmt->execute(['9999', 'Admin', 'Web', $hash, 'AdminWeb']);

pagina(
    '✅ Instalación completa',
    'Se creó el usuario administrador correctamente.<br><br>'
    . 'Placa: <code>9999</code><br>Contraseña: <code>admin123</code><br><br>'
    . '<strong>Ahora borrá este archivo (install.php) del servidor</strong> — ya cumplió su función y '
    . 'dejarlo puede ser un riesgo de seguridad. Después andá a '
    . '<a href="public/login.php">iniciar sesión</a> y cambiá la contraseña cuanto antes desde el panel de administración.'
);
