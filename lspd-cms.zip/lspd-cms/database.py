# -*- coding: utf-8 -*-
"""
database.py
Inicializa la base de datos SQLite (lspd.db) con todas las tablas necesarias
para el sistema LSPD (Portal Público Civil + MDT Interna).

Se ejecuta automáticamente al arrancar app.py, así que no hace falta correr
este archivo por separado (aunque también se puede: `python database.py`).
"""

import sqlite3
import bcrypt
from datetime import datetime

DB_NAME = "lspd.db"

# Roles válidos del sistema
ROL_CIVIL = "Civil"
ROLES_LSPD = ["Cadete", "Oficial", "Sargento", "Teniente", "Capitán", "Jefe", "AdminWeb"]
ROLES_ADMIN = ["Jefe", "AdminWeb"]
TODOS_LOS_ROLES = [ROL_CIVIL] + ROLES_LSPD


def get_connection():
    """Devuelve una conexión a la base de datos con row_factory tipo dict."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Crea todas las tablas si no existen y siembra datos iniciales."""
    conn = get_connection()
    c = conn.cursor()

    # ------------------------------------------------------------------
    # USUARIOS
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            placa TEXT UNIQUE NOT NULL,
            nombre TEXT NOT NULL,
            apellido TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            rol TEXT NOT NULL DEFAULT 'Civil',
            fecha_ingreso TEXT NOT NULL,
            activo INTEGER NOT NULL DEFAULT 1
        )
    """)

    # ------------------------------------------------------------------
    # CATEGORÍAS Y ESTADOS (dinámicos, gestionables desde /admin/panel)
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS categorias_denuncia (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT UNIQUE NOT NULL
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS categorias_investigacion (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT UNIQUE NOT NULL
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS categorias_multa (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT UNIQUE NOT NULL,
            monto_sugerido REAL DEFAULT 0
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS estados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo TEXT NOT NULL,      -- 'denuncia' | 'investigacion' | 'postulacion' | 'multa'
            nombre TEXT NOT NULL,
            UNIQUE(tipo, nombre)
        )
    """)

    # ------------------------------------------------------------------
    # DENUNCIAS
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS denuncias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nro_caso TEXT UNIQUE NOT NULL,
            tipo TEXT,
            fecha TEXT NOT NULL,
            lugar TEXT,
            denunciante TEXT,
            denunciado_dni TEXT,
            descripcion TEXT,
            estado TEXT NOT NULL DEFAULT 'Pendiente',
            id_oficial INTEGER,
            id_civil_creador INTEGER,
            fecha_creacion TEXT NOT NULL,
            es_publica INTEGER NOT NULL DEFAULT 0,
            datos_extra_json TEXT,
            FOREIGN KEY (id_oficial) REFERENCES usuarios(id),
            FOREIGN KEY (id_civil_creador) REFERENCES usuarios(id)
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS archivos_denuncia (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            id_denuncia INTEGER NOT NULL,
            nombre_archivo TEXT NOT NULL,
            ruta TEXT NOT NULL,
            FOREIGN KEY (id_denuncia) REFERENCES denuncias(id) ON DELETE CASCADE
        )
    """)

    # ------------------------------------------------------------------
    # BASE DE DATOS CRIMINAL
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS personas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            dni TEXT,
            foto TEXT,
            alias TEXT,
            direccion TEXT,
            antecedentes TEXT,
            nivel_amenaza TEXT DEFAULT 'Bajo',
            es_publico INTEGER NOT NULL DEFAULT 0,
            id_banda INTEGER,
            fecha_registro TEXT,
            FOREIGN KEY (id_banda) REFERENCES bandas(id)
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS bandas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            tag TEXT,
            lider TEXT,
            territorio TEXT,
            actividades TEXT,
            nivel_peligro TEXT DEFAULT 'Bajo',
            foto TEXT,
            es_publico INTEGER NOT NULL DEFAULT 0,
            fecha_registro TEXT
        )
    """)

    # ------------------------------------------------------------------
    # INVESTIGACIONES
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS investigaciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nro_operacion TEXT UNIQUE NOT NULL,
            nombre TEXT NOT NULL,
            objetivo_tipo TEXT,
            objetivo_id INTEGER,
            descripcion TEXT,
            categoria TEXT,
            estado TEXT NOT NULL DEFAULT 'Abierta',
            id_oficial_cargo INTEGER,
            fecha_inicio TEXT NOT NULL,
            FOREIGN KEY (id_oficial_cargo) REFERENCES usuarios(id)
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS notas_investigacion (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            id_investigacion INTEGER NOT NULL,
            nota TEXT,
            id_oficial INTEGER,
            fecha TEXT NOT NULL,
            archivo_adjunto TEXT,
            FOREIGN KEY (id_investigacion) REFERENCES investigaciones(id) ON DELETE CASCADE,
            FOREIGN KEY (id_oficial) REFERENCES usuarios(id)
        )
    """)

    # ------------------------------------------------------------------
    # MULTAS
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS multas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            id_persona INTEGER,
            nombre_infractor TEXT,
            dni_infractor TEXT,
            motivo TEXT NOT NULL,
            monto REAL NOT NULL DEFAULT 0,
            id_oficial INTEGER,
            fecha TEXT NOT NULL,
            estado TEXT NOT NULL DEFAULT 'Pendiente',
            FOREIGN KEY (id_persona) REFERENCES personas(id),
            FOREIGN KEY (id_oficial) REFERENCES usuarios(id)
        )
    """)

    # ------------------------------------------------------------------
    # POSTULACIONES
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS postulaciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            dni TEXT NOT NULL,
            edad INTEGER,
            motivo TEXT,
            cv_ruta TEXT,
            estado TEXT NOT NULL DEFAULT 'Pendiente',
            fecha TEXT NOT NULL,
            id_usuario_civil INTEGER,
            FOREIGN KEY (id_usuario_civil) REFERENCES usuarios(id)
        )
    """)

    # ------------------------------------------------------------------
    # CONTENIDO PÚBLICO
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS noticias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            contenido TEXT,
            imagen TEXT,
            fecha TEXT NOT NULL,
            publicado INTEGER NOT NULL DEFAULT 1
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS contactos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT,
            email TEXT,
            mensaje TEXT,
            fecha TEXT NOT NULL,
            leido INTEGER NOT NULL DEFAULT 0
        )
    """)

    # ------------------------------------------------------------------
    # CONFIGURACIÓN
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS configuracion (
            clave TEXT PRIMARY KEY,
            valor TEXT,
            seccion TEXT
        )
    """)

    # ------------------------------------------------------------------
    # LOGS
    # ------------------------------------------------------------------
    c.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            id_usuario INTEGER,
            accion TEXT NOT NULL,
            fecha TEXT NOT NULL,
            FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
        )
    """)

    conn.commit()

    # ------------------------------------------------------------------
    # SEED: usuario inicial AdminWeb (placa 9999 / admin123)
    # ------------------------------------------------------------------
    existe = c.execute("SELECT id FROM usuarios WHERE placa = ?", ("9999",)).fetchone()
    if not existe:
        pw_hash = bcrypt.hashpw("admin123".encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
        c.execute("""
            INSERT INTO usuarios (placa, nombre, apellido, password_hash, rol, fecha_ingreso, activo)
            VALUES (?, ?, ?, ?, ?, ?, 1)
        """, ("9999", "Admin", "Web", pw_hash, "AdminWeb", datetime.now().strftime("%Y-%m-%d")))

    # ------------------------------------------------------------------
    # SEED: categorías y estados por defecto
    # ------------------------------------------------------------------
    cats_denuncia = ["Robo", "Homicidio", "Vandalismo", "Tráfico de drogas", "Extorsión", "Otro"]
    for cat in cats_denuncia:
        c.execute("INSERT OR IGNORE INTO categorias_denuncia (nombre) VALUES (?)", (cat,))

    cats_investigacion = ["Narcóticos", "Crimen organizado", "Homicidios", "Robos", "Cibercrimen"]
    for cat in cats_investigacion:
        c.execute("INSERT OR IGNORE INTO categorias_investigacion (nombre) VALUES (?)", (cat,))

    cats_multa = [
        ("Exceso de velocidad", 250.0),
        ("Estacionamiento indebido", 100.0),
        ("Conducción temeraria", 400.0),
        ("Sin licencia", 300.0),
        ("Otro", 50.0),
    ]
    for nombre, monto in cats_multa:
        c.execute("INSERT OR IGNORE INTO categorias_multa (nombre, monto_sugerido) VALUES (?, ?)", (nombre, monto))

    estados_seed = {
        "denuncia": ["Pendiente", "En investigación", "Cerrada", "Archivada"],
        "investigacion": ["Abierta", "En curso", "Cerrada", "Archivada"],
        "postulacion": ["Pendiente", "Aprobada", "Rechazada"],
        "multa": ["Pendiente", "Pagada", "Anulada"],
    }
    for tipo, nombres in estados_seed.items():
        for nombre in nombres:
            c.execute("INSERT OR IGNORE INTO estados (tipo, nombre) VALUES (?, ?)", (tipo, nombre))

    # ------------------------------------------------------------------
    # SEED: configuración (editor de portales)
    # ------------------------------------------------------------------
    config_seed = [
        ("nombre_departamento", "Los Santos Police Department", "public"),
        ("banner_texto", "Servir y Proteger a la Ciudad de Los Santos", "public"),
        ("logo_public", "", "public"),
        ("footer_texto", "© Los Santos Police Department - Todos los derechos reservados", "public"),
        ("mdt_titulo", "MDT - Terminal de Datos Móvil", "mdt"),
        ("mdt_color_primario", "#0d6efd", "mdt"),
        ("mdt_logo", "", "mdt"),
        ("mdt_texto_dashboard", "Bienvenido a la Terminal de Datos Móvil del LSPD", "mdt"),
    ]
    for clave, valor, seccion in config_seed:
        c.execute("INSERT OR IGNORE INTO configuracion (clave, valor, seccion) VALUES (?, ?, ?)", (clave, valor, seccion))

    # Noticia de bienvenida de ejemplo
    noticia_existe = c.execute("SELECT id FROM noticias").fetchone()
    if not noticia_existe:
        c.execute("""
            INSERT INTO noticias (titulo, contenido, imagen, fecha, publicado)
            VALUES (?, ?, ?, ?, 1)
        """, (
            "Bienvenidos al nuevo portal del LSPD",
            "El Departamento de Policía de Los Santos presenta su nuevo portal ciudadano, "
            "donde podrás realizar denuncias, postular a la institución y mantenerte informado.",
            "",
            datetime.now().strftime("%Y-%m-%d %H:%M"),
        ))

    conn.commit()
    conn.close()


def log_accion(id_usuario, accion):
    """Inserta un registro en la tabla de logs."""
    conn = get_connection()
    conn.execute(
        "INSERT INTO logs (id_usuario, accion, fecha) VALUES (?, ?, ?)",
        (id_usuario, accion, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    )
    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    print("Base de datos inicializada correctamente en", DB_NAME)
