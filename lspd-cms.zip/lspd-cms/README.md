# LSPD CMS — Portal Público Civil + MDT Interna

Aplicación Flask completa con dos portales:

1. **Portal Público Civil** (`/`) — accesible sin login para cualquier ciudadano.
2. **MDT Interna LSPD** (`/mdt`) — accesible solo para personal LSPD autenticado.
3. **Panel de Administración** (`/admin/panel`) — solo para `Jefe` y `AdminWeb`.

Todo con CMS: noticias, categorías, estados y textos de ambos portales son editables desde el panel de administración sin tocar código.

---

## 🚀 Instalación

### En un PC (Linux/Mac/Windows)

```bash
# 1. Crear entorno virtual (recomendado)
python3 -m venv venv
source venv/bin/activate        # En Windows: venv\Scripts\activate

# 2. Instalar dependencias
pip install -r requirements.txt

# 3. Ejecutar la aplicación
python app.py
```

### 📱 En Termux (Android)

La app es 100% compatible con Termux: no usa `bcrypt` (requiere compilar con Rust y suele fallar en Termux); en su lugar usa `werkzeug.security`, que es Python puro y no necesita compilación.

```bash
# 1. Actualizar Termux e instalar Python
pkg update && pkg upgrade -y
pkg install python -y

# 2. (Opcional) descomprimir el proyecto si lo pasaste como .zip
#    pkg install unzip -y  &&  unzip lspd-cms.zip  &&  cd lspd-cms
cd lspd-cms

# 3. Actualizar pip e instalar dependencias
pip install --upgrade pip
pip install -r requirements.txt

# 4. Ejecutar la aplicación
python app.py
```

La app queda escuchando en `http://127.0.0.1:5000` (y también en `0.0.0.0:5000`).
Abre ese enlace desde el navegador del propio teléfono (Chrome, Firefox, etc.) mientras Termux siga corriendo en segundo plano.

**Notas para Termux:**
- No necesitas `termux-setup-storage` a menos que quieras copiar el `.db` o los archivos subidos fuera de la carpeta del proyecto.
- Si `pip install reportlab` se ve lento, es normal la primera vez: descarga e instala el paquete puro-Python, no requiere compilar nada.
- Para mantener el servidor corriendo aunque bloquees la pantalla, activa la "wake lock" de Termux (menú deslizable desde el borde izquierdo → Acquire wakelock), o usa `termux-wake-lock` desde otra sesión.
- Para acceder desde otro dispositivo de tu misma red (no solo el propio teléfono), usa la IP local del teléfono en vez de `127.0.0.1`, por ejemplo `http://192.168.x.x:5000` (puedes ver la IP con `ip addr` o `ifconfig` si tienes `pkg install net-tools`).

---

## 🔑 Usuario inicial

| Placa | Contraseña | Rol      |
|-------|------------|----------|
| 9999  | admin123   | AdminWeb |

Con este usuario puedes entrar directamente a `/mdt` y a `/admin/panel` para configurar el resto del sistema (crear más usuarios LSPD, categorías, etc.).

**Importante:** cambia esta contraseña en producción desde `/admin/usuarios`.

---

## 👥 Roles del sistema

- **Civil** — rol por defecto al registrarse. Solo accede al portal público (`/`). Si intenta entrar a `/mdt` recibe un error **403**.
- **Cadete, Oficial, Sargento, Teniente, Capitán, Jefe, AdminWeb** — roles LSPD. Todos pueden entrar a `/mdt`.
- **Jefe** y **AdminWeb** — además tienen acceso al panel `/admin/panel`.

Un Civil puede convertirse en Cadete si postula desde `/postulaciones` y un administrador aprueba su postulación desde `/admin/postulaciones`.

---

## 🗂️ Estructura del proyecto

```
lspd-cms/
├── app.py                  # Rutas, lógica de negocio, decoradores de rol
├── database.py              # Creación de tablas SQLite + datos semilla
├── requirements.txt
├── README.md
├── lspd.db                  # Se genera automáticamente
├── uploads/
│   ├── denuncias/<id>/      # Adjuntos de denuncias LSPD
│   ├── investigaciones/<id>/# Adjuntos de investigaciones y fotos BD criminal
│   └── public/<id>/         # CVs de postulaciones
├── static/
│   ├── css/style.css        # Tema oscuro (MDT + Admin)
│   ├── css/public.css       # Tema claro (Portal Civil)
│   └── js/main.js
└── templates/
    ├── public/               # Vistas del portal civil
    ├── mdt/                  # Vistas de la MDT interna
    └── admin/                # Vistas del panel de administración
```

---

## 🧩 Módulos principales

### Portal Público (`/`)
- **Inicio**: noticias/anuncios editables desde `/admin/config/public`.
- **Postulaciones** (`/postulaciones`): formulario con adjunto de CV. El Jefe/AdminWeb las revisa en `/admin/postulaciones`.
- **Denuncias Ciudadanas** (`/denuncias`): un civil puede denunciar y adjuntar evidencia; si está logueado ve su propio historial.
- **Se Busca** (`/se-busca`): lista personas y bandas marcadas como `es_publico = 1` desde la MDT.
- **Contacto** (`/contacto`).
- **Login / Registro** (`/login`, `/registro`): el registro siempre crea el rol `Civil`.

### MDT Interna (`/mdt`) — requiere rol LSPD
- **Dashboard**: métricas generales, últimas denuncias, BOLOs activos.
- **Denuncias**: CRUD completo, subida de archivos, generación de PDF con ReportLab, categorías dinámicas.
- **Base de Datos Criminal**: CRUD de Personas y Bandas, vínculo persona↔banda, marcador "Público" para BOLO.
- **Investigaciones**: CRUD con notas cronológicas y archivos adjuntos por nota.
- **Multas**: CRUD + generación de PDF de boleta oficial.
- **BOLO** (`/mdt/bolo`): personas/bandas con nivel Alto/Extremo.

### Panel Admin (`/admin/panel`) — solo Jefe/AdminWeb
- Gestión de usuarios (crear, editar, cambiar rol, desactivar, eliminar).
- Gestión de categorías (denuncias, investigaciones, multas).
- Gestión de estados (denuncia, investigación, postulación, multa).
- Editor del Portal Civil (banner, nombre del departamento, footer, noticias).
- Editor del MDT (título, color primario, texto del dashboard).
- Gestión de postulaciones (aprobar → asciende Civil a Cadete / rechazar).
- Ver logs de acciones del sistema.
- Descargar backup de la base de datos SQLite.

---

## 🔒 Seguridad implementada

- Contraseñas hasheadas con **werkzeug.security** (scrypt, Python puro — nunca se almacenan en texto plano, y sin dependencias nativas que compilar, ideal para Termux).
- Decorador `@role_required(*roles)` que protege cada ruta según el rol de sesión.
- Un Civil que intenta acceder a cualquier ruta `/mdt/*` o `/admin/*` recibe **403 Forbidden**.
- Los archivos subidos se validan por extensión (`ALLOWED_EXT`) y se guardan con `secure_filename`.
- Los adjuntos de denuncias/investigaciones solo son accesibles para personal LSPD autenticado.

---

## 📄 Generación de PDF

Se usa **ReportLab** para generar:
- Constancia oficial de denuncia (`/mdt/denuncias/<id>/pdf`).
- Boleta oficial de multa (`/mdt/multas/<id>/pdf`).

Ambos documentos incluyen encabezado institucional LSPD, tabla de datos y fecha de generación.

---

## ⚠️ Notas para producción

- Cambia `app.config["SECRET_KEY"]` por un valor aleatorio y secreto.
- Cambia la contraseña del usuario `9999` inmediatamente.
- Considera migrar de SQLite a PostgreSQL/MySQL si esperas alta concurrencia.
- Ejecuta detrás de un servidor WSGI real (Gunicorn/uWSGI) y no con `debug=True`.
