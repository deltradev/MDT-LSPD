// main.js - Funciones auxiliares de UI compartidas (opcional)
document.addEventListener('DOMContentLoaded', function () {
    // Cierre automático de alertas después de 5 segundos
    document.querySelectorAll('.alert').forEach(function (alertEl) {
        setTimeout(function () {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alertEl);
            if (bsAlert) bsAlert.close();
        }, 5000);
    });
});
