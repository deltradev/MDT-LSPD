// csrf.js
// Inserta automáticamente el token CSRF (de la etiqueta <meta name="csrf-token">)
// como campo oculto en TODOS los formularios POST de la página. Así no hace
// falta agregar el campo a mano en cada plantilla: cualquier <form method="post">
// nuevo que se agregue en el futuro queda protegido sin tocar este archivo.
document.addEventListener('DOMContentLoaded', function () {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (!meta) return;
    const token = meta.getAttribute('content');

    document.querySelectorAll('form').forEach(function (form) {
        const metodo = (form.getAttribute('method') || 'GET').toUpperCase();
        if (metodo !== 'POST') return;
        if (form.querySelector('input[name="csrf_token"]')) return;

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'csrf_token';
        input.value = token;
        form.appendChild(input);
    });
});
